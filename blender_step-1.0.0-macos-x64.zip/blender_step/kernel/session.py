"""In-memory caches keyed by blob hash.

Shapes are immutable values, so a blob hash fully identifies a shape. Undo, redo, file
load and duplicates need no special handling: a hash we have not seen is decoded once.
"""

from __future__ import annotations

from collections import OrderedDict

from . import api

_MAX = 64
_shapes: "OrderedDict[str, object]" = OrderedDict()
_tess: "OrderedDict[tuple, api.TessResult]" = OrderedDict()
_edges: "OrderedDict[tuple, list]" = OrderedDict()


def _put(cache, key, value):
    cache[key] = value
    cache.move_to_end(key)
    while len(cache) > _MAX:
        cache.popitem(last=False)


def remember(blob_hash: str, shape) -> None:
    _put(_shapes, blob_hash, shape)


def shape_for(blob_hash: str, blob: str):
    shape = _shapes.get(blob_hash)
    if shape is None:
        shape = api.from_blob(blob)
        _put(_shapes, blob_hash, shape)
    else:
        _shapes.move_to_end(blob_hash)
    return shape


def tess_for(blob_hash: str, blob: str, quality: str) -> api.TessResult:
    key = (blob_hash, quality)
    t = _tess.get(key)
    if t is None:
        t = api.tessellate(shape_for(blob_hash, blob), quality)
        _put(_tess, key, t)
    return t


def has_tess(blob_hash: str, quality: str) -> bool:
    return (blob_hash, quality) in _tess


def put_tess(blob_hash: str, quality: str, t) -> None:
    _put(_tess, (blob_hash, quality), t)


def edges_for(blob_hash: str, blob: str, quality: str) -> list:
    key = (blob_hash, quality)
    e = _edges.get(key)
    if e is None:
        e = api.edge_polylines(shape_for(blob_hash, blob), quality)
        _put(_edges, key, e)
    return e


_pairs: "OrderedDict[str, list]" = OrderedDict()


def pairs_for(blob_hash: str, blob: str) -> list:
    p = _pairs.get(blob_hash)
    if p is None:
        p = api.edge_face_pairs(shape_for(blob_hash, blob))
        _put(_pairs, blob_hash, p)
    return p


def clear() -> None:
    _shapes.clear()
    _tess.clear()
    _edges.clear()
    _pairs.clear()
