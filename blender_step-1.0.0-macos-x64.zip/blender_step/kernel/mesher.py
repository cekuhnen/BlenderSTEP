# SPDX-License-Identifier: GPL-3.0-or-later
"""A fast display mesher for B-rep bodies, used instead of the kernel's tessellation where it can.

Every edge is sampled once (to the chord tolerance and angle), and both faces meeting at it use
those very points, so the mesh is watertight. Every face is meshed in its own parameters: the
boundary loops are mapped there (in closed form for planes, cylinders, cones and spheres, through
the kernel's point projection for other surfaces), triangulated with Blender's constrained
Delaunay, and refined where a triangle is further than the tolerance from the surface or bends
more than the angle. SMLib splits closed surfaces into halves, so a face's parameters never wrap.

A face's mesh is cached by its surface and its boundary points: after an edit only the faces that
changed are meshed again. Anything this mesher cannot vouch for (a face it cannot map, a loop it
cannot close, an area that does not add up) raises Unsupported, and the caller falls back to the
kernel's tessellation of the whole body.
"""

from __future__ import annotations

import hashlib
import math
from collections import OrderedDict

import numpy as np

try:
    from mathutils.geometry import delaunay_2d_cdt
except Exception:  # outside Blender (the kernel worker)
    delaunay_2d_cdt = None


class Unsupported(Exception):
    pass


_EDGES: "OrderedDict[tuple, np.ndarray]" = OrderedDict()
_FACES: "OrderedDict[tuple, tuple]" = OrderedDict()
_MAX_EDGES = 20000
_MAX_FACES = 6000
stats = {"faces": 0, "reused": 0, "fallback": 0, "last_error": ""}


# The scene's mesher choice: "AUTO" uses the fast mesher body by body, only where it wins; "FAST" for every
# body; "KERNEL" never. `enabled` is whether the fast mesher may be used at all (mode is not "KERNEL").
mode = "AUTO"
enabled = True

# Measured on STEP files: the fast mesher solves planes, cylinders, cones and spheres in closed form (about 1.3x
# faster than the kernel, with a fifth fewer triangles), but one free-form face (a B-spline, a torus, a
# revolved or extruded curve) costs it seconds where the kernel needs milliseconds.
CLOSED_FORM = ("plane", "cylinder", "cone", "sphere")
AUTO_MIN_FACES = 20     # below this the difference is a few milliseconds

_AUTO: "OrderedDict[int, tuple]" = OrderedDict()


def set_mode(new: str) -> None:
    global mode, enabled
    mode = new if new in ("AUTO", "FAST", "KERNEL") else "AUTO"
    enabled = mode != "KERNEL"


def available() -> bool:
    return enabled and delaunay_2d_cdt is not None


def use_for(shape) -> bool:
    """Whether the fast mesher meshes this body (else the kernel does). FAST: always; AUTO: only a body
    of at least AUTO_MIN_FACES faces that are all closed-form."""
    if not available():
        return False
    if mode == "FAST":
        return True
    got = _AUTO.get(id(shape))
    if got is not None and got[0] is shape:
        return got[1]
    try:
        faces = shape.faces()
        ok = len(faces) >= AUTO_MIN_FACES and all(str(f.geom_type).lower() in CLOSED_FORM for f in faces)
    except Exception:
        ok = False
    _AUTO[id(shape)] = (shape, ok)       # (holds the shape, so its id is not reused while cached)
    while len(_AUTO) > 256:
        _AUTO.popitem(last=False)
    return ok


def clear() -> None:
    _EDGES.clear()
    _FACES.clear()


def _put(cache, key, value, limit):
    cache[key] = value
    if len(cache) > limit:
        for _ in range(len(cache) // 4):
            cache.popitem(last=False)


def quantized_tolerance(tol: float) -> float:
    """Round down to a step of 2^(1/4), so a body growing a little keeps its faces' meshes."""
    tol = max(float(tol), 1e-9)
    return 2.0 ** (math.floor(math.log2(tol) * 4.0) / 4.0)


# ----------------------------------------------------------------------------- edges

def _pt(e, t):
    return np.asarray(tuple(e.point_at(t))[:3], dtype=np.float64)


def fast_points(e, ts) -> np.ndarray:
    """Points along an edge at fractions of its own curve parameter (not of its length, as
    point_at takes them: finding the parameter at a length is slow on long intersection curves,
    a tenth of a second per point). The same points for the same edge from either face; lines
    and circles by length as before. Falls back to point_at."""
    ts = np.asarray(ts, dtype=float)
    kind = str(e.geom_type).lower()
    if kind not in ("line", "circle"):
        try:
            t0, t1 = e._range()
            u = np.clip(1.0 - ts if e._rev else ts, 0.0, 1.0)
            c = e._curve()
            return np.array([tuple(c.evaluate(float(t0 + (t1 - t0) * x)))[:3] for x in u], dtype=np.float64)
        except Exception:
            pass
    return np.array([_pt(e, float(x)) for x in ts], dtype=np.float64)


def _edge_key(e, tol, angle):
    """A key that is the same for the same edge whichever way round a face holds it, and
    different for different curves (five points along it, by arc length, and its length)."""
    a, q1, m, q3, b = fast_points(e, (0.0, 0.25, 0.5, 0.75, 1.0))
    try:
        L = float(e.length)
    except Exception:
        L = 0.0
    ka, kb, k1, k3 = a.tobytes(), b.tobytes(), q1.tobytes(), q3.tobytes()
    if ka == kb:   # closed: stored running the canonical way
        flip = k3 < k1
    else:
        flip = kb < ka
    if flip:
        ka, kb, k1, k3 = kb, ka, k3, k1
    return (str(e.geom_type), ka, k1, m.tobytes(), k3, kb, round(L, 12), tol, angle), flip


def _greedy(P, tol, angle):
    """Keep the fewest points of a dense polyline (Douglas-Peucker) so the dropped ones are
    within `tol` of the chords and no chord turns by more than `angle` against the curve."""
    n = len(P)
    if n <= 2:
        return P
    seg = np.diff(P, axis=0)
    sl = np.linalg.norm(seg, axis=1)
    T = seg / np.maximum(sl, 1e-300)[:, None]
    cosmax = math.cos(angle)
    keep = np.zeros(n, dtype=bool)
    keep[0] = keep[-1] = True
    stack = [(0, n - 1)]
    while stack:
        i, j = stack.pop()
        if j - i < 2:
            continue
        d = P[j] - P[i]
        L = math.sqrt(float(d @ d))
        if L < 1e-300:
            k = (i + j) // 2
        else:
            d = d / L
            q = P[i + 1:j] - P[i]
            off = q - np.outer(q @ d, d)
            dist = np.einsum("ij,ij->i", off, off)
            k = i + 1 + int(np.argmax(dist))
            if float(dist[k - i - 1]) <= tol * tol and float(np.min(T[i:j] @ d)) >= cosmax:
                continue
        keep[k] = True
        stack.append((i, k))
        stack.append((k, j))
    return P[keep]


def edge_points(e, tol: float, angle: float) -> np.ndarray:
    """The edge's sample points from its start to its end (cached by its geometry)."""
    key, flip = _edge_key(e, tol, angle)
    got = _EDGES.get(key)
    if got is None:
        kind = str(e.geom_type).lower()
        if kind == "line":
            P = np.array([_pt(e, 0.0), _pt(e, 1.0)])
        elif kind == "circle":
            P = None
            try:
                r = float(e.radius)
                arc = float(e.length) / max(r, 1e-300)
                c = np.asarray(tuple(e.arc_center)[:3], dtype=float)
            except Exception:
                r, arc, c = 0.0, 0.0, None
            if r > 0 and arc > 0 and c is not None:
                step = angle
                if tol < r:
                    step = min(step, 2.0 * math.acos(max(-1.0, 1.0 - tol / r)))
                n = min(4096, max(2, int(math.ceil(arc / max(step, 1e-6)))))
                s0 = _pt(e, 0.0) - c
                q = _pt(e, 0.25) - c                     # a quarter of the way: never opposite s0
                ax = np.cross(s0, q)
                la = float(np.linalg.norm(ax))
                if la > 1e-12 * r * r:
                    ax /= la
                    s1 = np.cross(ax, s0)
                    ph = np.linspace(0.0, arc, n + 1)
                    P = c + np.outer(np.cos(ph), s0) + np.outer(np.sin(ph), s1)
                    P[-1] = _pt(e, 1.0)
                    P[0] = s0 + c
                    if float(np.linalg.norm(P[n // 2] - _pt(e, (n // 2) / n))) > max(tol * 0.01, 1e-9 * r):
                        P = None                         # not the circle we think: sample it
            if P is None:
                P = fast_points(e, np.linspace(0.0, 1.0, 129))
                P = _greedy(P, tol, angle)
        else:
            try:
                L = float(e.length)
            except Exception:
                L = 0.0
            dense = int(min(2049, max(129, L / max(tol, 1e-12) * 0.25)))
            P = fast_points(e, np.linspace(0.0, 1.0, dense))
            P = _greedy(P, tol, angle)
        got = P[::-1].copy() if flip else P
        _put(_EDGES, key, got, _MAX_EDGES)
    else:
        _EDGES.move_to_end(key)
    return got[::-1] if flip else got


# ----------------------------------------------------------------------------- loops

def _snap(P, verts, eps):
    """The run's two ends replaced by the body's vertex they are at (bit for bit the same point
    in every face, whichever edge brought it)."""
    if verts is None or not len(verts):
        return P
    P = P.copy()
    for k in (0, -1):
        q = verts - P[k]
        d = np.einsum("ij,ij->i", q, q)
        j = int(np.argmin(d))
        if d[j] <= eps * eps:
            P[k] = verts[j]
    return P


def _loops(face, tol, angle, scale, verts=None):
    """The face's boundary loops as (k, 3) point arrays (no repeated closing point)."""
    out = []
    eps = max(scale * 1e-7, 1e-9)
    for w in face.wires():
        edges = [e for e in w.edges()]
        runs = []
        fixed = []
        lens = []
        for e in edges:
            try:
                lens.append(float(e.length))
            except Exception:
                lens.append(0.0)
        total = sum(lens)
        acc = 0.0
        for e, L in zip(edges, lens):
            P = _snap(edge_points(e, tol, angle), verts, max(tol, eps * 100))
            closed = len(P) > 2 and float(np.linalg.norm(P[-1] - P[0])) <= eps
            if closed and len(edges) > 1 and total > 0:
                # which way the loop runs through a closed edge (a seam loop goes round twice,
                # once each way): ask the wire itself
                wp = np.asarray(tuple(w.point_at((acc + 0.6 * L) / total))[:3], dtype=float)
                fwd = float(np.linalg.norm(wp - _pt(e, 0.6))) <= float(np.linalg.norm(wp - _pt(e, 0.4)))
                if not fwd:
                    P = P[::-1]
            acc += L
            if len(P) >= 2 and float(np.linalg.norm(P[-1] - P[0])) + float(np.sum(np.linalg.norm(np.diff(P, axis=0), axis=1))) > eps:
                runs.append(P)
                fixed.append(closed)
        if not runs:
            continue
        if len(runs) == 1:
            P = runs[0]
            if float(np.linalg.norm(P[-1] - P[0])) > eps * 10:
                raise Unsupported("open loop")
            out.append(P[:-1])
            continue
        # orient the first run so it ends where another run begins or ends
        first = runs[0]
        rest = runs[1:]

        def touches(p, R):
            return min(float(np.linalg.norm(R[0] - p)), float(np.linalg.norm(R[-1] - p)))

        if not fixed[0] and min(touches(first[-1], R) for R in rest) > min(touches(first[0], R) for R in rest):
            first = first[::-1]
        chain = [first]
        end = first[-1]
        pool = list(zip(rest, fixed[1:]))
        while pool:
            best, bd, flip = None, None, False
            for k, (R, fx) in enumerate(pool):
                d0 = float(np.linalg.norm(R[0] - end))
                d1 = float(np.linalg.norm(R[-1] - end))
                if fx:
                    d1 = np.inf
                if bd is None or min(d0, d1) < bd:
                    best, bd, flip = k, min(d0, d1), d1 < d0
            if bd > max(eps * 1e3, tol * 0.5):
                raise Unsupported("loop does not close")
            R, _fx = pool.pop(best)
            R = R[::-1] if flip else R
            chain.append(R[1:])
            end = R[-1]
        if float(np.linalg.norm(end - chain[0][0])) > max(eps * 1e3, tol * 0.5):
            raise Unsupported("loop does not close")
        P = np.concatenate(chain)[:-1]
        if len(P) >= 3:
            out.append(P)
    if not out:
        raise Unsupported("no loops")
    return out


# ----------------------------------------------------------------------------- surfaces

class _Surface:
    """Maps 3D points to the surface's parameters (scaled to be roughly arc length) and back."""

    kind = "generic"

    def loops_uv(self, loops):
        return [self.to_uv(P) for P in loops]

    def to_uv(self, P):
        raise NotImplementedError

    def eval(self, UV):
        raise NotImplementedError

    def normals(self, UV):
        h = self.fd
        Pu = self.eval(UV + [h, 0.0]) - self.eval(UV - [h, 0.0])
        Pv = self.eval(UV + [0.0, h]) - self.eval(UV - [0.0, h])
        N = np.cross(Pu, Pv)
        L = np.linalg.norm(N, axis=1, keepdims=True)
        return N / np.maximum(L, 1e-300), L[:, 0]


class _Plane(_Surface):
    kind = "plane"

    def __init__(self, info):
        pl = info["placement"]
        self.o = np.asarray(pl["origin"], dtype=float)
        self.x = np.asarray(pl["x_dir"], dtype=float)
        self.y = np.asarray(pl["y_dir"], dtype=float)
        self.n = np.cross(self.x, self.y)

    def to_uv(self, P):
        d = P - self.o
        return np.c_[d @ self.x, d @ self.y]

    def eval(self, UV):
        return self.o + np.outer(UV[:, 0], self.x) + np.outer(UV[:, 1], self.y)

    def normals(self, UV):
        return np.tile(self.n, (len(UV), 1)), np.ones(len(UV))

    def steps(self, lo, span, tol, angle):
        return np.array([1.0, 1.0])


class _Cone(_Surface):
    """Cylinders and cones: (r_ref * angle, height)."""
    kind = "cone"

    def __init__(self, info, ref_point):
        pl = info["placement"]
        self.o = np.asarray(pl["origin"], dtype=float)
        self.x = np.asarray(pl["x_dir"], dtype=float)
        self.y = np.asarray(pl["y_dir"], dtype=float)
        self.z = np.asarray(pl["z_dir"], dtype=float)
        self.r0 = float(info["radius"])
        self.t = math.tan(math.radians(float(info.get("semi_angle_deg", 0.0) or 0.0)))
        self.a0 = None
        self.R = max(abs(self.r0), 1e-9)
        self.fd = 1e-6 * self.R

    def loops_uv(self, loops):
        """Angles unwrapped point by point along each loop (a face with a seam becomes a
        rectangle); inner loops moved by whole turns next to the first loop."""
        out = []
        base = None
        for P in loops:
            d = P - self.o
            a = np.unwrap(np.arctan2(d @ self.y, d @ self.x))
            if base is None:
                base = 0.5 * (a.min() + a.max())
            else:
                a = a - 2.0 * math.pi * round((0.5 * (a.min() + a.max()) - base) / (2.0 * math.pi))
            h = d @ self.z
            if self.t != 0.0 and np.any(np.abs(self._radius(h)) < 1e-9 * self.R):
                raise Unsupported("cone apex")
            out.append(np.c_[a * self.R, h])
        return out

    def _radius(self, h):
        return self.r0 + h * self.t

    def normals(self, UV):
        a = UV[:, 0] / self.R
        N = np.cos(a)[:, None] * self.x + np.sin(a)[:, None] * self.y - self.t * self.z
        N /= np.linalg.norm(N, axis=1, keepdims=True)
        return N, np.ones(len(UV))

    def steps(self, lo, span, tol, angle):
        da = span[0] / self.R
        rmax = max(abs(self._radius(lo[1])), abs(self._radius(lo[1] + span[1])), 1e-300)
        step = angle
        if tol < rmax:
            step = min(step, 2.0 * math.acos(max(-1.0, 1.0 - tol / rmax)))
        n = math.ceil(da / max(step, 1e-6) - 1e-9)
        return np.array([float(max(1, min(512, n))), 1.0])

    def to_uv(self, P):
        d = P - self.o
        a = np.arctan2(d @ self.y, d @ self.x)
        a = self.a0 + (a - self.a0) % (2.0 * math.pi)
        h = d @ self.z
        if self.t != 0.0 and np.any(np.abs(self._radius(h)) < 1e-9 * self.R):
            raise Unsupported("cone apex")
        return np.c_[a * self.R, h]

    def eval(self, UV):
        a = UV[:, 0] / self.R
        h = UV[:, 1]
        r = self._radius(h)
        return self.o + (r * np.cos(a))[:, None] * self.x + (r * np.sin(a))[:, None] * self.y + h[:, None] * self.z


class _Sphere(_Surface):
    """Azimuthal equidistant map about the face's middle point: no pole on any face smaller than
    the whole sphere."""
    kind = "sphere"

    def __init__(self, info, ref_point):
        pl = info["placement"]
        self.o = np.asarray(pl["origin"], dtype=float)
        self.r = float(info["radius"])
        self.ref = np.asarray(ref_point, dtype=float)
        self._frame(self.ref - self.o)
        self.fd = 1e-6 * self.r

    def _frame(self, c):
        c = np.asarray(c, dtype=float)
        c = c / max(float(np.linalg.norm(c)), 1e-300)
        a = np.array([1.0, 0.0, 0.0]) if abs(c[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
        self.e1 = np.cross(c, a)
        self.e1 /= np.linalg.norm(self.e1)
        self.e2 = np.cross(c, self.e1)
        self.c = c

    def loops_uv(self, loops):
        """Center the map on the face: on the side of the boundary the face lies (a sphere with a
        bite taken out is mapped from the far side of the bite)."""
        B = np.concatenate(loops) - self.o
        D = B / np.maximum(np.linalg.norm(B, axis=1, keepdims=True), 1e-300)
        m = D.mean(axis=0)
        p = self.ref - self.o
        p = p / max(float(np.linalg.norm(p)), 1e-300)
        cands = [p]
        if float(np.linalg.norm(m)) > 1e-6:
            mn = m / float(np.linalg.norm(m))
            cands += [mn, -mn]
        best = min(cands, key=lambda c: float(np.max(np.arccos(np.clip(D @ c, -1.0, 1.0)))))
        if float(np.max(np.arccos(np.clip(D @ best, -1.0, 1.0)))) > math.radians(150.0):
            raise Unsupported("sphere face wrapping too far round")
        self._frame(best)
        return [self.to_uv(P) for P in loops]

    def to_uv(self, P):
        d = P - self.o
        d /= np.maximum(np.linalg.norm(d, axis=1, keepdims=True), 1e-300)
        x, y, z = d @ self.e1, d @ self.e2, d @ self.c
        th = np.arctan2(np.hypot(x, y), z)
        if np.any(th > math.pi - 1e-6):
            raise Unsupported("sphere face around its antipode")
        ph = np.arctan2(y, x)
        return np.c_[th * np.cos(ph), th * np.sin(ph)] * self.r

    def normals(self, UV):
        N = (self.eval(UV) - self.o) / self.r
        return N, np.ones(len(UV))

    def steps(self, lo, span, tol, angle):
        step = angle
        if tol < self.r:
            step = min(step, 2.0 * math.acos(max(-1.0, 1.0 - tol / self.r)))
        return np.array([float(max(1, min(512, math.ceil(span[k] / self.r / step)))) for k in (0, 1)])

    def eval(self, UV):
        q = UV / self.r
        th = np.linalg.norm(q, axis=1)
        s = np.where(th > 1e-300, np.sin(th) / np.maximum(th, 1e-300), 1.0)
        return self.o + self.r * (np.cos(th)[:, None] * self.c + (s * q[:, 0])[:, None] * self.e1
                                  + (s * q[:, 1])[:, None] * self.e2)


class _Generic(_Surface):
    """Any surface, through the face's own fractions (uv_at / position_at), scaled by the lengths
    of its middle iso curves."""

    def __init__(self, face):
        self.f = face
        mid = [tuple(face.position_at(t, 0.5))[:3] for t in np.linspace(0, 1, 9)]
        mid2 = [tuple(face.position_at(0.5, t))[:3] for t in np.linspace(0, 1, 9)]
        self.Lu = max(float(np.sum(np.linalg.norm(np.diff(np.asarray(mid), axis=0), axis=1))), 1e-9)
        self.Lv = max(float(np.sum(np.linalg.norm(np.diff(np.asarray(mid2), axis=0), axis=1))), 1e-9)
        self.fd = 1e-6 * max(self.Lu, self.Lv)
        # periodic directions: the surface meets itself across the domain
        self.periodic = [False, False]
        try:
            gap = max(self.Lu, self.Lv) * 1e-7
            for axis in (0, 1):
                same = True
                for w in (0.1, 0.5, 0.9):
                    a = face.position_at(0.0, w) if axis == 0 else face.position_at(w, 0.0)
                    b = face.position_at(1.0, w) if axis == 0 else face.position_at(w, 1.0)
                    if float(np.linalg.norm(np.asarray(tuple(a)[:3]) - np.asarray(tuple(b)[:3]))) > gap:
                        same = False
                        break
                self.periodic[axis] = same
        except Exception:
            pass

    def to_uv(self, P):
        uv = np.array([self.f.uv_at(tuple(p)) for p in P], dtype=float)
        return np.c_[uv[:, 0] * self.Lu, uv[:, 1] * self.Lv]

    def loops_uv(self, loops):
        out = []
        base = None
        for P in loops:
            uv = np.array([self.f.uv_at(tuple(p)) for p in P], dtype=float)
            # points on the surface's own border sit exactly on it (in line along an iso border)
            uv = np.where(np.abs(uv) < 1e-7, 0.0, uv)
            uv = np.where(np.abs(uv - 1.0) < 1e-7, 1.0, uv)
            for axis in (0, 1):
                if self.periodic[axis]:
                    uv[:, axis] = np.unwrap(uv[:, axis], period=1.0)
            if base is None:
                base = 0.5 * (uv.min(axis=0) + uv.max(axis=0))
            else:
                mid = 0.5 * (uv.min(axis=0) + uv.max(axis=0))
                for axis in (0, 1):
                    if self.periodic[axis]:
                        uv[:, axis] -= round(float(mid[axis] - base[axis]))
            out.append(np.c_[uv[:, 0] * self.Lu, uv[:, 1] * self.Lv])
        return out

    def _wrap(self, UV):
        u = UV[:, 0] / self.Lu
        v = UV[:, 1] / self.Lv
        u = np.mod(u, 1.0) if self.periodic[0] else np.clip(u, 0.0, 1.0)
        v = np.mod(v, 1.0) if self.periodic[1] else np.clip(v, 0.0, 1.0)
        return u, v

    def eval(self, UV):
        u, v = self._wrap(UV)
        return np.array([tuple(self.f.position_at(float(a), float(b)))[:3] for a, b in zip(u, v)], dtype=float)

    def normals(self, UV):
        # one-sided differences at the domain's border
        h = self.fd
        lo = np.array([-np.inf if self.periodic[0] else 0.0, -np.inf if self.periodic[1] else 0.0])
        hi = np.array([np.inf if self.periodic[0] else self.Lu, np.inf if self.periodic[1] else self.Lv])
        a = np.clip(UV + [h, 0.0], lo, hi)
        b = np.clip(UV - [h, 0.0], lo, hi)
        c = np.clip(UV + [0.0, h], lo, hi)
        d = np.clip(UV - [0.0, h], lo, hi)
        Pu = self.eval(a) - self.eval(b)
        Pv = self.eval(c) - self.eval(d)
        N = np.cross(Pu, Pv)
        L = np.linalg.norm(N, axis=1, keepdims=True)
        return N / np.maximum(L, 1e-300), L[:, 0]


def _surface(face):
    kind = str(face.geom_type).lower()
    try:
        info = face._surface_info()
    except Exception:
        info = {}
    try:
        ref = tuple(face.interior_point())[:3]
    except Exception:
        try:
            ref = tuple(face.position_at(0.5, 0.5))[:3]
        except Exception:
            ref = tuple(face.center())[:3]
    try:
        if kind == "plane" and "placement" in info:
            return _Plane(info), info
        if kind in ("cylinder", "cone") and "radius" in info and "placement" in info:
            return _Cone(info, ref), info
        if kind == "sphere" and "radius" in info and "placement" in info:
            return _Sphere(info, ref), info
    except Unsupported:
        raise
    except Exception:
        pass
    return _Generic(face), info


# ----------------------------------------------------------------------------- one face

def _cdt(UV, loops_idx, extra):
    pts = [tuple(p) for p in UV] + [tuple(p) for p in extra]
    r = delaunay_2d_cdt(pts, [], loops_idx, 1, 1e-12 * max(1.0, float(np.abs(UV).max())), True)
    verts = np.asarray([tuple(v) for v in r[0]], dtype=float)
    keep = [i for i, o in enumerate(r[5]) if len(o) % 2 == 1]
    tris = [r[2][i] for i in keep]
    if any(len(t) != 3 for t in tris):
        raise Unsupported("not triangles")
    orig = [o[0] if o else -1 for o in r[3]]
    return verts, np.asarray(tris, dtype=np.int64).reshape(-1, 3), orig


def mesh_face(face, tol: float, angle: float, scale: float, verts=None):
    """(vertices (k, 3), triangles (m, 3), corner normals (m, 3, 3)) of one face."""
    loops = _loops(face, tol, angle, scale, verts)
    sig = hashlib.sha1()
    for P in loops:
        sig.update(P.tobytes())
    surf, info = _surface(face)
    sig.update(repr(sorted((k, repr(v)) for k, v in info.items())).encode())
    if surf.kind == "generic":
        try:
            sig.update(repr(face.nurbs()).encode())
        except Exception:
            sig.update(str(id(face)).encode())
    key = (sig.hexdigest(), tol, angle)
    got = _FACES.get(key)
    if got is not None:
        _FACES.move_to_end(key)
        stats["reused"] += 1
        return got
    stats["faces"] += 1

    UVs = surf.loops_uv(loops)
    B = np.concatenate(loops)
    UVb = np.concatenate(UVs)
    if surf.kind == "generic":
        step = max(1, len(UVb) // 16)
        back = surf.eval(UVb[::step])
        if float(np.max(np.linalg.norm(back - B[::step], axis=1))) > max(10 * tol, scale * 1e-6):
            raise Unsupported("the face's points do not map to its parameters")
    nb = len(B)
    lo, hi = UVb.min(axis=0), UVb.max(axis=0)
    span = np.maximum(hi - lo, 1e-12)

    # Steps the tolerance needs along each direction (1 where the surface is straight that way):
    # the Delaunay works in coordinates where one step is one unit, so a straight direction
    # collapses and the triangles run straight across it.
    if surf.kind == "plane":
        steps = np.array([1.0, 1.0])
        metric = np.array([1.0, 1.0])
    elif hasattr(surf, "steps"):
        steps = surf.steps(lo, span, tol, angle)
        metric = steps / span
    else:
        steps = np.ones(2)
        for axis in (0, 1):
            m = 9
            g = np.linspace(0.0, 1.0, m)
            worst = 1.0
            for across in (0.15, 0.5, 0.85):
                gu_ = g if axis == 0 else np.full(m, across)
                gv_ = g if axis == 1 else np.full(m, across)
                line = np.c_[lo[0] + gu_ * span[0], lo[1] + gv_ * span[1]]
                N, _ = surf.normals(line)
                turn = float(np.sum(np.arccos(np.clip(np.sum(N[1:] * N[:-1], axis=1), -1, 1))))
                P = surf.eval(line)
                L = float(np.sum(np.linalg.norm(np.diff(P, axis=0), axis=1)))
                k = turn / max(L, 1e-300)                      # mean curvature along the line
                n_ang = turn / max(angle, 1e-3)
                n_tol = L * math.sqrt(k / (8.0 * tol)) if k > 0 else 0.0
                worst = max(worst, n_ang, n_tol)
            steps[axis] = min(512.0, math.ceil(worst)) if worst > 1.0 + 1e-9 else 1.0
        metric = steps / span
    UVm = (UVb - lo) * metric
    loops_idx = []
    k = 0
    for P in loops:
        idx = list(range(k, k + len(P)))
        uv = UVm[k:k + len(P)]
        area = 0.5 * float(np.sum(uv[:, 0] * np.roll(uv[:, 1], -1) - np.roll(uv[:, 0], -1) * uv[:, 1]))
        if not abs(area) > 1e-14 * max(1.0, float(np.abs(uv).max())) ** 2:
            raise Unsupported("a loop without area in the face's parameters")
        loops_idx.append(idx if area > 0 else idx[::-1])
        k += len(P)

    # seed points only where the surface bends both ways (spheres, tori, free-form)
    extra = np.zeros((0, 2))
    if steps[0] > 1 and steps[1] > 1:
        gu = np.arange(1, int(steps[0])) + 0.0
        gv = np.arange(1, int(steps[1])) + 0.0
        extra = np.array(np.meshgrid(gu, gv)).reshape(2, -1).T
        # keep clear of the boundary (a seed on a boundary segment would split it)
        extra = extra + 0.37e-3

    def to_param(M):
        return M / metric + lo

    cosmax = math.cos(min(angle * 1.5, 0.5 * math.pi))
    for _round in range(10):
        verts, tris, orig = _cdt(UVm, loops_idx, extra)
        if surf.kind == "plane" or not len(tris):
            break
        cent = verts[tris].mean(axis=1)
        # slivers along the boundary (three boundary points almost in line) cannot be helped by a
        # point inside them, and their only error is the boundary's own chord
        e0 = verts[tris[:, 1]] - verts[tris[:, 0]]
        e1 = verts[tris[:, 2]] - verts[tris[:, 0]]
        e2 = verts[tris[:, 2]] - verts[tris[:, 1]]
        a2 = np.abs(e0[:, 0] * e1[:, 1] - e0[:, 1] * e1[:, 0])
        longest = np.maximum.reduce([np.einsum("ij,ij->i", e, e) for e in (e0, e1, e2)])
        sliver = a2 < 1e-3 * longest
        P3 = surf.eval(to_param(verts))
        for i_, o in enumerate(orig):
            if 0 <= o < nb:
                P3[i_] = B[o]
        flat = P3[tris].mean(axis=1)
        dev = np.linalg.norm(surf.eval(to_param(cent)) - flat, axis=1)
        Nv, _ = surf.normals(to_param(verts))
        Nt = Nv[tris]
        bend = np.minimum.reduce([np.sum(Nt[:, 0] * Nt[:, 1], axis=1), np.sum(Nt[:, 1] * Nt[:, 2], axis=1),
                                  np.sum(Nt[:, 0] * Nt[:, 2], axis=1)])
        bad = ((dev > tol) | (bend < cosmax)) & ~sliver
        if not np.any(bad):
            break
        if _round == 9 and float(np.max(np.where(sliver, 0.0, dev))) > 4.0 * tol:
            raise Unsupported("the triangles do not settle onto the surface")
        add = cent[bad]
        extra = np.vstack([extra, add]) if len(extra) else add
    verts = to_param(verts)

    if not len(tris):
        raise Unsupported("no triangles")
    # 3D points: the exact boundary samples where the triangulation kept them
    P3 = surf.eval(verts)
    for i, o in enumerate(orig):
        if 0 <= o < nb:
            P3[i] = B[o]
    N, _ = surf.normals(verts)
    # outward: the face's own normal at the middle of its largest triangle
    tri_n = np.cross(P3[tris[:, 1]] - P3[tris[:, 0]], P3[tris[:, 2]] - P3[tris[:, 0]])
    big = int(np.argmax(np.linalg.norm(tri_n, axis=1)))
    cu = verts[tris[big]].mean(axis=0)
    cp = surf.eval(cu[None])[0]
    n_out = np.asarray(tuple(face.normal_at(tuple(cp)))[:3], dtype=float)
    n_c, _ = surf.normals(cu[None])
    if float(n_c[0] @ n_out) < 0:
        N = -N
    tri_n = np.cross(P3[tris[:, 1]] - P3[tris[:, 0]], P3[tris[:, 2]] - P3[tris[:, 0]])
    area2 = np.linalg.norm(tri_n, axis=1)
    good = area2 > 1e-300
    tris = tris[good]
    tri_n = tri_n[good]
    flip = np.sum(tri_n * N[tris].mean(axis=1), axis=1) < 0
    tris[flip] = tris[flip][:, [0, 2, 1]]
    used, local = np.unique(tris, return_inverse=True)
    V = P3[used]
    T = local.reshape(-1, 3)
    NC = N[used][T]
    # the triangles must cover exactly the region inside the loops (in the face's parameters)
    uvt = verts[tris]
    tri_area = 0.5 * float(np.sum(np.abs((uvt[:, 1, 0] - uvt[:, 0, 0]) * (uvt[:, 2, 1] - uvt[:, 0, 1])
                                         - (uvt[:, 2, 0] - uvt[:, 0, 0]) * (uvt[:, 1, 1] - uvt[:, 0, 1]))))
    k = 0
    signed = []
    for P in loops:
        uv = UVb[k:k + len(P)]
        k += len(P)
        signed.append(abs(0.5 * float(np.sum(uv[:, 0] * np.roll(uv[:, 1], -1) - np.roll(uv[:, 0], -1) * uv[:, 1]))))
    region = max(signed) - (sum(signed) - max(signed))
    if not abs(tri_area - region) <= 1e-6 * max(region, 1e-300) + 1e-9 * float(np.prod(span)):
        raise Unsupported(f"the triangles cover {tri_area:.6g}, the loops {region:.6g}")
    got = (V, T, NC)
    _put(_FACES, key, got, _MAX_FACES)
    return got


# ----------------------------------------------------------------------------- bodies

def tessellate(shape, tol: float, angle_deg: float):
    """(vertices, triangles, corner normals, face ids) of a whole body, or raise Unsupported."""
    if delaunay_2d_cdt is None:
        raise Unsupported("no triangulator here")
    if type(shape).__name__ not in ("Part", "Shell"):
        raise Unsupported(f"a {type(shape).__name__}")
    angle = math.radians(angle_deg)
    try:
        bb = shape._loose_box()
        scale = float(np.linalg.norm(np.asarray(tuple(bb.max)) - np.asarray(tuple(bb.min))))
    except Exception:
        scale = 1.0
    try:
        vx = np.array([tuple(v)[:3] for v in shape.vertices()], dtype=float).reshape(-1, 3)
    except Exception:
        vx = None
    verts, tris, norms, owners = [], [], [], []
    off = 0
    for fi, f in enumerate(shape.faces()):
        try:
            V, T, NC = mesh_face(f, tol, angle, scale, vx)
        except Unsupported:
            raise
        except Exception as ex:
            raise Unsupported(f"face {fi}: {type(ex).__name__}: {ex}") from ex
        verts.append(V)
        tris.append(T + off)
        norms.append(NC)
        owners.append(np.full(len(T), fi, dtype=np.int64))
        off += len(V)
    if not verts:
        raise Unsupported("no faces")
    V = np.concatenate(verts)
    T = np.concatenate(tris)
    # share the points where faces meet (they are the same samples, bit for bit)
    Vu, inv = np.unique(V, axis=0, return_inverse=True)
    T = inv.reshape(-1)[T]
    return Vu, T, np.concatenate(norms), np.concatenate(owners)
