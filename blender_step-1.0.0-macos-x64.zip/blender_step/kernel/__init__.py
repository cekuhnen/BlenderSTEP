"""The kernel layer: the only package that talks to smlibpy (NVIDIA's SMLib kernel).

Everything above this package works with opaque shapes, blobs (str) and numpy arrays, so the
kernel can later move into a separate process without touching tools or UI.
"""
