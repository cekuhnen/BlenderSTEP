"""Thin, stable wrapper over smlibpy.

Rules:
- Shapes are immutable values. Every operation returns a new shape.
- Every failure is raised as CadError with the kernel's own (human-readable) message.
- Face and edge ids are indices into shape.faces() / shape.edges(); they are valid for one
  shape value only. A new shape means new ids.
"""

from __future__ import annotations

import base64
import math
import hashlib
import zlib
from dataclasses import dataclass

import numpy as np

try:
    import smlibpy as _s
    from smlibpy.mesh import _tessellate as _tess_keep  # private: keeps kernel mesh for face ids
    from smlibpy.mesh import _triangle_faces
    IMPORT_ERROR = None
except Exception as ex:  # pragma: no cover - reported in the UI
    _s = None
    IMPORT_ERROR = ex


class CadError(Exception):
    """A modeling operation the kernel rejected; the message says why."""


class FilletRuleError(CadError):
    """A fillet option that does not fit the picked edges (no corner to mitre or set back, a
    setback out of range): no point searching for a smaller radius."""


def available() -> bool:
    return _s is not None


def version() -> str:
    if _s is None:
        return "unavailable"
    try:
        from importlib.metadata import version as v
        return v("smlibpy")
    except Exception:
        return "?"


def _call(what, fn, *args, **kwargs):
    if _s is None:
        raise CadError(f"SMLib kernel not available: {IMPORT_ERROR}")
    try:
        out = fn(*args, **kwargs)
    except CadError:
        raise
    except Exception as ex:
        msg = str(ex).strip() or type(ex).__name__
        raise CadError(f"{what}: {msg}" if not msg.startswith(what) else msg) from ex
    return out


# ----------------------------------------------------------------------------- blobs

def to_blob(shape) -> str:
    """Exact shape -> compact text (zlib-compressed binary .smb, base64)."""
    raw = _call("save", _s.to_smb, shape, ascii=False)
    return base64.b64encode(zlib.compress(raw, 6)).decode("ascii")


def from_blob(blob: str):
    raw = zlib.decompress(base64.b64decode(blob))
    return _call("load", _s.from_smb, raw)


def blob_hash(blob: str) -> str:
    return hashlib.sha1(blob.encode("ascii")).hexdigest()


# ----------------------------------------------------------------------------- primitives

def box(x: float, y: float, z: float):
    return _call("box", _s.Box, x, y, z)


def cylinder(radius: float, height: float):
    return _call("cylinder", _s.Cylinder, radius, height)


def sphere(radius: float):
    return _call("sphere", _s.Sphere, radius)


def torus(major: float, minor: float):
    return _call("torus", _s.Torus, major, minor)


def cone(bottom: float, top: float, height: float):
    return _call("cone", _s.Cone, bottom, top, height)


# ----------------------------------------------------------------------------- placement

def moved(shape, matrix4x4) -> object:
    """Apply a rigid 4x4 matrix (rotation + translation only)."""
    m = np.asarray(matrix4x4, dtype=float)
    return _call("move", shape.moved, _s.Location(m))


# ----------------------------------------------------------------------------- queries

def face_count(shape) -> int:
    return len(shape.faces())


def edge_count(shape) -> int:
    return len(shape.edges())


def is_solid(shape) -> bool:
    return isinstance(shape, _s.Part)


def describe(shape) -> str:
    kind = "Solid" if is_solid(shape) else "Surface"
    return f"{kind}: {face_count(shape)} faces, {edge_count(shape)} edges"


def volume(shape) -> float:
    try:
        return float(shape.volume)
    except Exception:
        return 0.0


def _faces(shape, ids):
    faces = shape.faces()
    try:
        return [faces[i] for i in ids]
    except IndexError:
        raise CadError("selection is out of date; select the faces again")


def _edges(shape, ids):
    edges = shape.edges()
    try:
        return [edges[i] for i in ids]
    except IndexError:
        raise CadError("selection is out of date; select the edges again")


def edge_face_pairs(shape) -> list[tuple[int, int]]:
    """For each edge (shape.edges() order), the ids of the two faces meeting there, sorted.
    (-1, -1) for edges with fewer or more than two faces."""
    faces = shape.faces()
    out = []
    for e in shape.edges():
        try:
            adj = list(e.faces())
        except Exception:
            adj = []
        idx = []
        for f in adj:
            i = next((k for k, g in enumerate(faces) if g == f), None)
            if i is not None:
                idx.append(i)
        out.append(tuple(sorted(idx)) if len(idx) == 2 else (-1, -1))
    return out


def tangent_chain(shape, edge_id: int) -> list[int]:
    """Ids of the edges tangent-continuous with edge_id (fillet chains)."""
    edges = shape.edges()
    chain = _call("chain", edges[edge_id].tangent_chain)
    centers = np.array([tuple(e.center()) for e in edges])
    out = []
    for e in chain:
        c = np.array(tuple(e.center()))
        out.append(int(np.argmin(np.linalg.norm(centers - c, axis=1))))
    return sorted(set(out))


# ----------------------------------------------------------------------------- features

_EDGE_MAX: dict = {}   # (shape key, edges, kind) -> largest value known to work (for quick refusals)


def _shape_key(shape):
    try:
        b = shape.bbox()
        return (type(shape).__name__, len(shape.faces()), len(shape.edges()),
                tuple(round(float(x), 9) for x in tuple(b.min) + tuple(b.max)))
    except Exception:
        return (id(shape),)


def _largest(run, value: float, steps: int = 7, budget: float = 4.0):
    """The largest value in (0, value) for which run(v) works (bisection, at most `budget` seconds),
    or 0.0."""
    import time
    t0 = time.monotonic()
    lo, hi = 0.0, float(value)
    for _ in range(steps):
        if time.monotonic() - t0 > budget:
            break
        mid = 0.5 * (lo + hi)
        try:
            run(mid)
            lo = mid
        except Exception:
            hi = mid
    return lo


def round_limit(shape, edge_ids, samples: int = 24):
    """The largest round the picked edges can take before the round runs over itself: where an edge
    bends towards the inside of one of its faces with a radius rho, the round's contact line on that
    face (r into the face) folds back at r = rho. (Past that the kernel either fails or returns a
    round that crosses itself: the waves.) None when nothing limits it.

    (Quick: the points along each edge by its own parameter, and which way is into each face found
    once per edge and face, not at every point: a distance to a free-form face takes a millisecond.)"""
    try:
        edges = _edges(shape, edge_ids)
    except CadError:
        return None
    best = None
    for e in edges:
        if str(e.geom_type).lower() == "line":
            continue
        try:
            faces = list(e.faces())
        except Exception:
            continue
        if not faces:
            continue
        L = max(float(e.length), 1e-12)
        h = 2e-4
        ts = np.linspace(0.0, 1.0, samples * 4 + 1)
        tc = np.clip(ts, h, 1.0 - h)                  # the difference stencil stays on the edge
        try:
            P1 = _fast_points(e, ts)
            P0 = _fast_points(e, tc - h)
            PC = _fast_points(e, tc)
            P2 = _fast_points(e, tc + h)
        except Exception:
            continue
        D1 = (P2 - P0) / (2 * h)
        D2 = (P2 - 2 * PC + P0) / (h * h)
        side = {}                                     # face -> +1 / -1: n x T points into it
        for k in range(len(ts)):
            sp = float(np.linalg.norm(D1[k]))
            if sp < 1e-12:
                continue
            T = D1[k] / sp
            kv = (D2[k] - float(np.dot(D2[k], T)) * T) / (sp * sp)   # curvature vector (towards the centre)
            kn = float(np.linalg.norm(kv))
            if kn * L < 1e-9:
                continue
            p1 = P1[k]
            for fi, f in enumerate(faces):
                try:
                    n = _unit(f.normal_at(tuple(p1)))
                except Exception:
                    continue
                m = np.cross(n, T)
                if float(np.linalg.norm(m)) < 1e-9:
                    continue
                m = _unit(m)
                if fi not in side:
                    eps = L * 1e-3
                    try:
                        side[fi] = -1.0 if float(f.distance_to(tuple(p1 + m * eps))) > float(
                            f.distance_to(tuple(p1 - m * eps))) else 1.0
                    except Exception:
                        continue
                m = m * side[fi]                       # into the face
                k_in = float(np.dot(kv, m))
                if k_in > 1e-12:
                    rho = 1.0 / k_in
                    best = rho if best is None else min(best, rho)
    return best


def _corner_rounds_apply(shape, edge_ids) -> bool:
    """True when every edge is straight between two flat faces of a solid (outside edges can then
    be rounded past their faces if need be)."""
    if not isinstance(shape, _s.Part):
        return False
    try:
        size = max(body_size(shape), 1e-12)
        for e in _edges(shape, edge_ids):
            kind = str(e.geom_type).lower()
            if kind == "line":
                fs = list(e.faces())
                if len(fs) != 2 or not all(bool(f.is_planar) for f in fs):
                    return False
            elif kind == "circle":
                if _circle_round_frame(shape, e, size * 1e-5) is None:
                    return False
            else:
                return False
    except Exception:
        return False
    return True


def _straight_round_tools(kind, shape, edge_ids, value):
    """Rounds (or bevels) of straight outside edges between two flat faces made the way Parasolid
    makes them when they outgrow their faces: the region between the two face planes and the
    round (a prism along the edge) is cut away. The faces
    the round reaches past simply give way: the round runs on into the faces beyond, and edges on
    one line with the same two planes become one round across any gap between them. Each end of a
    round stops where the edge ends against material, and runs on through empty space beyond.
    None when the edges are not all straight edges between two flat faces."""
    if not isinstance(shape, _s.Part) or value <= 0:
        return None
    try:
        edges = _edges(shape, edge_ids)
    except CadError:
        return None
    size = max(body_size(shape), 1e-12)
    delta = size * 1e-5
    groups = {}
    for e in edges:
        if str(e.geom_type).lower() != "line":
            return None
        try:
            fs = list(e.faces())
        except Exception:
            return None
        if len(fs) != 2 or not all(bool(f.is_planar) for f in fs):
            return None
        a, b = _vec(e.point_at(0.0)), _vec(e.point_at(1.0))
        d = _unit(b - a)
        mid = 0.5 * (a + b)
        us, ns = [], []
        for f in fs:
            n = _unit(f.normal_at(tuple(mid)))
            u = _unit(np.cross(n, d))
            try:
                if float(f.distance_to(tuple(mid + u * delta * 10))) > float(f.distance_to(tuple(mid - u * delta * 10))):
                    u = -u
            except Exception:
                return None
            us.append(u)
            ns.append(n)
        phi = math.acos(max(-1.0, min(1.0, float(np.dot(us[0], us[1])))))
        if phi < math.radians(1.0) or phi > math.radians(179.0):
            return None
        convex = float(np.dot(us[1], ns[0])) < 0.0
        if not convex:
            return None   # filling an inside corner past its faces would hang material in the air
        # the line and the two planes: edges sharing all three make one round
        if d[np.argmax(np.abs(d))] < 0:
            d = -d
        foot = a - np.dot(a, d) * d
        pl = sorted((tuple(np.round(n, 6)), round(float(np.dot(n, a)) / size, 6)) for n in ns)
        key = (tuple(np.round(d, 6)), tuple(np.round(foot / size, 6)), tuple(pl), convex)
        g = groups.setdefault(key, {"d": d, "foot": foot, "u": us, "n": ns, "phi": phi, "convex": convex,
                                    "s": []})
        g["s"] += [float(np.dot(a, d)), float(np.dot(b, d))]
    if not groups:
        return None
    tools = []
    for g in groups.values():
        d, u1, u2, phi = g["d"], g["u"][0], g["u"][1], g["phi"]
        s0, s1 = min(g["s"]), max(g["s"])
        K = g["foot"]                                   # the line's point at s = 0
        if kind == "fillet":
            t = value / math.tan(phi / 2.0)
            T1, T2 = K + t * u1, K + t * u2
            C = K + (value / math.sin(phi / 2.0)) * _unit(u1 + u2)
            M = C + value * _unit(K - C)
            rim = [T1, M, T2, 0.5 * (T1 + M), 0.5 * (T2 + M)]
        else:
            T1, T2 = K + value * u1, K + value * u2
            M = 0.5 * (T1 + T2)
            rim = [T1, M, T2]
        probes = [K + lam * (X - K) for X in rim for lam in (0.15, 0.5, 0.85)]

        def material(s):
            return any(bool(shape.contains(tuple(q + s * d))) for q in probes)

        def reach(s_end, sign):
            if material(s_end + sign * delta * 20):
                return 0.0                              # the edge ends against material
            step = max(min(value, size) / 4.0, size / 200.0)
            o = step
            while o < size * 1.5:
                if material(s_end + sign * o):
                    return max(o - step, delta * 20)    # stop in the gap before the next material
                o += step
            return size * 1.5

        lo = s0 - reach(s0, -1.0)
        hi = s1 + reach(s1, 1.0)
        # a round has to lie on faces: each tangent line must touch the part's material somewhere
        # (past that it would be a cut through the part, not a round; Parasolid refuses too)
        if kind == "fillet":
            n1, n2 = g["n"][0], g["n"][1]
            ss = np.linspace(lo, hi, 97)
            eps = delta * 10
            on1 = any(bool(shape.contains(tuple(T1 + s_ * d - eps * n1))) for s_ in ss)
            on2 = on1 and any(bool(shape.contains(tuple(T2 + s_ * d - eps * n2))) for s_ in ss)
            if not (on1 and on2):
                return None
        P = lambda X: tuple(X + lo * d)   # noqa: E731
        try:
            if kind == "fillet":
                w = _s.Wire([_s.Line(P(K), P(T1)), _s.ThreePointArc(P(T1), P(M), P(T2)), _s.Line(P(T2), P(K))])
            else:
                w = _s.Wire([_s.Line(P(K), P(T1)), _s.Line(P(T1), P(T2)), _s.Line(P(T2), P(K))])
            tool = _s.extrude(w, float(hi - lo), direction=tuple(d))
        except Exception as ex:
            raise CadError(f"{kind}: could not build the round past its faces ({ex})")
        tools.append(tool)
    return tools


def _circle_round_frame(shape, e, delta):
    """For a circular edge between a flat face and a cylinder around the same axis (a disk's rim):
    (axis origin at the circle, axis direction, e1, e2, radius, 2D in-face directions u1 (plane) and
    u2 (cylinder), convex) in the half-plane through the axis (coordinates: radius, height); or None."""
    try:
        fs = list(e.faces())
        if len(fs) != 2:
            return None
        pl = next((f for f in fs if str(f.geom_type).lower() == "plane"), None)
        cy = next((f for f in fs if str(f.geom_type).lower() == "cylinder"), None)
        if pl is None or cy is None:
            return None
        ax = cy.axis
        d = _unit(_vec(ax.direction))
        c = _vec(e.arc_center)
        r = float(e.radius)
        if abs(float(np.dot(_unit(pl.normal_at()), d))) < 1 - 1e-9 or abs(r - float(cy.radius)) > max(r, 1e-9) * 1e-7:
            return None
        o_ax = _vec(ax.origin)
        foot = o_ax + float(np.dot(c - o_ax, d)) * d
        if float(np.linalg.norm(foot - c)) > max(r, 1e-9) * 1e-7:
            return None
        e1 = _unit(_vec(e.point_at(0.0)) - c)
        e2 = np.cross(d, e1)
        m = _vec(e.point_at(0.5))
        rho = _unit(m - c)
        step = delta * 10
        u1 = np.array([-1.0, 0.0]) if float(pl.distance_to(tuple(m - rho * step))) <= float(
            pl.distance_to(tuple(m + rho * step))) else np.array([1.0, 0.0])
        u2 = np.array([0.0, -1.0]) if float(cy.distance_to(tuple(m - d * step))) <= float(
            cy.distance_to(tuple(m + d * step))) else np.array([0.0, 1.0])
        n1 = np.array([0.0, 1.0 if float(np.dot(_unit(pl.normal_at(tuple(m))), d)) > 0 else -1.0])
        convex = float(np.dot(u2, n1)) < 0.0
        return c, d, e1, e2, r, u1, u2, convex
    except Exception:
        return None


def _circle_round_tools(kind, shape, edge_ids, value):
    """Rounds (or bevels) of circular outside edges between a flat face and a cylinder around the
    same axis, made by revolving the corner region (between the two faces and the round) about the
    axis: each end runs on through empty space (a notch cut through the rim) and stops before the
    next material, so the round ends against the notch walls, as Parasolid ends it. Arcs of one
    circle that meet (a rim split at the cylinder's seam) are one round, the picked ones and the
    ones they run on into. None when an edge is not such an edge."""
    if not isinstance(shape, _s.Part) or value <= 0:
        return None
    try:
        edges = _edges(shape, edge_ids)
    except CadError:
        return None
    size = max(body_size(shape), 1e-12)
    delta = size * 1e-5
    tol = size * 1e-7
    two_pi = 2 * math.pi
    # ---- the circles: (frame, [edges]) with the arcs each picked arc runs on into
    allc = [x for x in shape.edges() if str(x.geom_type).lower() == "circle"]
    frames = {}

    def frame_of(x):
        k = id(x)
        if k not in frames:
            frames[k] = _circle_round_frame(shape, x, delta)
        return frames[k]

    def same_circle(f, g):
        return (float(np.linalg.norm(f[0] - g[0])) < tol and abs(f[4] - g[4]) < tol and
                abs(abs(float(np.dot(f[1], g[1]))) - 1) < 1e-9 and np.allclose(f[5], g[5]) and
                np.allclose(f[6], g[6]))

    def ends(x):
        return [_vec(x.point_at(0.0)), _vec(x.point_at(1.0))]

    groups = []
    for e in edges:
        if str(e.geom_type).lower() != "circle":
            return None
        fr = frame_of(e)
        if fr is None or not fr[7]:
            return None
        g = next((g for g in groups if same_circle(g[0], fr)), None)
        if g is None:
            g = (fr, [])
            groups.append(g)
        if not any(x is e or float(np.linalg.norm(_vec(x.point_at(0.5)) - _vec(e.point_at(0.5)))) < tol for x in g[1]):
            g[1].append(e)
    for fr, members in groups:
        grown = True
        while grown:
            grown = False
            pts = [p for x in members for p in ends(x)]
            for x in allc:
                if any(float(np.linalg.norm(_vec(x.point_at(0.5)) - _vec(m.point_at(0.5)))) < tol for m in members):
                    continue
                if not any(float(np.linalg.norm(p - q)) < tol for p in ends(x) for q in pts):
                    continue
                fx = frame_of(x)
                if fx is not None and fx[7] and same_circle(fr, fx):
                    members.append(x)
                    grown = True
    tools = []
    for fr, members in groups:
        c, d, e1, e2, R, u1, u2, _cv = fr
        ang = lambda p: math.atan2(float(np.dot(p - c, e2)), float(np.dot(p - c, e1))) % two_pi  # noqa: E731
        spans = []
        for x in members:
            p0, p1, pm = _vec(x.point_at(0.0)), _vec(x.point_at(1.0)), _vec(x.point_at(0.5))
            if float(np.linalg.norm(p1 - p0)) < size * 1e-9:
                spans = [(0.0, two_pi)]
                break
            s0, s1, sm = ang(p0), ang(p1), ang(pm)
            if (sm - s0) % two_pi < (s1 - s0) % two_pi:
                spans.append((s0, (s1 - s0) % two_pi))
            else:
                spans.append((s1, (s0 - s1) % two_pi))
        # arcs that meet are one run
        spans.sort()
        runs = []
        for a, L in spans:
            if runs and a <= runs[-1][0] + runs[-1][1] + 1e-9:
                ra, rl = runs[-1]
                runs[-1] = (ra, max(rl, a + L - ra))
            else:
                runs.append((a, L))
        if len(runs) > 1 and runs[-1][0] + runs[-1][1] >= two_pi + runs[0][0] - 1e-9:
            ra, rl = runs.pop()
            runs[0] = (ra, runs[0][0] + runs[0][1] + two_pi - ra)
        runs = [(a, min(L, two_pi)) for a, L in runs]
        for a0, span in runs:
            got = _circle_run_tool(kind, shape, fr, a0, span, value, delta, runs)
            if got is None:
                return None
            tools.append(got)
    return tools


def _circle_run_tool(kind, shape, fr, a0, span, value, delta, runs):
    """The cutting tool of one run of a rim round (from angle a0 over span)."""
    c, d, e1, e2, R, u1, u2, _cv = fr
    two_pi = 2 * math.pi
    K = np.array([R, 0.0])
    T1, T2 = K + value * u1, K + value * u2
    if kind == "fillet":
        C = K + value * (u1 + u2)
        M = C + value * (K - C) / float(np.linalg.norm(K - C))
        rim = [T1, M, T2, 0.5 * (T1 + M), 0.5 * (T2 + M)]
    else:
        M = 0.5 * (T1 + T2)
        rim = [T1, M, T2]
    if min(T1[0], T2[0], M[0]) <= 0:
        return None                      # the round would reach past the axis

    def at(q2, a):
        rho = math.cos(a) * e1 + math.sin(a) * e2
        return c + q2[0] * rho + q2[1] * d

    probes = [K + lam * (X - K) for X in rim for lam in (0.15, 0.5, 0.85)]

    def material(a):
        return any(bool(shape.contains(tuple(at(q, a)))) for q in probes)

    if span < two_pi - 1e-9:
        step = math.radians(3.0)

        def edge_between(a_lo, a_hi, sign, want):
            """Bisect for where material(a) turns to `want` between offsets a_lo and a_hi."""
            for _ in range(12):
                mid = 0.5 * (a_lo + a_hi)
                if material(a_end_[0] + sign * mid) == want:
                    a_hi = mid
                else:
                    a_lo = mid
            return a_lo, a_hi

        a_end_ = [0.0]

        def reach(a_end, sign, room):
            """How far past an end the round runs. Where the end's notch does not take the whole
            corner away at once (a round larger than the notch is deep: material of the rim goes on
            past the end, inside the notch), the round runs on through it, the notch walls trimming
            it, until the corner is clear; then on through the empty notch, stopping in the middle
            of the gap before the next material (coarse steps, then halving: a few dozen tests)."""
            a_end_[0] = a_end
            o, clear = 0.0, None
            if material(a_end + sign * 1e-5):
                while o < room:                          # through the notch while the rim goes on
                    o2 = min(o + step, room)
                    if not material(a_end + sign * o2):
                        clear = edge_between(o, o2, sign, False)[1]
                        break
                    o = o2
                if clear is None:
                    return 0.0                           # the corner never clears: end here
            else:
                clear = 0.0
            o = clear
            while True:                                  # through the empty notch
                o2 = min(o + step, room)
                if material(a_end + sign * o2):
                    hi_ = edge_between(o, o2, sign, True)[0]
                    return max(0.5 * (clear + hi_), 1e-5)   # the middle of the gap: clear of both walls
                if o2 >= room:
                    return room
                o = o2

        # room up to the neighbouring runs of the same circle (half of each gap)
        others = [(a, L) for a, L in runs if (a, L) != (a0, span)]
        gap_after = min([((a - (a0 + span)) % two_pi) for a, _L in others] or [two_pi - span])
        gap_before = min([((a0 - (a + L)) % two_pi) for a, L in others] or [two_pi - span])
        ext0 = reach(a0, -1.0, gap_before / 2)
        ext1 = reach(a0 + span, 1.0, gap_after / 2)
        a0 -= ext0
        span += ext0 + ext1
    # a round has to lie on the faces: both tangent circles touch material somewhere
    if kind == "fillet":
        # (just inside the material from a tangent point: along the other face's in-face direction)
        samples = np.linspace(a0, a0 + span, 73)
        in1 = any(bool(shape.contains(tuple(at(T1 + delta * 10 * u2, a)))) for a in samples)
        in2 = in1 and any(bool(shape.contains(tuple(at(T2 + delta * 10 * u1, a)))) for a in samples)
        if not (in1 and in2):
            return None
    try:
        # out into the air past both faces, touching the part only at the round: a ring of the
        # corner square (centre C, out past both faces) less the round's torus
        h = value * 0.5
        n1, n2 = -u2, -u1                    # the faces' outward directions (a square corner)
        if kind == "fillet":
            Cc = K + value * (u1 + u2)
            quad = [Cc, Cc + (value + h) * n1, Cc + (value + h) * (n1 + n2), Cc + (value + h) * n2]
        else:
            quad = [T1, T1 + h * n1, K + h * (n1 + n2), T2 + h * n2, T2]
        if min(q[0] for q in quad) <= 0:
            return None
        P = [tuple(at(q, a0)) for q in quad]
        w = _s.Wire([_s.Line(P[k], P[(k + 1) % len(P)]) for k in range(len(P))])
        ring = _s.revolve(w, _s.Axis(tuple(c), tuple(d)), float(min(math.degrees(span), 360.0)))
        if kind == "fillet":
            # the round's torus, revolved from a circle whose joints (and the revolve's seam) lie away
            # from the round: the kernel's own torus has its seam on the tangent circle, which the
            # checker flags in the result ("edge near seam")
            am = a0 + span + 0.5 * (two_pi - span) if span < two_pi - 1e-9 else a0 + math.pi
            cp = [tuple(at(Cc + value * (math.cos(t_) * n2 + math.sin(t_) * n1), am))
                  for t_ in (0.75 * math.pi, 1.25 * math.pi, 1.75 * math.pi, 0.25 * math.pi)]
            tw = _s.Wire([_s.ThreePointArc(cp[0], cp[1], cp[2]), _s.ThreePointArc(cp[2], cp[3], cp[0])])
            tor = _s.revolve(tw, _s.Axis(tuple(c), tuple(d)), 360.0)
            ring = _call(kind, ring.cut, tor)
        return ring
    except Exception as ex:
        raise CadError(f"{kind}: could not build the round of a circular edge ({ex})")


def _corner_rounds(kind, shape, edge_ids, value):
    """Rounds (or bevels) made by cutting the corner region away where the kernel's rolling ball
    cannot make them: straight edges between flat faces (past their faces, Parasolid style) and
    circular edges between a flat face and a coaxial cylinder (ending against notches). None when
    an edge is neither.

    The kernel's tolerances suit parts measured in millimetres: on a part of a few metres or less
    (Blender units) its curve intersections near small rounds come out with gaps its own check
    rejects, so when the cut at the part's own size does not pass, it is made again on a copy
    scaled to millimetre size and scaled back."""
    if not isinstance(shape, _s.Part) or value <= 0:
        return None
    size = body_size(shape)
    k = 10.0 ** round(math.log10(300.0 / size)) if size > 0 else 1.0
    try:
        circles = any(str(e.geom_type).lower() == "circle" for e in _edges(shape, edge_ids))
    except CadError:
        return None
    if k >= 10.0 and circles:          # (rounds of circles come out clean only at millimetre size)
        return _corner_rounds_scaled(kind, shape, edge_ids, value, k, size) or \
            _corner_rounds_at(kind, shape, edge_ids, value)
    out = _corner_rounds_at(kind, shape, edge_ids, value)
    if out is not None or k < 10.0:
        return out
    return _corner_rounds_scaled(kind, shape, edge_ids, value, k, size)


def _corner_rounds_scaled(kind, shape, edge_ids, value, k, size):
    """_corner_rounds_at on a copy of the part scaled by k, scaled back. (The kernel's booleans do
    not always come out the same; a result that does not scale back cleanly is made again at the
    next size: k, 10 k, k / 10.)"""
    base_own = None
    for kk in (k, k * 10.0, k / 10.0):
        if kk < 10.0:
            continue
        try:
            big = shape.scale(kk)
            ids = _same_edges(shape, big, edge_ids, kk)
            if ids is None:
                continue
            got = _corner_rounds_at(kind, big, ids, value * kk)
            if got is None:
                continue
            back = got.scale(1.0 / kk)
            # (scaling sets the kernel's default tolerances: edges the part already had that were
            # within their own looser tolerance may now be reported; only new problems count)
            if base_own is None:
                base_own = list(shape.check())
            base = base_own + list(big.scale(1.0 / kk).check())
            if isinstance(back, _s.Part) and not _new_problems(base, back.check(), size * 1e-6):
                return back
        except Exception:
            continue
    return None


def _fast_points(e, ts) -> np.ndarray:
    """Points along an edge at fractions of its own curve parameter: quick where point_at (by
    length) is slow, on long intersection curves (see mesher.fast_points; this copy also works in
    the kernel worker, which loads this module on its own)."""
    ts = np.asarray(ts, dtype=float)
    if str(e.geom_type).lower() not in ("line", "circle"):
        try:
            t0, t1 = e._range()
            u = np.clip(1.0 - ts if e._rev else ts, 0.0, 1.0)
            c = e._curve()
            return np.array([tuple(c.evaluate(float(t0 + (t1 - t0) * x)))[:3] for x in u], dtype=float)
        except Exception:
            pass
    return np.array([tuple(e.point_at(float(x)))[:3] for x in ts], dtype=float)


def _problem_point(p):
    """Where a check problem is (the middle of its edge, the centre of its face, ...), or None."""
    sh = getattr(p, "shape", None)
    if sh is None:
        return None
    for get in (lambda: _fast_points(sh, [0.5])[0] if type(sh).__name__ == "Edge" else sh.missing,
                lambda: sh.center(), lambda: sh.position):
        try:
            return _vec(get())
        except Exception:
            continue
    return None


def _new_problems(before, after, tol):
    """The problems in `after` that `before` does not have (same test at the same place)."""
    old = [(str(p.test), _problem_point(p)) for p in before]
    out = []
    for p in after:
        q = _problem_point(p)
        if not any(t == str(p.test) and ((q is None and r is None) or (q is not None and r is not None and
                                                                      float(np.linalg.norm(q - r)) <= tol))
                   for t, r in old):
            out.append(p)
    return out


def _same_edges(shape, other, edge_ids, k):
    """The ids in `other` (`shape` scaled by k, perhaps healed) of the edges `edge_ids` of `shape`."""
    mids = [_fast_points(e, [0.5])[0] for e in other.edges()]
    tol = body_size(shape) * k * 1e-6
    out = []
    for e in _edges(shape, edge_ids):
        p = _fast_points(e, [0.5])[0] * k
        dist = [float(np.linalg.norm(m - p)) for m in mids]
        j = int(np.argmin(dist))
        if dist[j] > tol:
            return None
        out.append(j)
    return out


def _corner_rounds_at(kind, shape, edge_ids, value):
    """_corner_rounds at the part's own size."""
    try:
        edges = _edges(shape, edge_ids)
    except CadError:
        return None
    lines = [i for i, e in zip(edge_ids, edges) if str(e.geom_type).lower() == "line"]
    circles = [i for i, e in zip(edge_ids, edges) if str(e.geom_type).lower() == "circle"]
    if len(lines) + len(circles) != len(edge_ids):
        return None
    tools = []
    for ids, build in ((lines, _straight_round_tools), (circles, _circle_round_tools)):
        if ids:
            got = build(kind, shape, ids, value)
            if got is None:
                return None
            tools += got
    if not tools:
        return None
    out = shape
    try:
        out = _call(kind, out.cut, combine(tools) if len(tools) > 1 else tools[0])
    except CadError:
        out = shape
        for tool in tools:
            out = _call(kind, out.cut, tool)
    try:
        if not out.faces() or float(out.volume) <= 0:
            return None
        found = out.check()
        if found and _new_problems(shape.check(), found, max(body_size(shape), 1e-12) * 1e-6):
            return None
    except Exception:
        return None
    return out


def _edge_op(kind, shape, edge_ids, value, run, explain: bool = True, overflow: bool = True, tag=(), word=None):
    """Run an edge rounding (fillet / chamfer); when the value is too large for the kernel, round
    straight outside edges between flat faces past their faces (see _corner_rounds), else say how
    large it can be."""
    if overflow:
        inner = run

        def run(v):
            try:
                return inner(v)
            except CadError:
                got = _corner_rounds(kind, shape, edge_ids, v)
                if got is None:
                    raise
                return got

        if not _corner_rounds_apply(shape, edge_ids):
            run = inner       # (the largest value below is then the kernel's alone)
    key = (_shape_key(shape), tuple(sorted(edge_ids)), kind, tuple(tag))
    word = word or ("radius" if kind == "fillet" else "length")
    if kind == "fillet" and value > 0 and word == "radius":
        if key + ("limit",) not in _EDGE_MAX:
            _EDGE_MAX[key + ("limit",)] = round_limit(shape, edge_ids)
        lim = _EDGE_MAX[key + ("limit",)]
        if lim is not None and value > lim * 0.999:
            raise CadError(f"fillet: the radius is too large here: the tightest bend along these edges has a "
                           f"radius of {lim:.6g}, and a round larger than that would run over itself; "
                           f"largest possible radius here: {lim * 0.995:.6g}")
    known = _EDGE_MAX.get(key)
    if known is not None and value > known * 1.0001 and known > 0:
        raise CadError(f"{kind}: the {word} is too large for these edges; largest possible {word} here: {known:.6g}")
    try:
        return run(value)
    except CadError as ex:
        if value <= 0 or not explain:
            raise
        if isinstance(ex, FilletRuleError):
            raise
        mx = _largest(run, value)
        if len(_EDGE_MAX) > 128:
            _EDGE_MAX.clear()
        _EDGE_MAX[key] = mx
        if mx <= 0:
            raise
        import re
        groups = [g for g in re.findall(r"\(([^()]*)\)", str(ex))
                  if re.search(r"[a-z]{3}", g) and "too large" not in g and not g.startswith("it is")]
        reason = f" ({groups[-1]})" if groups else ""
        hint = _corner_hint(kind, shape, edge_ids, value)
        raise CadError(f"{kind}: the {word} is too large here{reason}; largest possible {word} here: {mx:.6g}{hint}")


def _corner_hint(kind, shape, edge_ids, value) -> str:
    """Where two of the picked edges meet an edge that is not picked (a corner the kernel finishes
    with a setback, which it cannot always build): when rounding those edges too works at the
    value, say so."""
    if kind != "fillet" or not isinstance(shape, _s.Part) or len(edge_ids) < 2:
        return ""
    try:
        edges = list(shape.edges())
        size = max(body_size(shape), 1e-12)
        ends = [(_vec(e.start), _vec(e.end)) for e in edges]
        picked = set(int(i) for i in edge_ids)
        third = set()
        for i in picked:
            for p in ends[i]:
                at = [j for j, (a, b) in enumerate(ends) if float(np.linalg.norm(a - p)) < size * 1e-5
                      or float(np.linalg.norm(b - p)) < size * 1e-5]
                if len(at) == 3 and len(picked & set(at)) == 2:
                    third |= set(at) - picked
        if not third:
            return ""
        ids = sorted(picked | third)
        _call(kind, shape.fillet, [edges[j] for j in ids], value)
        return (f". The rounds end at {len(third)} corner(s) against an edge that is not rounded, and the "
                f"kernel cannot always build such a corner: picking {'that edge' if len(third) == 1 else 'those edges'} "
                f"too works at this radius")
    except Exception:
        return ""


def _free_loops(shape):
    """The open borders of a sheet as wires (closed loops of edges used by one face)."""
    free = [e for e in shape.edges() if len(e.faces()) == 1]
    size = max(float(shape.bbox().diagonal), 1e-9)
    tol = size * 1e-7
    groups = []
    for e in free:
        ends = (_vec(e.start), _vec(e.end))
        hit = [g for g in groups if any(np.linalg.norm(p - q) < tol for f in g for q in (_vec(f.start), _vec(f.end))
                                        for p in ends)]
        merged = [e] + [f for g in hit for f in g]
        groups = [g for g in groups if g not in hit] + [merged]
    return [wire(_ordered_chain(g)) for g in groups]


def _cap(loop):
    """A face closing an open border: flat when the loop is planar, else a patch through it."""
    try:
        f = face_from_wires(loop)
        faces = list(f.faces()) if hasattr(f, "faces") else [f]
        if faces:
            return _call("cap", _s.stitch, faces)
    except Exception:
        pass
    return fill([loop], tangent=False)


def _on_caps(face, caps, tol):
    """True when a face lies on one of the cap sheets (it came from closing the surface)."""
    try:
        pts = [_vec(face.center())]
        try:
            pts.append(_vec(face.interior_point()))
        except Exception:
            pass
        for cap in caps:
            if all(float(cap.distance_to(tuple(p))) < tol for p in pts):
                return True
    except Exception:
        return False
    return False


def _sheet_edge_op(kind, shell, edge_ids, value, op):
    """Round (or bevel) edges between faces of a sheet: its open borders are closed with caps into
    a solid (which also decides the side: the round goes where a solid's would), the edges are
    rounded there, and the caps are taken off again."""
    edges = _edges(shell, edge_ids)
    for e in edges:
        if len(e.faces()) != 2:
            raise CadError(f"{kind}: an edge on the open border of a surface has only one face; pick edges "
                           "between two faces of the surface")
    loops = _free_loops(shell)
    size = max(float(shell.bbox().diagonal), 1e-9)
    tol = size * 1e-6
    try:
        caps = [_cap(lp) for lp in loops]
        closed = _call(kind, _s.stitch, shell, *caps) if caps else shell
    except CadError as ex:
        raise CadError(f"{kind} on a surface: its open borders could not be closed to find the side to round "
                       f"({str(ex).split(': ', 1)[-1]})")
    if not isinstance(closed, _s.Part):
        raise CadError(f"{kind} on a surface: closing its open borders did not give a solid, so the side to round "
                       "is unclear (fillet surfaces whose borders are simple loops, or thicken first)")
    # the picked edges in the closed body (by their middle points)
    cedges = list(closed.edges())
    ids = []
    for e in edges:
        m = _vec(e.point_at(0.5))
        k = min(range(len(cedges)), key=lambda i: float(np.linalg.norm(_vec(cedges[i].point_at(0.5)) - m)))
        ids.append(k)

    def run(v):
        out = op(closed, ids, v)
        keep = [f for f in out.faces() if not _on_caps(f, caps, tol)]
        if not keep:
            raise CadError(f"{kind}: nothing left of the surface")
        return _call(kind, _s.stitch, keep)

    return run


CORNERS = ("patch", "mitre", "setback")


def fillet(shape, edge_ids, radius: float, g2: bool = False, explain: bool = True, radius_end=None,
           corners: str = "patch", setback: float | None = None, fullness: float = 1.0,
           continuity: str | None = None, radii=None, radius_map=None, chord: bool = False):
    """Round edges.

    corners: where three or more rounded edges meet: "patch" (a ball corner where the radii are
    equal), "mitre" (the rounds run on into each other along mitre lines: three convex edges and no
    other at the corner) or "setback" (the rounds stop `setback` from the corner along its edges and
    one softer patch joins them: every edge at the corner rounded, all convex or all concave; 0 /
    None: 1.6 times the radius, kept inside the edges). continuity: None (circular), "G1" (a tangent
    blend, not a circle), "G2" or "G3" (g2=True is "G2"). fullness: the blend's cross-section,
    fuller above 1, flatter below. radii: one radius per picked edge (0: `radius`).
    radius_map: {position along each run (0 its start, 1 its end): radius} (0: `radius`), joined
    smoothly. chord: `radius` (and radii / radius_map) are chord lengths, the width of the round
    across its two contact lines: turned into radii from the angle between the faces (exactly
    where that angle stays the same along an edge; see chord_radii)."""
    if not edge_ids:
        raise CadError("fillet: select one or more edges first")
    corners = {"miter": "mitre", "ball": "patch"}.get(str(corners or "patch").lower(), str(corners or "patch").lower())
    if corners not in CORNERS:
        raise CadError(f"fillet: corners must be one of {', '.join(CORNERS)}")
    cont = continuity if continuity not in (None, "", "CIRCULAR", "circular") else ("G2" if g2 else None)
    word = "chord" if chord else "radius"
    kw = {}
    if cont:
        kw["continuity"] = str(cont).upper()
    if fullness and abs(float(fullness) - 1.0) > 1e-9:
        kw["fullness"] = float(fullness)
    if corners == "mitre":
        kw["corners"] = "mitre"
    value = float(radius)
    per = None
    if radii is not None and any(float(r) > 0 for r in list(radii)[:len(edge_ids)]):
        per = [float(r) if float(r) > 0 else value for r in list(radii)[:len(edge_ids)]]
        per += [value] * (len(edge_ids) - len(per))
    rmap = None
    if radius_map:
        rmap = {min(max(float(p), 0.0), 1.0): (float(r) if float(r) > 0 else value) for p, r in dict(radius_map).items()}
    if radius_end:
        rmap = {0.0: value, 1.0: float(radius_end)}
    varying = rmap is not None
    if varying and (corners != "patch" or per or cont):
        raise FilletRuleError(f"fillet: a {word} that varies along the edges goes with ball corners, a circular "
                              "round and one size for all the edges (the kernel's own limits)")
    note = ""
    if chord:
        try:
            if varying:
                spec, err = chord_radii(shape, edge_ids, value, chord_map=rmap)
            else:
                spec, err = chord_radii(shape, edge_ids, value, per_chords=per)
        except CadError:
            raise
        if isinstance(spec, dict):
            rmap, per = spec, None
            if cont:
                raise FilletRuleError("fillet: chord lengths on these edges need a radius that varies along "
                                      "them (the angle between the faces changes), which the kernel makes as "
                                      "circular rounds only: use the Circular blend")
        else:
            per = spec
        if err > value * 1e-6:
            note = (f"chord within ±{err:.3g} of {value:.4g} (one radius along runs where the angle between "
                    f"the faces changes)")
    if corners == "setback":
        sb = float(setback or 0.0)
        if sb <= 0:
            sb = _auto_setback(shape, edge_ids, max(per or ([max(rmap.values())] if rmap else [value])))
        kw["setback"] = sb
    if corners in ("mitre", "setback") and isinstance(shape, _s.Part):
        why = _corner_rule(shape, edge_ids, corners)
        if why:
            raise FilletRuleError(why)
    if rmap is not None:
        lim = round_limit(shape, edge_ids)
        top_r = max(rmap.values())
        if lim is not None and top_r > lim * 0.999:
            raise CadError(f"fillet: the radius is too large here: the tightest bend along these edges has a "
                           f"radius of {lim:.6g}; largest possible radius here: {lim * 0.995:.6g}")

    def spec_at(v):
        f = v / value
        if rmap is not None:
            return {p: r * f for p, r in rmap.items()}
        if per is not None:
            return [x * f for x in per]
        return v

    def solid_op(sh, ids, v):
        try:
            return _call("fillet", sh.fillet, _edges(sh, ids), spec_at(v), **kw)
        except CadError as ex:
            m = str(ex)
            if ("setback" in m and ("exceed" in m or "below" in m or "length" in m)) or 'corners="mitre"' in m \
                    or "set back are" in m or "no corner" in m:
                raise FilletRuleError(m) from ex
            raise

    plain = not kw and per is None and rmap is None and not chord
    if not isinstance(shape, _s.Part):
        run = _sheet_edge_op("fillet", shape, edge_ids, value, solid_op)
    else:
        def run(v):
            return solid_op(shape, edge_ids, v)
    tag = (corners, kw.get("setback"), kw.get("continuity"), kw.get("fullness"), tuple(per) if per else None,
           tuple(sorted(rmap.items())) if rmap else None, chord)
    out = _edge_op("fillet", shape, edge_ids, value, run, explain, overflow=plain, tag=tag, word=word)
    LAST_NOTE["fillet"] = note
    return out


LAST_NOTE = {"fillet": ""}      # what the last fillet wants said (how close a chord length came)


def _dihedral(e, faces, t):
    """The angle between the two faces' normals at a fraction t along an edge (0: they run on
    smoothly; 90 degrees at a box's edge), radians."""
    p = _vec(e.point_at(float(t)))
    n1 = _unit(_vec(faces[0].normal_at(tuple(p))))
    n2 = _unit(_vec(faces[1].normal_at(tuple(p))))
    return math.acos(max(-1.0, min(1.0, float(np.dot(n1, n2)))))


def chord_radii(shape, edge_ids, chord, per_chords=None, chord_map=None, samples: int = 9):
    """Radii for rounds of a given chord length (the width across the round's two contact lines):
    a circular round of radius r between faces whose normals are alpha apart spans
    2 r sin(alpha / 2). Where alpha stays the same along each edge: one radius per edge, exact.
    Where it changes along an edge: for a single edge (or with chord_map), radii at points along it
    (the kernel's varying radius, joined smoothly between them); for several edges, each edge's
    middle radius. Returns (radii per edge | {position: radius}, largest chord error)."""
    edges = _edges(shape, edge_ids)
    ts = np.linspace(0.0, 1.0, samples)
    per_edge = []
    for k, e in enumerate(edges):
        fs = list(e.faces())
        if len(fs) != 2:
            raise CadError("fillet: chord lengths need edges between two faces")
        c = float(per_chords[k]) if per_chords is not None else float(chord)
        al = []
        for t in ts:
            try:
                al.append(_dihedral(e, fs, t))
            except Exception:
                continue
        al = np.array(al)
        if not len(al) or float(al.min()) < 1e-3:
            raise CadError("fillet: chord length: the faces of an edge run on smoothly (no angle between them) "
                           "somewhere along it")
        per_edge.append((c, al))
    alone = False
    if len(edges) == 1:
        try:
            alone = len(list(edges[0].tangent_chain())) <= 1     # its run is the edge itself
        except Exception:
            alone = True
    varies = any(np.ptp(a) > 1e-4 for _c, a in per_edge)
    if varies and not alone:
        # a run of several edges (picked, or running on smoothly): the kernel varies a radius along a
        # run but not around a closed run of several edges, and different radii where edges run on
        # into each other do not meet: one radius for them all, the middle of the ones the chord asks for
        rs = np.concatenate([c / (2 * np.sin(a / 2)) for c, a in per_edge])
        r = float(np.median(rs))
        err = max(float(np.max(np.abs(2 * r * np.sin(a / 2) - c))) for c, a in per_edge)
        if chord_map:
            raise CadError("fillet: a chord length that varies along the edge goes on one edge whose round "
                           "does not run on into others")
        return [r] * len(edges), err
    if chord_map is not None or (alone and varies):
        # one run: radii at points along it from the angle there and the chord asked for there
        if len(edges) > 1:
            al = np.concatenate([a for _c, a in per_edge])
            if np.ptp(al) > 1e-4:
                raise CadError("fillet: a varying chord length goes on one edge at a time where the angle "
                               "between the faces changes along the edges")
            a0 = float(np.mean(al))
            return {p: float(c) / (2 * math.sin(a0 / 2)) for p, c in (chord_map or {0.0: chord}).items()}, 0.0
        al = per_edge[0][1]
        pos = np.linspace(0.0, 1.0, len(al))
        if chord_map:
            cps = sorted(chord_map.items())
            cs = np.interp(pos, [p for p, _c in cps], [c for _p, c in cps])
        else:
            cs = np.full(len(al), float(chord))
        rmap = {float(p): float(c / (2 * math.sin(a / 2))) for p, c, a in zip(pos, cs, al)}
        return rmap, 0.0
    radii, err = [], 0.0
    for c, al in per_edge:
        a_mid = float(al[len(al) // 2])
        r = c / (2 * math.sin(a_mid / 2))
        radii.append(r)
        err = max(err, float(np.max(np.abs(2 * r * np.sin(al / 2) - c))))
    return radii, err


def _corner_vertices(shape, edge_ids):
    """[(point, [edge ids at it], [picked ids at it])] for the corners of the picked edges."""
    edges = list(shape.edges())
    size = max(body_size(shape), 1e-12)
    tol = size * 1e-5
    ends = [(_vec(e.start), _vec(e.end)) for e in edges]
    picked = set(int(i) for i in edge_ids)
    out = []
    for i in sorted(picked):
        for p in ends[i]:
            if any(float(np.linalg.norm(p - q)) < tol for q, _a, _b in out):
                continue
            at = [j for j, (a, b) in enumerate(ends) if float(np.linalg.norm(a - p)) < tol or float(np.linalg.norm(b - p)) < tol]
            out.append((p, at, [j for j in at if j in picked]))
    return out


def _convexity(e) -> str:
    try:
        c = e.convexity() if callable(e.convexity) else e.convexity
        return str(c).lower()
    except Exception:
        return "unknown"


def _corner_rule(shape, edge_ids, corners) -> str:
    """Why no corner of the picked edges can be mitred / set back, or "" when one can."""
    edges = list(shape.edges())
    verts = [v for v in _corner_vertices(shape, edge_ids) if len(v[2]) >= 2]
    if not verts:
        return (f"fillet: {'Mitre' if corners == 'mitre' else 'Setback'} corners need a corner where the rounded "
                "edges meet; these edges meet at none (pick the edges around a corner)")
    reasons = []
    for p, at, pk in verts:
        conv = {_convexity(edges[j]) for j in pk}
        where = f"({p[0]:.4g}, {p[1]:.4g}, {p[2]:.4g})"
        if len(pk) < len(at):
            reasons.append(f"the corner at {where} has an edge that is not rounded")
            continue
        if corners == "mitre":
            if len(at) != 3:
                reasons.append(f"the corner at {where} has {len(at)} edges (a mitre takes three)")
                continue
            if conv != {"convex"}:
                reasons.append(f"the corner at {where} is not three outside (convex) edges")
                continue
            return ""
        if len(conv) > 1 or not conv <= {"convex", "concave"}:
            reasons.append(f"the corner at {where} has inside and outside edges")
            continue
        return ""
    what = ("Mitre corners need three rounded outside edges meeting and no other edge"
            if corners == "mitre" else
            "Setback corners need every edge at a corner rounded, all outside or all inside")
    return f"fillet: {what}; {reasons[0]}" + (f" (and {len(reasons) - 1} more)" if len(reasons) > 1 else "")


def _auto_setback(shape, edge_ids, radius) -> float:
    """1.6 times the radius, but well inside the shortest rounded edge at a corner (half of it
    where both its ends are set back)."""
    sb = 1.6 * float(radius)
    try:
        edges = list(shape.edges())
        verts = [v for v in _corner_vertices(shape, edge_ids) if len(v[2]) >= 3 and len(v[2]) == len(v[1])]
        count = {}
        for _p, _at, pk in verts:
            for j in pk:
                count[j] = count.get(j, 0) + 1
        for j, n in count.items():
            L = float(edges[j].length)
            sb = min(sb, 0.9 * (L / 2 if n >= 2 else L))
    except Exception:
        pass
    return sb


def chamfer(shape, edge_ids, length: float, explain: bool = True, length2: float | None = None,
            angle: float | None = None, flip: bool = False, corners: str = "patch", reference_faces=None):
    """Bevel edges. One distance (length) on both faces; or two: length on each edge's reference
    face and length2 on its other face; or length on the reference face and the bevel at `angle`
    (degrees) to it. The reference face of an edge: a picked face it lies on (reference_faces), else
    its face shared by the most picked edges (the top face for the top edges of a box); `flip`
    takes the other one. corners: "patch" or "mitre" where three bevelled edges meet."""
    if not edge_ids:
        raise CadError("chamfer: select one or more edges first")
    corners = {"miter": "mitre", "ball": "patch"}.get(str(corners or "patch").lower(), str(corners or "patch").lower())
    if corners not in ("patch", "mitre"):
        raise CadError("chamfer: corners must be patch or mitre")
    two = length2 is not None and length2 > 0 and abs(float(length2) - float(length)) > 1e-12 * max(1.0, float(length))
    ang = angle is not None and angle > 0 and abs(float(angle) - 45.0) > 1e-9
    kw = {"corners": "mitre"} if corners == "mitre" else {}
    if corners == "mitre" and isinstance(shape, _s.Part):
        why = _corner_rule(shape, edge_ids, "mitre")
        if why:
            raise FilletRuleError(why.replace("fillet:", "chamfer:").replace("rounded", "bevelled"))

    def solid_op(sh, ids, v):
        if not (two or ang):
            try:
                return _call("chamfer", sh.chamfer, _edges(sh, ids), v, **kw)
            except CadError as ex:
                if 'corners="mitre"' in str(ex):
                    raise FilletRuleError(str(ex)) from ex
                raise
        scale = v / float(length)
        extra = {"length2": float(length2) * scale} if two else {"angle": float(angle)}
        return _chamfer_two(sh, ids, v, extra, flip, reference_faces if sh is shape else None, kw)

    if not isinstance(shape, _s.Part):
        run = _sheet_edge_op("chamfer", shape, edge_ids, length, solid_op)
    else:
        def run(v):
            return solid_op(shape, edge_ids, v)
    plain = not (two or ang) and not kw
    tag = ("two", float(length2) / float(length)) if two else (("angle", float(angle)) if ang else ())
    return _edge_op("chamfer", shape, edge_ids, length, run, explain, overflow=plain,
                    tag=tag + ((corners, bool(flip)) if (two or ang or kw) else ()))


def _chamfer_two(shape, edge_ids, length, extra, flip, reference_faces, kw):
    """An asymmetric bevel (two distances, or a distance and an angle). The kernel wants each edge
    on exactly one of the reference faces given: edges whose faces would both be references (the
    top edge and the side edge at a box's corner, each measured from its own face) are bevelled in
    turns, each turn finding its edges and faces again on the part the turn before made."""
    edges = _edges(shape, edge_ids)
    faces = list(shape.faces())
    picked = set(i for i in (reference_faces or []) if 0 <= i < len(faces))
    pairs = []
    for e in edges:
        fs = list(e.faces())
        if len(fs) != 2:
            raise CadError("chamfer: two distances need edges between two faces")
        pairs.append([next((i for i, g in enumerate(faces) if g == f), None) for f in fs])
    # turns, each a set of reference faces that no edge of the turn has both of: faces picked first,
    # then the faces with the most edges (the top and bottom of a box, then two opposite sides)
    left = list(range(len(edges)))
    turns = []
    while left:
        refs, members, others = [], [], set()
        count = {}
        for k in left:
            for f in pairs[k]:
                count[f] = count.get(f, 0) + 1
        order = sorted(count, key=lambda f: (f not in picked, -count[f], f))
        for f in order:
            if f in others:
                continue
            mine = [k for k in left if f in pairs[k] and k not in members]
            mine = [k for k in mine if (pairs[k][0] if pairs[k][1] == f else pairs[k][1]) not in refs]
            if not mine:
                continue
            refs.append(f)
            for k in mine:
                members.append(k)
                others.add(pairs[k][0] if pairs[k][1] == f else pairs[k][1])
        if not members:
            raise CadError("chamfer: could not tell which face to measure the distances from")
        turn = []
        for k in members:
            ref = next(f for f in refs if f in pairs[k])
            other = pairs[k][0] if pairs[k][1] == ref else pairs[k][1]
            turn.append((edges[k], other, ref) if flip else (edges[k], ref, other))
        turns.append(turn)
        left = [k for k in left if k not in members]
    if kw.get("corners") == "mitre" and len(turns) > 1:
        raise FilletRuleError("chamfer: Mitre corners and two distances do not go together here: the bevels "
                              "meeting at a corner have to be measured from faces that share their edges, so "
                              "they are made one after another and cannot be mitred; use Patch corners")
    out = shape
    size = max(body_size(shape), 1e-12)
    for n, turn in enumerate(turns):
        if n == 0:
            es = [x[0] for x in turn]
            refs = []
            for x in turn:
                f = faces[x[1]]
                if not any(f == g for g in refs):
                    refs.append(f)
        else:
            es, refs = [], []
            for e, rid, _oid in turn:
                ne = _edge_again(out, e, size)
                if ne is None:
                    raise CadError("chamfer: an edge was taken away by the bevel of an edge next to it; "
                                   "give smaller distances")
                es.append(ne)
                rf = faces[rid]
                cand = list(ne.faces())
                best = min(cand, key=lambda g: float(rf.distance_to(tuple(_face_samples(g, most=2)[0]))))
                if not any(best == g for g in refs):
                    refs.append(best)
        out = _call("chamfer", out.chamfer, es, length, reference=refs if len(refs) > 1 else refs[0], **extra, **kw)
    return out


def _edge_again(shape, e, size):
    """The edge of `shape` lying along the old edge e (the longest such piece), or None."""
    best = None
    for f in shape.edges():
        try:
            P = _fast_points(f, [0.2, 0.5, 0.8])
            if max(float(e.distance_to(tuple(p))) for p in P) <= size * 1e-6:
                L = float(f.length)
                if best is None or L > best[1]:
                    best = (f, L)
        except Exception:
            continue
    return best[0] if best else None


def push_pull(shape, face_ids, distance: float):
    if not face_ids:
        raise CadError("push/pull: select one or more faces first")
    return _call("push/pull", shape.offset_faces, _faces(shape, face_ids), distance)


def move_faces(shape, face_ids, offset_xyz):
    if not face_ids:
        raise CadError("move faces: select one or more faces first")
    return _call("move faces", shape.move_faces, _faces(shape, face_ids), tuple(offset_xyz))


def remove_faces(shape, face_ids):
    if not face_ids:
        raise CadError("delete faces: select the faces of a hole, boss, pocket or fillet first")
    try:
        out = _call("delete faces", shape.remove_faces, _faces(shape, face_ids))
        # the kernel closes a hole in one face (a slot, a pocket in a body) with a patch of its own on
        # that face's surface: a face more, its seam drawn round where the hole was. Growing the
        # faces round the hole back over it gives the one face again (kept when it is the same solid)
        want = len(shape.faces()) - len(set(face_ids))
        if len(out.faces()) > want and isinstance(shape, _s.Part):
            try:
                again = rebuild_without(shape, face_ids)
                v0, v1 = float(out.volume), float(again.volume)
                if len(again.faces()) < len(out.faces()) and abs(v1 - v0) <= abs(v0) * 1e-5 and not again.check():
                    return again
            except (CadError, Exception):
                pass
        return out
    except CadError as ex:
        # rounds the kernel cannot take out: extend the two faces each one blends instead (planes,
        # cylinders, spheres), else grow every face around them and find the solid again
        for heal in (heal_rounds, rebuild_without):
            try:
                return heal(shape, face_ids)
            except CadError:
                continue
        raise ex


def _void_side(face, big: float, grow: float = 0.0):
    """The empty side of a face's whole surface (the complement of _material_side)."""
    mat = _material_side(face, big, -grow)
    if mat is None:
        return None
    c = _vec(face.center())
    box = _s.Box(4.0 * big, 4.0 * big, 4.0 * big).translate(tuple(c))
    return _call("heal", box.cut, mat)


def _round_sides(shape, fid):
    """(the two faces a round blends (it meets them tangentially), the faces at its ends)."""
    faces = list(shape.faces())
    f = faces[fid]
    blend, ends = [], []
    for e in f.edges():
        try:
            p = _vec(e.point_at(0.5))
        except Exception:
            continue
        for g in e.faces():
            gi = _face_ids_of(shape, [g])
            if not gi or gi[0] == fid:
                continue
            try:
                d = float(np.dot(_unit(f.normal_at(tuple(p))), _unit(g.normal_at(tuple(p)))))
            except Exception:
                d = 0.0
            (blend if d > 0.999 else ends).append(gi[0])
    blend = sorted(set(blend))
    return blend, sorted(set(ends) - set(blend))


def heal_rounds(shape, face_ids):
    """Take out rounds (fillet faces) by extending the two faces each one blends, as Delete + Heal
    does where the kernel cannot (a round that runs into another face at its ends, like the floor
    round of a notch open at the side). An inside round: the material in the corner, on the empty
    side of both faces, is cut away; an outside round: the corner on the material side of both
    faces (and of the faces at its ends) is filled."""
    if not isinstance(shape, _s.Part):
        raise CadError("delete faces: rounds are taken out of solids")
    out = shape
    # one at a time, from the last index (the others' ids stay valid in the original) by geometry
    targets = []
    faces = list(shape.faces())
    for i in face_ids:
        try:
            targets.append(_vec(faces[i].interior_point()))
        except Exception:
            targets.append(_vec(faces[i].center()))
    size = max(body_size(shape), 1e-9)
    big = size * 2.0
    for q in targets:
        cur = list(out.faces())
        fid = min(range(len(cur)), key=lambda k: float(cur[k].distance_to(tuple(q))))
        if float(cur[fid].distance_to(tuple(q))) > size * 1e-6:
            raise CadError("delete faces: a round could not be found again")
        f = cur[fid]
        blend, ends = _round_sides(out, fid)
        if len(blend) != 2:
            raise CadError("delete faces: the face is not a round between two faces")
        A, B = cur[blend[0]], cur[blend[1]]
        lo, hi = np.asarray(tuple(f.bbox().min)), np.asarray(tuple(f.bbox().max))
        pad = 0.5 * float(np.linalg.norm(hi - lo)) + size * 1e-4
        region = _s.Box(*(hi - lo + 2 * pad)).translate(tuple((lo + hi) / 2.0))
        tol = size * 1e-6
        ref = abs(float(out.volume))
        probes = [q]
        vA, vB = _void_side(A, big), _void_side(B, big)
        healed = None
        if vA is not None and vB is not None:
            try:   # an inside round: its material sits in the empty corner of the two faces
                corner = _call("heal", _call("heal", region.intersect, vA).intersect, vB)
                cut = _touching(_call("heal", out.intersect, corner), probes, tol, ref)
                if cut is not None:
                    healed = _call("heal", out.cut, cut)
            except CadError:
                healed = None
        if healed is None:
            mA, mB = _material_side(A, big), _material_side(B, big)
            if mA is None or mB is None:
                raise CadError(f"delete faces: the faces the round blends are not planes, cylinders or spheres")
            corner = _call("heal", _call("heal", region.intersect, mA).intersect, mB)
            for k in ends:   # the faces at its ends bound the corner too
                m = _material_side(cur[k], big)
                if m is not None:
                    corner = _call("heal", corner.intersect, m)
            fill = _touching(_call("heal", corner.cut, out), probes, tol, ref)
            if fill is None:
                raise CadError("delete faces: nothing to take out at the round")
            healed = _call("heal", out.fuse, fill)
        if not healed.faces() or healed.check():
            raise CadError("delete faces: the round could not be taken out cleanly")
        out = healed
    return out


def shell(shape, thickness: float, open_face_ids=(), outward: bool = False):
    openings = _faces(shape, open_face_ids) if open_face_ids else None
    try:
        out = _call("shell", shape.shell, thickness, openings, outward=outward)
        if not outward and isinstance(shape, _s.Part) and thickness > 0 and not _hollow_enough(
                shape, out, float(thickness), open_face_ids):
            # (on some parts the kernel says it shelled and hands back the part as it was)
            raise CadError("shell failed: the kernel gave back a part that is not hollow")
        return out
    except CadError as ex:
        # the kernel's shell can fail where a nearly flat crease (a straight loft's middle section)
        # runs into a concave edge (a handle joining there): the inside then comes from the faces'
        # own offset surfaces, as Boundary Fill finds a volume, and is cut out of the part
        if outward or not isinstance(shape, _s.Part) or thickness <= 0:
            raise
        for way in (_shell_by_proxy, _shell_by_cells):
            try:
                return way(shape, float(thickness), list(open_face_ids or ()))
            except CadError:
                continue
            except Exception:
                continue
        raise ex


def _hollow_enough(shape, out, t, open_ids):
    """Whether a shelled part is about what walls t thick weigh: between a fifth and twice the
    faces' area times t (and less than the part)."""
    try:
        opened = set(int(i) for i in (open_ids or ()))
        area = sum(float(f.area) for k, f in enumerate(shape.faces()) if k not in opened)
        v, v0 = float(out.volume), float(shape.volume)
    except Exception:
        return True
    return 0.2 * area * t < v < min(2.0 * area * t, 0.999 * v0)


def _grown_sheet(f, margin):
    """A face's surface grown past the face by about margin (less, or just its whole surface, or
    the face itself where growing fails: a round's surface grown far can fold), cut down to a box
    round the face."""
    b = f.bbox()
    a, c = _vec(b.min) - margin, _vec(b.max) + margin
    last = None
    for how in (("natural", margin), ("G1", margin), ("natural", margin / 3), ("G1", margin / 3), "untrimmed", "face"):
        try:
            if how == "untrimmed":
                grown = f.untrimmed()
            elif how == "face":
                grown = f.to_shell()
            else:
                grown = f.extend(how[1], continuity=how[0])
            gb = grown.bbox()
            if not (np.all(_vec(gb.min) >= a) and np.all(_vec(gb.max) <= c)):
                box = _s.Box(*[float(x) for x in (c - a)]).translate(tuple(float(x) for x in (a + c) / 2))
                piece = grown.intersect(box)
                if list(piece.faces()):
                    grown = piece
            return grown
        except Exception as ex:
            last = ex
    raise CadError(f"shell: a face's surface cannot be grown ({last})")


def _round_width(face):
    """How wide a round is across, between its two long rails (the widest of a few chords), or
    None when it has not two rails."""
    smooth = [e for e in face.edges() if _convexity(e) == "smooth"]
    rails = sorted(smooth, key=lambda e: -float(e.length))
    if len(rails) < 2:
        return None
    a, b = rails[0], rails[1]
    w = []
    for p in _fast_points(a, [0.2, 0.35, 0.5, 0.65, 0.8]):
        try:
            cp = b.closest_point(tuple(p))
            w.append(float(np.linalg.norm(_vec(getattr(cp, "point", cp)) - p)))
        except Exception:
            continue
    return max(w) if w else None


def _rounds_back(proxy, round_faces_, widths, size):
    """{edge index: radius} of a stand-in's edges where rounds were (taken off the part): an edge
    off the rounds but within their width of them, each radius the one whose round sinks as far
    below the edge as the part's round does (for faces turning theta at the edge, a round of
    radius R lies R (1 / cos(theta / 2) - 1) in from the sharp edge)."""
    out = {}
    for k, e in enumerate(proxy.edges()):
        if _convexity(e) not in ("convex", "concave"):
            continue
        fs = list(e.faces())
        if len(fs) != 2:
            continue
        Rs = []
        for m in _fast_points(e, [0.3, 0.5, 0.7]):
            try:
                ds = [float(f.distance_to(tuple(m))) for f in round_faces_]
            except Exception:
                break
            j = int(np.argmin(ds))
            d = ds[j]
            if not (size * 1e-6 < d < (widths[j] or 0.0)):
                break
            try:
                n0 = _unit(_vec(fs[0].normal_at(tuple(m))))
                n1 = _unit(_vec(fs[1].normal_at(tuple(m))))
            except Exception:
                break
            th = math.acos(max(-1.0, min(1.0, float(np.dot(n0, n1)))))
            if th < math.radians(5.0):
                break
            Rs.append(d / (1.0 / math.cos(th / 2.0) - 1.0))
        else:
            if Rs:
                out[k] = float(np.median(Rs))
    return out


def _nurbs_grid(nurbs, m, n):
    """(m, n, 3) points of a NURBS surface (the kernel's .nurbs() data) over its whole parameter
    rectangle, evenly in the parameters (here, without surfedit: the kernel worker has no bpy)."""
    pu, pv = (int(x) for x in nurbs.degrees)
    ku, kv = (np.asarray(x, dtype=float) for x in nurbs.knots)
    P = np.asarray([[tuple(q)[:3] for q in row] for row in nurbs.points], dtype=float)
    nu, nv = P.shape[0], P.shape[1]
    W = np.ones((nu, nv)) if nurbs.weights is None else np.asarray(nurbs.weights, dtype=float).reshape(nu, nv)
    Bu = _bspline_basis(ku, pu, nu, np.linspace(ku[pu], ku[nu], m))
    Bv = _bspline_basis(kv, pv, nv, np.linspace(kv[pv], kv[nv], n))
    H = np.concatenate([P * W[..., None], W[..., None]], axis=2)
    S = np.einsum("ai,ijk,bj->abk", Bu, H, Bv)
    return S[..., :3] / S[..., 3:4]


def _open_cylinder_sheet(face, margin, size):
    """A cylinder face's surface as an open piece of cylinder, just past the face round and along
    the axis by margin, or None (not a cylinder, or it wraps nearly all the way round). The kernel's
    shell fails on a face cut out of a whole (closed) cylinder away from its seam, a scoop: a
    concave cylinder cut into a body (body.cut(Cylinder) leaves one); on the same scoop on an open
    piece of cylinder it does not."""
    try:
        if str(face.geom_type).lower() != "cylinder":
            return None
        r = float(face.radius)
        o = _vec(face.axis.origin)
        d = _unit(_vec(face.axis.direction))
    except Exception:
        return None
    e1 = _unit(np.cross(d, [1.0, 0.0, 0.0]) if abs(d[0]) < 0.9 else np.cross(d, [0.0, 1.0, 0.0]))
    e2 = np.cross(d, e1)
    pts = list(_face_samples(face, most=40))
    for e in face.edges():
        pts.extend(_fast_points(e, np.linspace(0.0, 1.0, 17)))
    P = np.asarray(pts, dtype=float) - o
    th = np.sort(np.mod(np.arctan2(P @ e2, P @ e1), 2 * math.pi))
    gaps = np.diff(np.concatenate([th, [th[0] + 2 * math.pi]]))
    k = int(np.argmax(gaps))
    span = 2 * math.pi - float(gaps[k])
    if span > math.radians(300.0):
        return None
    pad = min(math.radians(30.0), (2 * math.pi - span) / 3.0)
    start = float(th[(k + 1) % len(th)]) - pad
    span += 2 * pad
    h = P @ d
    h0, h1 = float(h.min()) - margin, float(h.max()) + margin
    try:
        c = _s.Cylinder(r, h1 - h0, arc_size=math.degrees(span))
        cf = next(f for f in c.faces() if str(f.geom_type).lower() == "cylinder")
        a_loc = _vec(cf.axis.origin)
        z_lo = float(_vec(c.bbox().min)[2])
        u1 = math.cos(start) * e1 + math.sin(start) * e2
        u2 = np.cross(d, u1)
        R = np.column_stack([u1, u2, d])
        M = np.eye(4)
        M[:3, :3] = R
        M[:3, 3] = o + d * h0 - R @ np.array([a_loc[0], a_loc[1], z_lo])
        sheet = c.moved(_s.Location(M))
        sf = next(f for f in sheet.faces() if str(f.geom_type).lower() == "cylinder")
        if any(float(sf.distance_to(tuple(q + o))) > size * 1e-5 for q in P[:: max(1, len(P) // 30)]):
            return None
        return sf.to_shell()
    except Exception:
        return None


def _chain_grid(faces, size):
    """The faces of a soft-crease group as one grid of points (rows along the shared sides, the
    faces one after another across them), or None when they do not join side to side with the
    same spacing along the sides (only then is one surface through them a plain refit)."""
    grids = [_nurbs_grid(f.untrimmed().faces()[0].nurbs(), 64, 32) for f in faces]
    tol = size * 1e-5

    def sides(G):
        T = np.transpose(G, (1, 0, 2))
        return [G, G[:, ::-1], T, T[:, ::-1]]

    def join(A, B):
        for a in sides(A):
            for b in sides(B):
                for c in (b[:, ::-1], b[:, ::-1][::-1]):
                    if a.shape[0] == c.shape[0] and np.max(np.linalg.norm(a[:, -1] - c[:, 0], axis=1)) < tol:
                        return np.concatenate([a, c[:, 1:]], axis=1)
        return None

    G, left = grids[0], list(grids[1:])
    while left:
        for k, B in enumerate(left):
            J = join(G, B)
            if J is not None:
                G = J
                left.pop(k)
                break
        else:
            return None
    return G


def _run_on(G, grow, axis):
    """A grid of points run on straight past both its ends along an axis (0: rows, 1: columns) by
    about grow, along the end tangents."""
    if axis == 0:
        return np.transpose(_run_on(np.transpose(G, (1, 0, 2)), grow, 1), (1, 0, 2))
    step = float(np.mean(np.linalg.norm(np.diff(G, axis=1), axis=2)))
    k = max(1, int(math.ceil(grow / max(step, 1e-12))))
    d0 = G[:, 0] - G[:, 1]
    d1 = G[:, -1] - G[:, -2]
    d0 /= np.maximum(np.linalg.norm(d0, axis=1), 1e-300)[:, None]
    d1 /= np.maximum(np.linalg.norm(d1, axis=1), 1e-300)[:, None]
    ss = np.arange(1, k + 1) * (grow / k)
    head = G[:, :1] + d0[:, None, :] * ss[::-1][None, :, None]
    tail = G[:, -1:] + d1[:, None, :] * ss[None, :, None]
    return np.concatenate([head, G, tail], axis=1)


def _smooth_sheet(G, size, t, grow=0.0):
    """One smooth surface through a grid of points (least squares, a few CVs: a soft crease in the
    grid is rounded over a span), as a sheet run on past the grid's open ends by grow; with the
    largest distance of the grid from it. The fewest CVs that keep within a twentieth of the
    wall."""
    closed_u = float(np.max(np.linalg.norm(G[0] - G[-1], axis=1))) < size * 1e-6
    Q = G[::4, ::3].reshape(-1, 3)
    if grow > 0:
        # (run on in the data, so the surface stays closed round a tube over the part run on too)
        G = _run_on(G, grow, 1)
        if not closed_u:
            G = _run_on(G, grow, 0)
    m, n, _ = G.shape
    su = np.concatenate([[0.0], np.cumsum(np.linalg.norm(np.diff(G, axis=0), axis=2).mean(axis=1))])
    sv = np.concatenate([[0.0], np.cumsum(np.linalg.norm(np.diff(G, axis=1), axis=2).mean(axis=0))])
    su, sv = su / su[-1], sv / sv[-1]
    best = None
    for nu, nv in ((16, 12), (20, 16), (24, 20), (28, 26), (32, 32)):
        ku, kv = _uniform_knots(nu, 3), _uniform_knots(nv, 3)
        Bu, Bv = _bspline_basis(ku, 3, nu, su), _bspline_basis(kv, 3, nv, sv)
        C = np.einsum("ia,abk,jb->ijk", np.linalg.pinv(Bu), G, np.linalg.pinv(Bv))
        if closed_u:              # (closed round: the seam's rows meet, in line, as a smooth tube)
            mid = (C[0] + C[-1]) / 2.0
            tg = (C[1] - C[-2]) / 2.0
            C[0], C[-1], C[1], C[-2] = mid, mid, mid + tg, mid - tg
        try:
            rows = [[tuple(map(float, q)) for q in row] for row in C]
            sheet = _s.Shell.from_nurbs(((3, 3), (ku, kv), rows, None))
            f = sheet.faces()[0]
            dev = max(float(f.distance_to(tuple(q))) for q in Q)
        except Exception:
            continue
        if best is None or dev < best[1]:
            best = (sheet, dev)
        if dev <= t * 0.05:
            break
    return best


def _shell_by_proxy(shape, t: float, open_ids):
    """Shelling where the kernel's own shell fails: at soft creases (a straight loft's sections)
    crossed by other faces (a handle joining across them), and at scoops (a body cut with a
    cylinder) on thin walls. The inside is found on a stand-in for the part, and cut out of the
    part itself:

    - scoops are taken off and their cutters kept: the inside of a body cut by a cylinder is the
      inside of the body without the cut, cut by the cylinder grown by t (exactly);
    - rounds are taken off, each soft-crease group of faces refitted as one smooth surface (within
      a twentieth of the wall), cylinder faces put on open pieces of cylinder, openings pushed out
      past the part, the rounds put back by the kernel's fillet at their measured radii;
    - the kernel's shell of that gives the inside.

    Walls come out t thick to within that twentieth, and to within how closely the rounds put back
    match the part's."""
    size = max(body_size(shape), 1e-12)
    faces_s = list(shape.faces())
    work, cutters = _without_scoops(shape, open_ids, size)
    if cutters:
        open_w = []
        for k, f in enumerate(work.faces()):
            try:
                ip = f.interior_point()
                q = tuple(_vec(getattr(ip, "point", ip)))
            except Exception:
                continue
            if any(float(faces_s[j].distance_to(q)) <= size * 1e-6 for j in open_ids):
                open_w.append(k)
        if len(open_w) < len(set(open_ids)):
            raise CadError("shell: the open faces are not found again")
    else:
        open_w = list(open_ids)
    inside = _proxy_inside(work, t, open_w, size, changed=bool(cutters))
    for o, d, r in cutters:
        inside = _call("shell", inside.cut, _axis_cylinder(o, d, r + t, 4.0 * size))
    out = _call("shell", shape.cut, inside)
    area = sum(float(f.area) for k, f in enumerate(faces_s) if k not in set(open_ids))
    v = float(out.volume)
    if not isinstance(out, _s.Part) or not (0.3 * area * t < v < 2.0 * area * t):
        raise CadError("shell: the inside found does not leave walls of the thickness")
    # (the kernel's check flags spots of the refitted inside, a seam it runs near: geometry that is
    # still sound; what matters is the wall: nowhere thinner than most of t)
    thin = _thinnest_wall(shape, out)
    if thin is None or thin < 0.6 * t:
        raise CadError("shell: the inside found leaves the wall too thin in places")
    return out


def _axis_cylinder(o, d, r, length):
    """A solid cylinder of radius r about the axis through o along d, length long, its middle at o."""
    d = _unit(_vec(d))
    e1 = _unit(np.cross(d, [1.0, 0.0, 0.0]) if abs(d[0]) < 0.9 else np.cross(d, [0.0, 1.0, 0.0]))
    M = np.eye(4)
    M[:3, :3] = np.column_stack([e1, np.cross(d, e1), d])
    c = _s.Cylinder(float(r), float(length))
    M[:3, 3] = _vec(o) - M[:3, :3] @ _vec(c.center())
    return c.moved(_s.Location(M))


def _without_scoops(shape, open_ids, size):
    """(the part without its scoops, [(axis point, axis direction, radius)] of their cutters): its
    concave cylinder faces, when cutting the part without them by whole cylinders gives the part
    back (they were cut by cylinders running right through); else (the part, [])."""
    faces = list(shape.faces())
    scoops, cutters = [], []
    for k, f in enumerate(faces):
        if k in set(open_ids) or str(f.geom_type).lower() != "cylinder":
            continue
        try:
            ip = f.interior_point()
            p = _vec(getattr(ip, "point", ip))
            n = _unit(_vec(f.normal_at(tuple(p))))
            o, d, r = _vec(f.axis.origin), _unit(_vec(f.axis.direction)), float(f.radius)
        except Exception:
            continue
        foot = o + d * float(np.dot(p - o, d))
        if float(np.dot(n, foot - p)) > 0.5 * r:          # (the normal points at the axis: concave)
            scoops.append(k)
            cutters.append((foot, d, r))
    if not scoops:
        return shape, []
    try:
        whole = rebuild_without(shape, scoops)
        back = whole
        for o, d, r in cutters:
            back = back.cut(_axis_cylinder(o, d, r, 4.0 * size))
        if abs(float(back.volume) - float(shape.volume)) > 1e-4 * float(shape.volume):
            return shape, []
    except Exception:
        return shape, []
    return whole, cutters


def _proxy_inside(shape, t, open_ids, size, changed=False):
    """The inside (a solid) of the stand-in of a part, as _shell_by_proxy describes; changed: the
    part is already a stand-in (scoops taken off), so it goes on even with nothing more to do."""
    faces0 = list(shape.faces())
    rounds = [i for i in round_faces(shape) if i not in set(open_ids)]
    widths = {i: _round_width(faces0[i]) for i in rounds}
    rounds = [i for i in rounds if widths[i]]
    base = shape
    if rounds:
        try:
            base = remove_fillet_faces(shape, rounds)
        except CadError:
            base, rounds = shape, []
    faces = list(base.faces())
    # the openings on the stand-in: its faces lying on the part's open faces
    opened = set()
    for k, f in enumerate(faces):
        try:
            ip = f.interior_point()
            q = tuple(_vec(getattr(ip, "point", ip)))
        except Exception:
            continue
        if any(float(faces0[j].distance_to(q)) <= size * 1e-6 for j in open_ids):
            opened.add(k)
    if len(opened) < len(set(open_ids)):
        raise CadError("shell: the open faces are not found again")
    margin = max(8.0 * t, 0.03 * size)
    sheets, done, smoothed = [], set(), False
    for g in _soft_groups(base, faces, opened):
        G = _chain_grid([faces[k] for k in g], size)
        if G is None:
            continue
        got = _smooth_sheet(G, size, t, grow=margin)
        if got is None or got[1] > t * 0.05:
            continue
        sheets.append(got[0])
        done.update(g)
        smoothed = True
    opened_up = {}
    for k, f in enumerate(faces):
        if k not in done:
            sheet = _open_cylinder_sheet(f, margin, size)
            if sheet is not None:
                opened_up[k] = sheet
    if not smoothed and not rounds and not opened_up and not changed:
        raise CadError("shell: no soft crease to smooth")
    for k, f in enumerate(faces):
        if k in done:
            continue
        grown = opened_up.get(k) or _grown_sheet(f, margin)
        sheets.append(grown.offset(2.0 * t) if k in opened else grown)
    cells = None
    for order in (sheets, sheets[::-1]):
        cells = _sheet_cells(order, size)
        if cells and cells[0]:
            break
    if not cells or not cells[0]:
        raise CadError("shell: the stand-in does not close up")
    proxy = _solid_of_cells(base, cells[0])
    if rounds:
        # the rounds back on: the stand-in's edges where they were, at their radii
        pe = list(proxy.edges())
        picked = _rounds_back(proxy, [faces0[i] for i in rounds], [widths[i] for i in rounds], size)
        if picked:
            R = float(np.median(list(picked.values())))
            try:
                proxy = fillet(proxy, sorted(picked), R, explain=False)
            except Exception:
                # concave rounds only can go without: the inside runs sharp there, the wall thicker
                if any(_convexity(pe[k]) == "convex" for k in picked):
                    raise CadError("shell: the rounds cannot be put back on the stand-in")
    hollow = _call("shell", proxy.shell, t, None)
    return _call("shell", proxy.cut, hollow)


def _thinnest_wall(part, hollow):
    """How far the hollowed part's inside faces come to the part's own faces at their nearest
    (sampled), or None when there is no inside face."""
    outer = list(part.faces())
    size = max(body_size(part), 1e-12)
    thin = None
    for f in hollow.faces():
        pts = _face_samples(f, most=10)
        if not pts:
            continue
        try:
            d0 = min(float(g.distance_to(tuple(pts[0]))) for g in outer)
        except Exception:
            continue
        if d0 <= size * 1e-6:
            continue                       # (one of the part's own faces, cut down)
        for p in pts:
            try:
                d = min(float(g.distance_to(tuple(p))) for g in outer)
            except Exception:
                continue
            thin = d if thin is None else min(thin, d)
    return thin


def _soft_groups(shape, faces, skip=()):
    """Faces joined across soft creases (edges where they meet at a few degrees, a straight loft's
    sections): [[face index, ...], ...] of two or more. Their surfaces, moved apart one by one, run
    past each other almost tangent where they cross; moved together as one sheet they do not."""
    parent = list(range(len(faces)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    index = {f: i for i, f in enumerate(faces)}
    for e in shape.edges():
        js = [index.get(g) for g in e.faces()]
        if len(js) != 2 or None in js or js[0] == js[1] or js[0] in skip or js[1] in skip:
            continue
        try:
            angs = []
            for m in _fast_points(e, [0.25, 0.5, 0.75]):
                n0 = _unit(_vec(faces[js[0]].normal_at(tuple(m))))
                n1 = _unit(_vec(faces[js[1]].normal_at(tuple(m))))
                angs.append(math.degrees(math.acos(max(-1.0, min(1.0, float(np.dot(n0, n1)))))))
        except Exception:
            continue
        if 0.3 < min(angs) and max(angs) < 25.0:
            ra, rb = find(js[0]), find(js[1])
            if ra != rb:
                parent[ra] = rb
    groups = {}
    for i in range(len(faces)):
        groups.setdefault(find(i), []).append(i)
    return [g for g in groups.values() if len(g) > 1]


def _shell_by_cells(shape, t: float, open_ids):
    """A part hollowed to walls t thick (inward), with open_ids open: every face's surface, grown a
    little past the face, moved t inward (an opening's t outward, so the inside runs out through
    it); the closed cell those sheets make inside the part is the inside, cut out of the part.
    Faces meeting at soft creases are moved together, as one sheet of their whole surfaces.
    Corners come out sharp: the inside's faces run on until they meet."""
    faces = list(shape.faces())
    size = max(body_size(shape), 1e-12)
    margin = max(8.0 * t, 0.03 * size)
    opened = set(int(i) for i in open_ids)
    sheets = []
    done = set()
    for g in _soft_groups(shape, faces, opened):
        try:
            whole, rep = _s.stitch(*[faces[k].untrimmed() for k in g], report=True)
            if int(getattr(rep, "sewn_edges", 0) or 0) < len(g) - 1:
                continue                      # (their whole surfaces do not meet: one by one)
            moved = whole.offset(-t)
        except Exception:
            continue
        sheets.append(moved)
        done.update(g)
    for k, f in enumerate(faces):
        if k in done:
            continue
        b = f.bbox()
        lo, hi = _vec(b.min), _vec(b.max)
        moved, last = None, None
        # the face's surface grown past it (less and less, then just the face itself: a round's
        # surface grown far can fold), cut down to a box round the face, moved
        for how in (("natural", margin), ("G1", margin), ("natural", margin / 3), ("G1", margin / 3), "untrimmed", "face"):
            try:
                if how == "untrimmed":
                    grown = f.untrimmed()
                elif how == "face":
                    grown = f.to_shell()
                else:
                    grown = f.extend(how[1], continuity=how[0])
                gb = grown.bbox()
                a, c = lo - margin, hi + margin
                if not (np.all(_vec(gb.min) >= a) and np.all(_vec(gb.max) <= c)):
                    box = _s.Box(*[float(x) for x in (c - a)]).translate(tuple(float(x) for x in (a + c) / 2))
                    piece = grown.intersect(box)
                    if list(piece.faces()):
                        grown = piece
                moved = grown.offset(t if k in opened else -t)
                break
            except Exception as ex:
                last = ex
                continue
        if moved is None:
            raise CadError(f"shell: face {k} cannot be moved {t:.6g} inward ({last})")
        sheets.append(moved)
    # (the kernel's fuse of many sheets can fail in one order and not another)
    got = None
    for order in (sheets, sheets[::-1], sorted(sheets, key=lambda x: -float(x.area))):
        got = _sheet_cells(order, size)
        if got and got[0]:
            break
    if not got or not got[0]:
        raise CadError("shell: the moved faces do not close round an inside")
    area = sum(float(f.area) for k, f in enumerate(faces) if k not in opened)
    vol = float(shape.volume)
    best = None
    for c in got[0]:
        pts = _cell_points(c)
        if not pts:
            continue
        try:
            n = sum(1 for r in shape._classify([tuple(p) for p in pts]) if r[0] == "inside")
        except Exception:
            n = sum(1 for p in pts if shape.contains(tuple(p)))
        if n > len(pts) * 0.5:
            v = float(c.volume)
            if best is None or v > best[0]:
                best = (v, c)
    if best is None:
        raise CadError("shell: no inside found")
    if not (0.3 * area * t < vol - best[0] < 2.0 * area * t):
        raise CadError("shell: the inside found does not leave walls of the thickness")
    out = _call("shell", shape.cut, best[1])
    # (a wall about t thick all round: the volume is near the area times t)
    v = float(out.volume)
    if not (0.3 * area * t < v < 2.0 * area * t) or out.check():
        raise CadError("shell: the inside found does not leave walls of the thickness")
    return out


def _boolean_once(a, b, op: str):
    if op == "UNION":
        return _call("union", a.fuse, b)
    if op == "DIFFERENCE":
        return _call("difference", a.cut, b)
    if op == "INTERSECT":
        return _call("intersect", a.intersect, b)
    raise CadError(f"unknown boolean {op}")


def _rescales(size: float):
    """Scale factors to try a failed kernel step at (a model a few centimetres across, in metres, sits
    near the kernel's fixed tolerances: the same step at ten or a hundred times the size goes
    through): those bringing it towards 1 to 100 across first."""
    out = []
    if size < 10.0:
        k = 10.0 ** math.ceil(math.log10(max(10.0 / max(size, 1e-12), 10.0)))
        out += [k, k * 10.0, 10.0, 100.0]
    else:
        out += [0.1, 0.01, 10.0]
    seen = []
    for k in out:
        if k not in seen and k != 1.0:
            seen.append(k)
    return seen


def boolean(a, b, op: str):
    """Union / difference / intersection. When the kernel fails, the same operation is tried with
    both bodies scaled up (or down) together and the result scaled back: exact, as scaling is; it
    gets small parts (a few centimetres, in metres) past the kernel's fixed tolerances."""
    try:
        return _boolean_once(a, b, op)
    except CadError as ex:
        size = max(body_size(a), body_size(b))
        for k in _rescales(size):
            try:
                r = _boolean_once(a.scale(k), b.scale(k), op).scale(1.0 / k)
            except Exception:
                continue
            try:
                if r.is_valid() and len(r.faces()):
                    return r
            except Exception:
                continue
        raise ex


def mirror(shape, plane: str = "YZ", face_id=None):
    """Mirrored copy across a local plane, or across a picked planar face (face_id)."""
    if face_id is not None:
        f = shape.faces()[face_id]
        if not bool(f.is_planar):
            raise CadError("mirror: the face to mirror across must be flat")
        p, n = face_frame(shape, face_id)
        pl = _s.Plane(tuple(p), z_dir=tuple(n))
        return _call("mirror", shape.mirror, pl)
    pl = {"YZ": _s.Plane.YZ, "XZ": _s.Plane.XZ, "XY": _s.Plane.XY}[plane]
    return _call("mirror", shape.mirror, pl)


# ----------------------------------------------------------------------------- group 1: surfaces

def offset_body(shape, distance: float, corners: str = "round"):
    """A surface moved along its normals, or a solid grown / shrunk (round or sharp corners)."""
    if isinstance(shape, _s.Part):
        return _call("offset", _s.offset, shape, distance, corners=corners)
    return _call("offset", shape.offset, distance)


def extend_sheet(shape, edge_ids, distance: float, continuity: str = "natural"):
    """A surface grown past picked open edges (all growable sides of a one-face sheet when none is
    picked). Faces of a multi-face sheet are extended one by one and sewn back."""
    if isinstance(shape, _s.Part):
        raise CadError("extend: works on surfaces (a solid's faces are extended by Push/Pull)")
    edges = _edges(shape, edge_ids) if edge_ids else []
    faces = list(shape.faces())
    if not edges:
        if len(faces) != 1:
            raise CadError("extend: pick the open edges to extend past (Shift+click adds)")
        return _call("extend", shape.extend, distance, continuity=continuity.lower() if continuity == "natural" else continuity)
    for e in edges:
        if len(e.faces()) != 1:
            raise CadError("extend: pick open edges (on the surface's border)")
    by_face = {}
    for e in edges:
        f = e.faces()[0]
        k = next(i for i, x in enumerate(faces) if float(np.linalg.norm(_vec(x.center()) - _vec(f.center()))) < 1e-12
                 and abs(float(x.area) - float(f.area)) < 1e-12)
        by_face.setdefault(k, []).append(e)
    out = []
    for i, f in enumerate(faces):
        if i in by_face:
            sides = [x for x in f.edges() if any(float(np.linalg.norm(_vec(x.point_at(0.5)) - _vec(e.point_at(0.5))))
                                                 < 1e-9 for e in by_face[i])]
            out += list(_call("extend", f.extend, distance, sides=sides, continuity=continuity).faces())
        else:
            out.append(f)
    return _call("extend", _s.stitch, out) if len(out) > 1 else _call("extend", _s.stitch, out[0])


def ruled_surface(a, b):
    """A ruled surface between two curves: one untrimmed NURBS patch between two open curves (its
    CVs the curves' own, made compatible: no trimmed plane when they lie in one plane), else the
    kernel's ruled surface."""
    got = _open_skin([a, b], ruled=True)
    if got is not None:
        return got
    return _call("ruled", _s.ruled, a, b)


# ----------------------------------------------------------------------------- untrimmed skins of open curves

def _basis_rows(knots, p: int, n: int, us) -> np.ndarray:
    """(len(us), n): the B-spline basis functions of degree p at each parameter (Cox - de Boor; the
    domain's right end belongs to the last span)."""
    k = np.asarray(knots, dtype=float)
    lo, hi = k[p], k[n]
    out = np.zeros((len(us), n))
    for r, u in enumerate(us):
        u = min(max(float(u), lo), hi)
        span = p
        while span < n - 1 and k[span + 1] <= u:
            span += 1
        N = np.zeros(p + 1)
        N[0] = 1.0
        left, right = np.zeros(p + 1), np.zeros(p + 1)
        for j in range(1, p + 1):
            left[j] = u - k[span + 1 - j]
            right[j] = k[span + j] - u
            saved = 0.0
            for q in range(j):
                den = right[q + 1] + left[j - q]
                tmp = N[q] / den if den != 0 else 0.0
                N[q] = saved + right[q + 1] * tmp
                saved = left[j - q] * tmp
            N[j] = saved
        out[r, span - p:span + 1] = N
    return out


def _greville(knots, p: int, n: int) -> np.ndarray:
    k = np.asarray(knots, dtype=float)
    return np.array([k[i + 1:i + p + 1].mean() if p > 0 else k[i] for i in range(n)])


def _inner_knots(knots, p: int, n: int):
    """[(value, multiplicity)] of a clamped knot vector's inner knots."""
    k = [float(x) for x in knots]
    lo, hi = k[p], k[n]
    span = max(hi - lo, 1e-300)
    out = []
    for x in k[p + 1:n]:
        if out and abs(out[-1][0] - x) <= span * 1e-10:
            out[-1] = (out[-1][0], out[-1][1] + 1)
        else:
            out.append((x, 1))
    return out


def _knot_vector(lo, hi, p: int, inner):
    return [lo] * (p + 1) + [x for x, m in inner for _ in range(m)] + [hi] * (p + 1)


def _refit(curve, knots, p: int):
    """A curve (degree, knots, homogeneous CVs) put on a richer knot vector of degree p that contains
    its spline space (degree raised, knots added): the same curve exactly."""
    p0, k0, H0 = curve
    n0, n = len(H0), len(knots) - p - 1
    g = _greville(knots, p, n)
    S = _basis_rows(k0, p0, n0, g) @ H0
    return p, list(map(float, knots)), np.linalg.solve(_basis_rows(knots, p, n, g), S)


def _edge_curve(e, lo: float, hi: float):
    """An edge as (degree, knots on [lo, hi], homogeneous CVs)."""
    nb = e.nurbs()
    p = int(nb.degree)
    P = np.array([tuple(q)[:3] for q in nb.points], dtype=float)
    W = np.ones(len(P)) if nb.weights is None else np.asarray(nb.weights, dtype=float)
    k = np.asarray(nb.knots, dtype=float)
    a, b = k[p], k[len(P)]
    k = lo + (k - a) * (hi - lo) / (b - a)
    return p, list(map(float, k)), np.hstack([P * W[:, None], W[:, None]])


def _reverse_curve(c):
    p, k, H = c
    lo, hi = k[0], k[-1]
    return p, [lo + hi - x for x in reversed(k)], H[::-1].copy()


def _elevated(c, p: int):
    p0, k0, H0 = c
    if p0 == p:
        return c
    n0 = len(H0)
    inner = [(x, min(m + p - p0, p)) for x, m in _inner_knots(k0, p0, n0)]
    return _refit(c, _knot_vector(k0[p0], k0[n0], p, inner), p)


def _section_curve(sec, p_min: int = 1):
    """An open section (a wire or an edge) as one curve (degree, knots on [0, 1], homogeneous CVs):
    its edges in order, each raised to the highest degree among them, joined end to end (knots of
    full multiplicity at the joints), parameterized by length. None when it is not an open chain."""
    kind = type(sec).__name__
    if kind not in ("Wire", "Edge"):
        return None
    try:
        if bool(sec.is_closed):
            return None
        edges = [sec] if kind == "Edge" else list(sec.edges())
    except Exception:
        return None
    if not edges:
        return None
    lengths = [max(float(e.length), 1e-300) for e in edges]
    total = sum(lengths)
    curves, at = [], 0.0
    for e, L in zip(edges, lengths):
        curves.append(_edge_curve(e, at / total, (at + L) / total))
        at += L
    # each piece running on from the one before it
    tol = max(total, 1e-12) * 1e-6
    point = lambda H, i: H[i, :3] / H[i, 3]  # noqa: E731
    for i in range(len(curves)):
        if i == 0 and len(curves) > 1:
            a, b = curves[0], curves[1]
            ends_b = (point(b[2], 0), point(b[2], -1))
            if min(np.linalg.norm(point(a[2], 0) - q) for q in ends_b) < min(np.linalg.norm(point(a[2], -1) - q)
                                                                            for q in ends_b):
                curves[0] = _reverse_curve(a)
        elif i > 0:
            prev_end = point(curves[i - 1][2], -1)
            c = curves[i]
            if np.linalg.norm(point(c[2], 0) - prev_end) > np.linalg.norm(point(c[2], -1) - prev_end):
                c = _reverse_curve(c)
            if np.linalg.norm(point(c[2], 0) - prev_end) > tol:
                return None             # not one chain
            curves[i] = c
    p = max(p_min, max(c[0] for c in curves))
    curves = [_elevated(c, p) for c in curves]
    knots = list(curves[0][1][:-1])
    H = [curves[0][2]]
    for c in curves[1:]:
        f = H[-1][-1, 3] / c[2][0, 3]          # the same weight at the joint (a rational curve times
        H.append(c[2][1:] * f)                 # a constant is the same curve)
        knots += list(c[1][p + 1:-1])
    knots += [curves[-1][1][-1]]
    H = np.vstack(H)
    if len(knots) - p - 1 != len(H):
        return None
    return p, knots, H


def _compatible(curves):
    """Curves raised to one degree and put on one knot vector (the union of their knots)."""
    p = max(c[0] for c in curves)
    curves = [_elevated(c, p) for c in curves]
    inner = {}
    for c in curves:
        for x, m in _inner_knots(c[1], p, len(c[2])):
            key = next((y for y in inner if abs(y - x) < 1e-10), x)
            inner[key] = max(inner.get(key, 0), m)
    kv = _knot_vector(0.0, 1.0, p, sorted(inner.items()))
    return [_refit(c, kv, p) for c in curves]


def _open_skin(sections, ruled: bool = False):
    """One untrimmed NURBS sheet through open sections (wires or edges): their curves made
    compatible, straight between neighbouring sections (ruled, or two sections) or a smooth skin
    through them (degree up to 3 across). None when a section is closed or not a curve (the
    kernel's loft makes those)."""
    if len(sections) < 2:
        return None
    try:
        curves = [_section_curve(s_) for s_ in sections]
        if any(c is None for c in curves):
            return None
        # each running the way the first runs
        pt = lambda c, i: c[2][i, :3] / c[2][i, 3]  # noqa: E731
        for i in range(1, len(curves)):
            a, b = curves[i - 1], curves[i]
            same = np.linalg.norm(pt(a, 0) - pt(b, 0)) + np.linalg.norm(pt(a, -1) - pt(b, -1))
            flip = np.linalg.norm(pt(a, 0) - pt(b, -1)) + np.linalg.norm(pt(a, -1) - pt(b, 0))
            if flip < same:
                curves[i] = _reverse_curve(b)
        curves = _compatible(curves)
        p, ku = curves[0][0], curves[0][1]
        Hs = np.stack([c[2] for c in curves], axis=1)          # (n along u, sections, 4)
        m = len(curves)
        # parameters across: the mean distance between neighbouring sections
        P3 = Hs[..., :3] / Hs[..., 3:4]
        d = np.linalg.norm(np.diff(P3, axis=1), axis=2).mean(axis=0)
        if np.any(d <= 0):
            return None
        vs = np.concatenate([[0.0], np.cumsum(d) / d.sum()])
        if ruled or m == 2:
            q = 1
            kv = [0.0, 0.0] + list(vs[1:-1]) + [1.0, 1.0]
            C = Hs
        else:
            q = min(3, m - 1)
            kv = [0.0] * (q + 1) + [float(np.mean(vs[j:j + q])) for j in range(1, m - q)] + [1.0] * (q + 1)
            B = _basis_rows(kv, q, m, vs)
            C = np.einsum("ij,ajk->aik", np.linalg.inv(B), Hs)
        W = C[..., 3]
        if np.any(W <= 0):
            return None
        P = C[..., :3] / W[..., None]
        rational = not np.allclose(W, W.flat[0])

        def sheet(i0, i1, knots):
            rows = [[tuple(map(float, x)) for x in row] for row in P[i0:i1 + 1]]
            wts = [list(map(float, row)) for row in W[i0:i1 + 1]] if rational else None
            return _s.Shell.from_nurbs(((int(p), int(q)), (list(knots), list(map(float, kv))), rows, wts))

        S3 = P3
        # one patch, split where a section has a corner (a crease inside one face is not valid):
        # at a joint knot (full multiplicity) whose CVs turn there
        cuts, j = [], p + 1
        n = len(P)
        while j < n:
            run = 1
            while j + run < len(ku) and abs(ku[j + run] - ku[j]) < 1e-12:
                run += 1
            if run >= p and ku[j] < ku[-1]:
                c = j - 1                              # the CV at the joint
                if 0 < c < n - 1:
                    a_, b_ = S3[c] - S3[c - 1], S3[c + 1] - S3[c]     # (the sections' own CVs)
                    na, nb = np.linalg.norm(a_, axis=1), np.linalg.norm(b_, axis=1)
                    ok_ = (na > 0) & (nb > 0)
                    cos = np.einsum("ij,ij->i", a_[ok_], b_[ok_]) / (na[ok_] * nb[ok_])
                    if np.any(cos < 1 - 1e-9):
                        cuts.append((c, ku[j]))
            j += run
        if not cuts:
            got = sheet(0, n - 1, ku)
            return got if not got.check() else None
        pieces, c0, k0 = [], 0, 0
        for c, x in cuts + [(n - 1, ku[-1])]:
            if x < ku[-1]:
                first = next(i for i, y in enumerate(ku) if abs(y - x) < 1e-12)
                kn = ku[k0:first + p] + [x] if k0 == 0 else [ku[k0]] * (p + 1) + ku[k0 + p:first + p] + [x]
            else:
                kn = ku[k0:] if k0 == 0 else [ku[k0]] * (p + 1) + ku[k0 + p:]
            pieces.append(sheet(c0, c, kn))
            if x < ku[-1]:
                c0 = c
                k0 = next(i for i, y in enumerate(ku) if abs(y - x) < 1e-12)
        faces = [f for sh in pieces for f in sh.faces()]
        got = _call("loft", _s.stitch, faces)
        return got if not got.check() else None
    except Exception:
        return None


def network_surface(u, v, level: str = "G0", faces_u=None, faces_v=None):
    """A surface through a network of curves. Where the curves of one direction are closed (rings
    round a body: a bottle's sections with profiles running between them) it is a closed Gordon
    surface through all of them; otherwise the kernel's network surface.

    level "G1" / "G2" with faces_u / faces_v (the face each curve is an open edge of, or None): the
    surface also meets those faces along the outer curves tangentially / with the same curvature
    across (see _matched_patch), still through the inner curves. LAST_NOTE["network"] says how
    closely."""
    LAST_NOTE["network"] = ""
    out = _network_plain(u, v)
    level = str(level or "G0").upper()
    if level == "G0":
        return out
    faces_u = list(faces_u or [None] * len(u))
    faces_v = list(faces_v or [None] * len(v))
    if not any(f is not None for f in faces_u + faces_v):
        LAST_NOTE["network"] = "G0: none of its outer curves is an open edge of a surface"
        return out
    if any(bool(w.is_closed) for w in list(u) + list(v)) or len(out.faces()) != 1:
        LAST_NOTE["network"] = "G0: matching surfaces is for open networks (four outer curves)"
        return out
    f0 = out.faces()[0]
    size = max(float(out.bbox().diagonal), 1e-12)
    outer, inner = [], []
    for w, fc in list(zip(u, faces_u)) + list(zip(v, faces_v)):
        try:
            uv = [f0.uv_at(tuple(q)) for q in _wire_samples(w, 5)]
        except Exception:
            uv = []
        on_border = uv and any(all(abs(x[i] - b) < 1e-3 for x in uv) for i in (0, 1) for b in (0.0, 1.0))
        (outer if on_border else inner).append((w, fc))
    if not any(fc is not None for _w, fc in outer):
        LAST_NOTE["network"] = "G0: none of its outer curves is an open edge of a surface"
        return out
    extra = []
    for w, _fc in inner:
        for q in _wire_samples(w, 24)[1:-1]:
            uu, vv = f0.uv_at(tuple(q))
            extra.append((uu, vv, q))
    got = matched_patch(outer, level, base=lambda a, b: f0.position_at(float(a), float(b)), extra=extra)
    if got is None:
        return out
    sheet, info = got
    mid = [float(sheet.distance_to(tuple(q))) for uu, vv, q in extra if min(uu, 1 - uu, vv, 1 - vv) >= 0.2]
    near = [float(sheet.distance_to(tuple(q))) for uu, vv, q in extra if min(uu, 1 - uu, vv, 1 - vv) < 0.2]
    off = max(mid or [0.0])
    off_n = max(near or [0.0])
    inner_s = ""
    if extra:
        inner_s = f", the inner curves within {_fmt_len(off)}"
        if off_n > 2 * off and off_n > size * 1e-5:
            inner_s += f" ({_fmt_len(off_n)} near the outer curves, where the surfaces decide)"
    LAST_NOTE["network"] = (f"{level} within {info['angle']:.2f}° of the surfaces"
                            + (f", curvature within {100 * info['curvature']:.2g}%" if level == "G2" else "")
                            + inner_s)
    return sheet


def _wire_samples(w, n: int):
    """n + 1 points spread along a wire, end to end."""
    P, s = _polyline(w, per_edge=max(8, n))
    if s[-1] <= 0:
        return [P[0]]
    at = np.linspace(0.0, s[-1], n + 1)
    return [np.array([np.interp(x, s, P[:, j]) for j in range(3)]) for x in at]


def _fmt_len(x: float) -> str:
    return f"{x * 1000:.3g} mm" if x < 1 else f"{x:.3g} m"


def _network_plain(u, v):
    u, v = list(u), list(v)
    cu = [bool(w.is_closed) for w in u]
    cv = [bool(w.is_closed) for w in v]
    if any(cu) or any(cv):
        if all(cu) and not any(cv):
            return _closed_network(u, v)
        if all(cv) and not any(cu):
            return _closed_network(v, u)
        raise CadError("network: the closed curves must all run the same way (rings), the curves across "
                       "them open (from the first ring to the last)")
    return _call("network", _s.network, u, v)


# ----------------------------------------------------------------------------- closed networks (Gordon)

def _polyline(w, per_edge: int = 240):
    """Dense points along a wire, in its order (a closed wire without its repeated end) and the
    length along it at each."""
    pts = []
    for e in w.edges():
        q = [_vec(e.point_at(float(x))) for x in np.linspace(0.0, 1.0, per_edge + 1)]
        if pts and float(np.linalg.norm(q[0] - pts[-1])) > float(np.linalg.norm(q[-1] - pts[-1])):
            q = q[::-1]
        pts += q[1:] if pts else q
    P = np.array(pts)
    if bool(w.is_closed) and len(P) > 2 and float(np.linalg.norm(P[0] - P[-1])) < 1e-12 + 1e-9 * float(
            np.ptp(P, axis=0).max()):
        P = P[:-1]
    s = np.concatenate([[0.0], np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))])
    return P, s


def _meet(wa, Pa, sa, wb, Pb, sb, closed_a):
    """Where two curves meet: (point, length along a, length along b, gap)."""
    d = np.linalg.norm(Pa[:, None, :] - Pb[None, :, :], axis=2)
    ia, ib = np.unravel_index(int(np.argmin(d)), d.shape)
    p = 0.5 * (Pa[ia] + Pb[ib])
    ea, eb = list(wa.edges()), list(wb.edges())
    for _ in range(8):                            # onto both exact curves, back and forth
        qa = min((_closest(e, p) for e in ea), key=lambda x: float(np.linalg.norm(x - p)))
        qb = min((_closest(e, qa) for e in eb), key=lambda x: float(np.linalg.norm(x - qa)))
        p = 0.5 * (qa + qb)
    gap = float(np.linalg.norm(qa - qb))

    def along(P, s, i, x, closed):
        best = (float("inf"), s[i])
        n = len(P)
        for k in (i - 1, i):
            if not closed and (k < 0 or k + 1 >= n):
                continue
            a_, b_ = P[k % n], P[(k + 1) % n]
            sa_ = s[k % n]
            sb_ = s[(k + 1) % n] if (k + 1) % n else s[-1] + float(np.linalg.norm(P[-1] - P[0]))
            ab = b_ - a_
            L2 = float(np.dot(ab, ab))
            tt = 0.0 if L2 == 0 else min(max(float(np.dot(x - a_, ab)) / L2, 0.0), 1.0)
            dist = float(np.linalg.norm(a_ + tt * ab - x))
            if dist < best[0]:
                best = (dist, sa_ + tt * (sb_ - sa_))
        return best[1]

    return p, along(Pa, sa, ia, p, closed_a), along(Pb, sb, ib, p, False), gap


def _cardinal_b(d: int, x: np.ndarray) -> np.ndarray:
    """The uniform B-spline of degree d on [0, d + 1)."""
    x = np.asarray(x, dtype=float)
    if d == 0:
        return ((x >= 0) & (x < 1)).astype(float)
    return (x * _cardinal_b(d - 1, x) + (d + 1 - x) * _cardinal_b(d - 1, x - 1)) / d


def _periodic_rows(K: int, d: int, ts) -> np.ndarray:
    """(len(ts), K): a periodic uniform B-spline basis of degree d with K spans on [0, 1)."""
    ts = np.asarray(ts, dtype=float) % 1.0
    out = np.zeros((len(ts), K))
    x = ts * K
    span = np.floor(x).astype(int)
    for r in range(d + 1):
        k = (span - r) % K
        np.add.at(out, (np.arange(len(ts)), k), _cardinal_b(d, x - span + r))
    return out


def _fit(rows, data, node_rows=None, node_data=None, periodic=False):
    """Least squares control points for points `data` at basis rows, nodes held (heavily weighted);
    a faint pull towards even CV spacing keeps spans with few points from wandering."""
    if node_rows is not None:
        w = 1e4
        rows = np.vstack([rows, w * node_rows])
        data = np.vstack([data, w * node_data])
    k = rows.shape[1]
    if k >= 3:
        D = np.zeros((k if periodic else k - 2, k))
        for r in range(D.shape[0]):
            D[r, r % k], D[r, (r + 1) % k], D[r, (r + 2) % k] = 1e-5, -2e-5, 1e-5
        rows = np.vstack([rows, D])
        data = np.vstack([data, np.zeros((D.shape[0], data.shape[1]))])
    return np.linalg.lstsq(rows, data, rcond=None)[0]


def _pchip(x, y, xs):
    """A monotone cubic through (x, y) (Fritsch - Carlson), at xs."""
    x, y = np.asarray(x, dtype=float), np.asarray(y, dtype=float)
    h = np.diff(x)
    dl = np.diff(y) / h
    d = np.zeros_like(y)
    for i in range(1, len(x) - 1):
        if dl[i - 1] * dl[i] > 0:
            w1, w2 = 2 * h[i] + h[i - 1], h[i] + 2 * h[i - 1]
            d[i] = (w1 + w2) / (w1 / dl[i - 1] + w2 / dl[i])
    d[0], d[-1] = dl[0], dl[-1]
    xs = np.asarray(xs, dtype=float)
    k = np.clip(np.searchsorted(x, xs, side="right") - 1, 0, len(x) - 2)
    t_ = (xs - x[k]) / h[k]
    h00, h10, h01, h11 = 2 * t_**3 - 3 * t_**2 + 1, t_**3 - 2 * t_**2 + t_, -2 * t_**3 + 3 * t_**2, t_**3 - t_**2
    return h00 * y[k] + h10 * h[k] * d[k] + h01 * y[k + 1] + h11 * h[k] * d[k + 1]


def _smooth_params(nodes_t, nodes_s, s_samples, periodic_len=None):
    """Parameters for samples at lengths s along a curve, from a smooth monotone map t -> s through
    the nodes (t_j, s_j) (periodic with period 1 in t and periodic_len in s when given): no jumps in
    speed at the nodes for a spline fit to follow."""
    tn, sn = np.asarray(nodes_t, dtype=float), np.asarray(nodes_s, dtype=float)
    if periodic_len is not None:
        tn = np.concatenate([tn - 1, tn, tn + 1, [tn[0] + 2]])
        sn = np.concatenate([sn - periodic_len, sn, sn + periodic_len, [sn[0] + 2 * periodic_len]])
    grid = np.linspace(tn[0] if periodic_len is None else 0.0, tn[-1] if periodic_len is None else 1.0, 20001)
    sg = _pchip(tn, sn, grid)
    if np.any(np.diff(sg) <= 0):
        return None
    if periodic_len is not None:
        s_samples = np.mod(s_samples - sg[0], periodic_len) + sg[0]
    return np.interp(s_samples, sg, grid)


def _closed_network(rings, profiles):
    """A closed surface through closed curves (rings) and open curves running across them (profiles,
    each from the first ring to the last, crossing every ring once): a Gordon surface, the sum of a
    skin through the rings and a skin round through the profiles less the surface through their
    crossings. The rings and profiles are fitted (to well within the kernel's tolerance) so that
    every ring meets the profiles at the same parameters and every profile the rings."""
    m, n = len(rings), len(profiles)
    if m < 2 or n < 2:
        raise CadError("network: two or more rings and two or more curves across them are needed")
    size = max(max(float(w.bbox().diagonal) for w in rings + profiles), 1e-12)
    tol = size * 1e-6
    R = [_polyline(w) for w in rings]
    Pr = [_polyline(w) for w in profiles]
    X = np.zeros((m, n, 3))
    sr = np.zeros((m, n))
    sp = np.zeros((m, n))
    for i in range(m):
        for j in range(n):
            p, a, b, gap = _meet(rings[i], *R[i], profiles[j], *Pr[j], True)
            if gap > size * 1e-4:
                raise CadError(f"network: ring {i + 1} and curve {j + 1} do not meet (they pass {gap:.3g} apart)")
            X[i, j], sr[i, j], sp[i, j] = p, a, b
    # the rings in the order the profiles cross them (all the same way round), the profiles in the
    # order the rings cross them (all the same way along)
    order_p = np.argsort(sp[:, 0])                       # rings along profile 0
    for j in range(n):
        if list(np.argsort(sp[:, j])) not in (list(order_p), list(order_p[::-1])):
            raise CadError("network: the curves across the rings must cross them in the same order")
    rings = [rings[i] for i in order_p]
    R = [R[i] for i in order_p]
    X, sr, sp = X[order_p], sr[order_p], sp[order_p]
    flip_p = [sp[0, j] > sp[-1, j] for j in range(n)]
    L0 = R[0][1][-1] + float(np.linalg.norm(R[0][0][-1] - R[0][0][0]))
    turn = np.argsort((sr[0] - sr[0, 0]) % L0)            # profiles round ring 0
    profiles = [profiles[j] for j in turn]
    Pr = [Pr[j] for j in turn]
    X, sr, sp = X[:, turn], sr[:, turn], sp[:, turn]
    flip_p = [flip_p[j] for j in turn]
    # ---- rings, each fitted periodic with profile j at u = j / n
    def winding(P):
        c0 = P.mean(axis=0)
        return np.cross(P - c0, np.roll(P, -1, axis=0) - c0).sum(axis=0)

    w0 = winding(R[0][0])
    data_u = []
    for i in range(m):
        P, s = R[i]
        L = s[-1] + float(np.linalg.norm(P[-1] - P[0]))
        sgn = 1.0 if float(np.dot(winding(P), w0)) >= 0 else -1.0     # every ring the same way round
        rel = (sgn * (sr[i] - sr[i, 0])) % L
        if np.any(np.diff(rel) <= 0):
            raise CadError("network: the curves across the rings must cross every ring in the same order")
        pos = (sgn * (s - sr[i, 0])) % L
        u = _smooth_params(np.arange(n) / n, rel, pos, periodic_len=L)
        if u is None:
            knots = np.concatenate([rel, [L]])
            seg = np.clip(np.searchsorted(knots, pos, side="right") - 1, 0, n - 1)
            u = (seg + (pos - knots[seg]) / (knots[seg + 1] - knots[seg])) / n
        data_u.append((u % 1.0, P))
    # ---- profiles, each fitted with ring i at the same v for all
    vfrac = np.zeros((m, n))
    data_v = []
    for j in range(n):
        P, s = Pr[j]
        a_, b_ = (sp[0, j], sp[-1, j]) if not flip_p[j] else (sp[-1, j], sp[0, j])
        lo_, hi_ = min(a_, b_), max(a_, b_)
        keep = (s >= lo_ - 1e-12) & (s <= hi_ + 1e-12)
        pos = (s[keep] - sp[0, j]) * (-1.0 if flip_p[j] else 1.0)
        vfrac[:, j] = (sp[:, j] - sp[0, j]) * (-1.0 if flip_p[j] else 1.0) / max(abs(sp[-1, j] - sp[0, j]), 1e-300)
        data_v.append((pos / max(abs(sp[-1, j] - sp[0, j]), 1e-300), P[keep]))
    vn = vfrac.mean(axis=1)
    vn[0], vn[-1] = 0.0, 1.0
    if np.any(np.diff(vn) <= 0):
        raise CadError("network: the rings must follow one another along the curves across them")
    for j in range(n):           # ring i at vn[i]
        w_, P = data_v[j]
        f = vfrac[:, j]
        v = _smooth_params(vn, f, w_) if m > 2 else w_
        if v is None:
            seg = np.clip(np.searchsorted(f, w_, side="right") - 1, 0, m - 2)
            v = vn[seg] + (w_ - f[seg]) / (f[seg + 1] - f[seg]) * (vn[seg + 1] - vn[seg])
        data_v[j] = (np.clip(v, 0.0, 1.0), P)
    u_nodes = np.arange(n) / n
    # fitted rings: periodic cubic, more spans until they fit
    ring_cv, Ku = None, None
    for spans in (4, 8, 16, 32, 64):
        Ku = n * spans
        if Ku > 1024:
            break
        cvs, worst = [], 0.0
        for i in range(m):
            u, P = data_u[i]
            B = _periodic_rows(Ku, 3, u)
            C = _fit(B, P, _periodic_rows(Ku, 3, u_nodes), X[i], periodic=True)
            cvs.append(C)
            worst = max(worst, float(np.linalg.norm(B @ C - P, axis=1).max()))
        ring_cv = cvs
        if worst <= tol:
            break
    # fitted profiles: clamped cubic
    prof_cv, kv_p = None, None
    for spans in (4, 8, 16, 32, 64, 128):
        kv_p = [0.0] * 4 + [k / spans for k in range(1, spans)] + [1.0] * 4
        nb = spans + 3
        cvs, worst = [], 0.0
        for j in range(n):
            v, P = data_v[j]
            B = _basis_rows(kv_p, 3, nb, v)
            C = _fit(B, P, _basis_rows(kv_p, 3, nb, vn), X[:, j])
            cvs.append(C)
            worst = max(worst, float(np.linalg.norm(B @ C - P, axis=1).max()))
        prof_cv = cvs
        if worst <= tol:
            break
    nbp = len(kv_p) - 4
    # blending across: through the rings (degree up to 3 along v), round through the profiles
    q = min(3, m - 1)
    kv_r = [0.0] * (q + 1) + [float(np.mean(vn[j:j + q])) for j in range(1, m - q)] + [1.0] * (q + 1)
    phi_inv = np.linalg.inv(_basis_rows(kv_r, q, m, vn))          # phi_i(v) = N(v) @ phi_inv[:, i]
    dn = 3                                           # (a periodic cubic: smooth round even through two or three)
    psi_inv = np.linalg.inv(_periodic_rows(n, dn, u_nodes))

    def skin(us, vs):
        """Through the rings: (a, b, 3)."""
        Nu = _periodic_rows(Ku, 3, us)
        phi = _basis_rows(kv_r, q, m, np.clip(vs, 0.0, 1.0)) @ phi_inv
        A = np.stack([Nu @ C for C in ring_cv], axis=1)        # (a, m, 3)
        return np.einsum("aik,bi->abk", A, phi)

    def frames(us, vs):
        """Unit frames of the ring skin (along u, across, normal): (a, b, 3, 3), columns."""
        h = 1e-5
        du = skin(np.asarray(us) + h, vs) - skin(np.asarray(us) - h, vs)
        vs = np.asarray(vs, dtype=float)
        v0, v1 = np.clip(vs - h, 0.0, 1.0), np.clip(vs + h, 0.0, 1.0)
        dv = skin(us, v1) - skin(us, v0)
        tu = du / np.maximum(np.linalg.norm(du, axis=2, keepdims=True), 1e-300)
        nn = np.cross(du, dv)
        nn = nn / np.maximum(np.linalg.norm(nn, axis=2, keepdims=True), 1e-300)
        tv = np.cross(nn, tu)
        return np.stack([tu, tv, nn], axis=3)

    def surface(us, vs):
        """The ring skin plus the profiles' departures from it, carried round in the skin's own
        frame (so a profile bulging out bulges the body out all round, between the profiles too):
        through every ring (the departures are nil there) and every profile."""
        us, vs = np.asarray(us, dtype=float), np.asarray(vs, dtype=float)
        Nv = _basis_rows(kv_p, 3, nbp, vs)
        Bp = np.stack([Nv @ C for C in prof_cv], axis=1)              # (b, n, 3)
        D = Bp - np.transpose(skin(u_nodes, vs), (1, 0, 2))           # (b, n, 3)
        Fn = np.transpose(frames(u_nodes, vs), (1, 0, 2, 3))          # (b, n, 3, 3)
        c = np.einsum("bjkl,bjk->bjl", Fn, D)                          # in each profile's frame
        psi = _periodic_rows(n, dn, us) @ psi_inv                      # (a, n)
        cc = np.einsum("aj,bjl->abl", psi, c)
        return skin(us, vs) + np.einsum("abkl,abl->abk", frames(us, vs), cc)

    # the surface's own CVs: clamped cubic both ways, on knots fine enough to hold it (refined
    # until the profiles and rings are matched to well within the kernel's tolerance)
    def knots_with(extra_u, extra_v):
        inner_u = [(k / (Ku * extra_u), 1) for k in range(1, Ku * extra_u)]
        ku_ = _knot_vector(0.0, 1.0, 3, inner_u)
        inner = {x: mm for x, mm in _inner_knots(kv_p, 3, nbp)}
        for x, mm in _inner_knots(kv_r, q, m):
            key = next((y for y in inner if abs(y - x) < 1e-10), x)
            inner[key] = max(inner.get(key, 0), min(mm + 3 - q, 3))
        vals = [0.0] + sorted(inner) + [1.0]
        for a_, b_ in zip(vals[:-1], vals[1:]):
            for k in range(1, extra_v):
                inner[a_ + (b_ - a_) * k / extra_v] = 1
        return ku_, _knot_vector(0.0, 1.0, 3, sorted(inner.items()))

    best = None
    for extra in (1, 2, 4):
        ku, kvv = knots_with(extra, extra)
        nu, nv = len(ku) - 4, len(kvv) - 4
        gu, gv = _greville(ku, 3, nu), _greville(kvv, 3, nv)
        S = surface(gu, gv)
        Bu, Bv = _basis_rows(ku, 3, nu, gu), _basis_rows(kvv, 3, nv, gv)
        C = np.empty((nu, nv, 3))
        for k in range(3):
            C[..., k] = np.linalg.solve(Bu, np.linalg.solve(Bv, S[..., k].T).T)
        C[-1] = C[0]                                     # the seam: closed exactly
        # how far the CV surface is from the curves: on every profile and every ring
        tu, tv = np.linspace(0.0, 1.0, 4 * nu + 1), np.linspace(0.0, 1.0, 4 * nv + 1)
        Su = _basis_rows(ku, 3, nu, u_nodes)
        Sv = _basis_rows(kvv, 3, nv, tv)
        on_p = np.einsum("ai,ijk,bj->abk", Su, C, Sv)                   # (n, b, 3)
        want_p = np.stack([_basis_rows(kv_p, 3, nbp, tv) @ Cp for Cp in prof_cv])
        Ru = _basis_rows(ku, 3, nu, tu)
        on_r = np.einsum("ai,ijk,bj->abk", Ru, C, _basis_rows(kvv, 3, nv, vn))  # (a, m, 3)
        want_r = np.stack([_periodic_rows(Ku, 3, tu) @ Cr for Cr in ring_cv], axis=1)
        err = max(float(np.linalg.norm(on_p - want_p, axis=2).max()), float(np.linalg.norm(on_r - want_r, axis=2).max()))
        best = (ku, kvv, C)
        if err <= tol * 10:
            break
    ku, kvv, C = best
    # (closed the second way round, across the rows, as the kernel's own lofts of rings are: its
    # checker reads the seam of such a surface reliably)
    rows = [[tuple(map(float, x)) for x in C[:, j]] for j in range(C.shape[1])]
    return _call("network", _s.Shell.from_nurbs, ((3, 3), (list(kvv), list(ku)), rows, None))


def surface_fillet(face_a, face_b, radius: float, side_a: int = 1, side_b: int = 1, trim: bool = False,
                   chamfer: bool = False):
    return _call("surface fillet", _s.surface_fillet, face_a, face_b, radius, sides=(side_a, side_b), trim=trim,
                 shape="chamfer" if chamfer else "round")


def match_surface(sheet, edge_id: int, target_edge, target_face=None, continuity: str = "G1",
                  extent: float = 0.35, extra: int = 4):
    """A surface whose border edge is moved onto a target curve, G0 / G1 / G2 to the surface the target
    is an edge of (target_face). The face's CV rows along that border are set: row 0 onto the
    target, row 1 (G1) along the target surface's direction across its edge, row 2 (G2) on the same
    line (exact for target surfaces straight across their edge); deeper rows follow smoothly over
    `extent` of the face. The face must be untrimmed with the edge as one whole side."""
    from importlib import import_module
    edges = list(sheet.edges())
    e = edges[edge_id]
    if len(e.faces()) != 1:
        raise CadError("match: pick an open edge of the surface (a whole side of its face)")
    face = e.faces()[0]
    faces = list(sheet.faces())
    fid = next(i for i, x in enumerate(faces) if float(np.linalg.norm(_vec(x.center()) - _vec(face.center()))) < 1e-12)
    try:
        surfedit = import_module(__package__.rsplit(".", 1)[0] + ".surfedit") if __package__ else None
    except Exception:
        surfedit = None
    if surfedit is None:
        raise CadError("match: not available here")
    net0, info = surfedit.face_net(sheet, fid)
    if info["trimmed"]:
        # fall back to the kernel's own match (positions only)
        return _call("match", sheet.match_edge, e, target_edge, extent=min(max(extent, 0.05), 0.95))
    net = net0.refined(extra, extra, 3)
    P = net.P.copy()
    nu, nv = net.shape
    u0, u1 = net.ku[net.pu], net.ku[nu]
    v0, v1 = net.kv[net.pv], net.kv[nv]
    m = _vec(e.point_at(0.5))
    cands = {"u0": (u0, None), "u1": (u1, None), "v0": (None, v0), "v1": (None, v1)}
    best = None
    for key, (uu, vv) in cands.items():
        pts = net.evaluate([uu] if uu is not None else np.linspace(u0, u1, 9),
                           [vv] if vv is not None else np.linspace(v0, v1, 9)).reshape(-1, 3)
        d = min(float(np.linalg.norm(q - m)) for q in pts)
        if best is None or d < best[0]:
            best = (d, key)
    key = best[1]
    # view the CV grid with the matched border as row 0
    if key == "u0":
        G = P
    elif key == "u1":
        G = P[::-1]
    elif key == "v0":
        G = P.transpose(1, 0, 2)
    else:
        G = P.transpose(1, 0, 2)[::-1]
    G = G.copy()
    rows, cols = G.shape[0], G.shape[1]
    knots_along = net.kv if key[0] == "u" else net.ku
    deg_along = net.pv if key[0] == "u" else net.pu
    # where the border's CVs go: the target at the Greville points, matched by length fraction
    g = surfedit.greville(knots_along, deg_along, cols)
    lo, hi = knots_along[deg_along], knots_along[cols]
    T = _Polyline(target_edge if type(target_edge).__name__ == "Wire" else wire([target_edge]))
    border_start = G[0, 0]
    if float(np.linalg.norm(T.at(0.0) - border_start)) > float(np.linalg.norm(T.at(1.0) - border_start)):
        T = _Polyline(target_edge if type(target_edge).__name__ == "Wire" else wire([target_edge]), reverse=True)
    fr = (g - lo) / max(hi - lo, 1e-300)
    targets = np.array([T.at(f) for f in fr])
    B = surfedit.basis_matrix(knots_along, deg_along, cols, g)
    new0 = np.linalg.solve(B, targets)
    old = G.copy()
    G[0] = new0
    d0 = new0 - old[0]
    level = {"G0": 0, "G1": 1, "G2": 2}.get(continuity, 0)
    if level >= 1 and target_face is not None:
        tedges = list(target_edge.edges()) if type(target_edge).__name__ == "Wire" else [target_edge]
        for j in range(cols):
            q = new0[j]
            te = min(tedges, key=lambda x: float(np.linalg.norm(_closest(x, q) - q)))
            try:   # our face continues the target surface: away from it, across its edge
                dirn = _unit(_surface_out(target_face, te, _closest(te, q)))
            except Exception:
                continue
            L1 = float(np.linalg.norm(old[1, j] - old[0, j]))
            G[1, j] = new0[j] + dirn * L1
            if level >= 2 and rows > 3:
                G[2, j] = new0[j] + dirn * 2 * L1
    # deeper rows follow the moved ones smoothly (falloff over `extent` of the rows)
    fixed = 1 + (level if target_face is not None else 0)
    last_delta = G[fixed - 1] - old[fixed - 1]
    reach = max(int(round(extent * rows)), fixed + 1)
    for i in range(fixed, min(reach, rows - 1)):
        t = (i - fixed + 1) / (reach - fixed + 1)
        G[i] = old[i] + last_delta * (1 - t) ** 2
    # back to the grid
    if key == "u0":
        P2 = G
    elif key == "u1":
        P2 = G[::-1]
    elif key == "v0":
        P2 = G.transpose(1, 0, 2)
    else:
        P2 = G[::-1].transpose(1, 0, 2)
    info = dict(info)
    return surfedit.rebuild(sheet, fid, net, P2, info, "FREE")


# ----------------------------------------------------------------------------- group 1: curves

def intersection_edges(a, b):
    out = list(_call("intersect", a.intersection_curves, b))
    if not out:
        raise CadError("the two bodies do not cross")
    return out


def project_edges(target, curves, direction, nearest: bool = False):
    out = []
    for c in curves:
        try:
            out += list(_call("project", target.project, c, tuple(direction), nearest=nearest))
        except CadError:
            continue
    if not out:
        raise CadError("the curves do not land on the body along that direction")
    return out


def iso_edges(face, direction: str, positions):
    out = []
    for t in positions:
        kw = {"u": float(t)} if direction == "U" else {"v": float(t)}
        out += list(_call("iso curve", face.iso, **kw))
    if not out:
        raise CadError("no iso curve there (outside the face?)")
    return out


def silhouette_edges(shape, direction):
    out = list(_call("silhouette", shape.silhouette, tuple(direction)))
    if not out:
        raise CadError("no silhouette seen from that direction")
    return out


def helix_edge(pitch, height, radius, end_radius=None, left=False):
    return _call("helix", _s.Helix, pitch, height, radius, end_radius=end_radius, left_handed=left)


def spiral_edge(r0, r1, turns, clockwise=False):
    return _call("spiral", _s.Spiral, r0, r1, turns, clockwise=clockwise)


# ----------------------------------------------------------------------------- group 1: solids

def draft_faces(part, face_ids, angle: float, pull, neutral_point):
    if not isinstance(part, _s.Part):
        raise CadError("draft: works on solids")
    pl = _s.Plane(tuple(neutral_point), z_dir=tuple(pull))
    return _call("draft", part.draft, _faces(part, face_ids), angle, pl)


def hole_tool(kind: str, radius: float, depth: float, cb_radius: float = 0.0, cb_depth: float = 0.0,
              cs_radius: float = 0.0, cs_angle: float = 82.0):
    if kind == "COUNTERBORE":
        return _call("hole", _s.CounterBoreHole, radius, cb_radius, cb_depth, depth)
    if kind == "COUNTERSINK":
        return _call("hole", _s.CounterSinkHole, radius, cs_radius, depth, angle=cs_angle)
    return _call("hole", _s.Hole, radius, depth)


def drill(part, face_id: int, point, tool_args: dict):
    """A hole drilled into a planar face at a point (projected onto the face), along -normal."""
    f = part.faces()[face_id]
    if not bool(f.is_planar):
        raise CadError("hole: pick a flat face")
    p0, n = face_frame(part, face_id)
    n = _unit(n)
    q = _vec(point)
    q = q - n * float(np.dot(q - _vec(p0), n))
    size = max(float(part.bbox().diagonal), 1e-9)
    a = dict(tool_args)
    if a.get("depth", 0) <= 0:
        a["depth"] = size * 2   # through
    eps = size * 1e-4
    a["depth"] += eps
    if a.get("cb_depth"):
        a["cb_depth"] += eps
    tool = hole_tool(**a)
    z = n
    x = _unit(np.cross([0.0, 0.0, 1.0], z)) if abs(z[2]) < 0.9 else _unit(np.cross([1.0, 0.0, 0.0], z))
    y = np.cross(z, x)
    top = q + n * eps
    M = [[x[0], y[0], z[0], top[0]], [x[1], y[1], z[1], top[1]], [x[2], y[2], z[2], top[2]], [0, 0, 0, 1]]
    return boolean(part, moved(tool, M), "DIFFERENCE")


def pattern(shape, matrices, merge: bool = True):
    """Copies of a body by rigid matrices; merged into one body (solids fused, surfaces sewn) or as
    separate bodies."""
    copies = [moved(shape, m) for m in matrices]
    if not merge:
        return copies
    return combine([shape] + copies)


def _solid_or_none(x, ref_volume: float):
    import warnings
    try:
        if x is None or not x.faces():
            return None
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")    # (a piece in the making may have tiny gaps)
            v = abs(float(x.volume))
        return x if v > ref_volume * 1e-9 else None
    except Exception:
        return None


def _feature_probes(shape, face_ids):
    faces = list(shape.faces())
    out = []
    for i in face_ids:
        f = faces[i]
        try:
            out.append(_vec(f.interior_point()))
        except Exception:
            out.append(_vec(f.center()))
    return out


def _touching(x, probes, tol, ref):
    """The pieces of x that touch the picked faces (other voids / slivers are not the feature)."""
    if x is None:
        return None
    try:
        lumps = list(x.solids()) if hasattr(x, "solids") else [x]
    except Exception:
        lumps = [x]
    keep = [lump for lump in lumps if any(float(lump.distance_to(tuple(q))) < tol for q in probes)]
    return _solid_or_none(combine(keep), ref) if keep else None


def _no_slivers(removed, added):
    """A feature is a cut or a boss: a by-product thousands of times smaller than the other is noise."""
    if removed is not None and added is not None:
        vr, va = abs(float(removed.volume)), abs(float(added.volume))
        if va < vr * 1e-3:
            added = None
        elif vr < va * 1e-3:
            removed = None
    return removed, added


def feature_volumes(shape, face_ids):
    """The material a feature (the picked faces: a pocket's walls and floor, a hole, a boss) took
    away and added: the part is healed without those faces (Delete + Heal) and compared with
    itself. Returns (removed, added); either may be None."""
    if not isinstance(shape, _s.Part):
        raise CadError("pattern: feature patterns work on solids")
    if not face_ids:
        raise CadError("pattern: pick the faces of the feature to repeat (its walls and floor)")
    try:
        healed = remove_faces(shape, face_ids)
    except CadError as ex:
        try:   # the kernel cannot heal it: extend the faces around the feature instead
            return _envelope_volumes(shape, face_ids)
        except CadError as ex2:
            raise CadError("pattern: the feature could not be found from the picked faces (pick all of its "
                           f"faces: walls, floor, rounds) ({str(ex2).split(': ', 1)[-1]}; healing: "
                           f"{str(ex).split(': ', 1)[-1][:80]})")
    ref = abs(float(shape.volume)) + abs(float(healed.volume))
    probes = _feature_probes(shape, face_ids)
    tol = max(body_size(shape), 1e-9) * 1e-6
    removed = added = None
    try:
        removed = _touching(_call("pattern", healed.cut, shape), probes, tol, ref)
    except CadError:
        pass
    try:
        added = _touching(_call("pattern", shape.cut, healed), probes, tol, ref)
    except CadError:
        pass
    removed, added = _no_slivers(removed, added)
    if removed is None and added is None:
        raise CadError("pattern: the picked faces do not make a feature (taking them out changed nothing)")
    return removed, added


def _face_ids_of(shape, faces):
    allf = list(shape.faces())
    out = []
    for f in faces:
        i = next((k for k, g in enumerate(allf) if g == f), None)
        if i is not None:
            out.append(i)
    return out


def _orient_z(direction, origin):
    """A matrix (list of rows) taking +Z to `direction` at `origin`."""
    from mathutils import Matrix, Vector
    R = Vector((0.0, 0.0, 1.0)).rotation_difference(Vector(tuple(direction))).to_matrix().to_4x4()
    M = Matrix.Translation(Vector(tuple(origin))) @ R
    return [list(map(float, r)) for r in M]


def _material_side(face, big: float, grow: float = 0.0):
    """The solid on the material side of a face's whole surface, within a big region: a half-space
    for a plane, a full cylinder / ball for a convex one, the space around it for a hole's wall.
    `grow` moves its boundary outwards (into the air; negative: into the material). None for
    surfaces it cannot extend."""
    kind = str(face.geom_type).lower()
    c = _vec(face.center())
    n = _unit(face.normal_at(tuple(c)))
    if kind == "plane":
        c = c + grow * n
        a = np.array([1.0, 0.0, 0.0]) if abs(n[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
        u = _unit(np.cross(n, a))
        v = np.cross(n, u)
        P = [c + big * (su * u + sv * v) for su, sv in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
        w = _s.Wire([_s.Line(tuple(P[k]), tuple(P[(k + 1) % 4])) for k in range(4)])
        return _s.extrude(w, float(big), direction=tuple(-n))
    if kind in ("cylinder", "sphere"):
        if kind == "cylinder":
            ax = face.axis
            o, d = _vec(ax.origin), _unit(_vec(ax.direction))
            foot = o + float(np.dot(c - o, d)) * d
            r = float(face.radius)
            radial = c - foot
            convex = float(np.dot(n, radial)) > 0
            r = max(r + (grow if convex else -grow), r * 1e-3)
            solid = moved(_s.Cylinder(r, 4.0 * big), _orient_z(d, foot))
        else:
            info = face._surface_info()
            ctr = np.asarray(info["placement"]["origin"], dtype=float)
            r = float(info["radius"])
            radial = c - ctr
            convex = float(np.dot(n, radial)) > 0
            r = max(r + (grow if convex else -grow), r * 1e-3)
            solid = _s.Sphere(r).translate(tuple(ctr))
        if convex:
            return solid                                   # convex: the material is inside
        box = _s.Box(4.0 * big, 4.0 * big, 4.0 * big).translate(tuple(c))
        return _call("pattern", box.cut, solid)            # a hole's wall: the material is around it
    return None


def _envelope_volumes(shape, face_ids):
    """The feature's volumes without healing: the faces around the feature are extended (their whole
    plane / cylinder / sphere) and cut against the part near the feature; the pieces that touch the
    picked faces are the feature."""
    faces = list(shape.faces())
    picked = [faces[i] for i in face_ids]
    pset = set(face_ids)
    near = set()
    for f in picked:
        for e in f.edges():
            for g in e.faces():
                for i in _face_ids_of(shape, [g]):
                    if i not in pset:
                        near.add(i)
    if not near:
        raise CadError("pattern: the picked faces have no faces around them")
    size = max(body_size(shape), 1e-9)
    big = size * 2.0
    eps = size * 1e-5   # the volumes reach a hair past the faces around them (no faces in common)

    def sides_grown(grow):
        out = []
        for i in sorted(near):
            h = _material_side(faces[i], big, grow)
            if h is None:
                raise CadError(f"pattern: a face around the feature is {faces[i].geom_type}; only planes, "
                               "cylinders and spheres can be extended to find the feature")
            out.append(h)
        return out
    lo = np.min([np.asarray(tuple(f.bbox().min)) for f in picked], axis=0)
    hi = np.max([np.asarray(tuple(f.bbox().max)) for f in picked], axis=0)
    pad = 0.5 * float(np.linalg.norm(hi - lo)) + size * 1e-3
    lo, hi = lo - pad, hi + pad
    region = _s.Box(*(hi - lo)).translate(tuple((lo + hi) / 2.0))

    def envelope(grow):
        env = region
        for h in sides_grown(grow):
            env = _call("pattern", env.intersect, h)
        return env
    ref = abs(float(shape.volume))
    probes = []
    for f in picked:
        try:
            probes.append(_vec(f.interior_point()))
        except Exception:
            probes.append(_vec(f.center()))

    def touching(x):
        if x is None:
            return None
        keep = []
        try:
            lumps = list(x.solids()) if hasattr(x, "solids") else [x]
        except Exception:
            lumps = [x]
        tol = size * 1e-6
        for lump in lumps:
            if any(float(lump.distance_to(tuple(q))) < tol for q in probes):
                keep.append(lump)
        return _solid_or_none(combine(keep), ref) if keep else None

    def box_round(x, grow):
        b = x.bbox()
        lo_, hi_ = np.asarray(tuple(b.min)) - grow, np.asarray(tuple(b.max)) + grow
        return _s.Box(*(hi_ - lo_)).translate(tuple((lo_ + hi_) / 2.0))

    def vol(x):
        return abs(float(x.volume))

    removed = added = None
    env0 = None
    try:   # a cut: the space the part's surfaces would enclose, less the part
        env0 = envelope(0.0)
        exact = touching(_call("pattern", env0.cut, shape))
        removed = exact
        if exact is not None:
            # the same, a hair beyond the surfaces (no faces in common with the part when repeated);
            # only around the feature itself: a hair beyond the whole part would join the feature
            # to all the space around it
            try:
                near = _call("pattern", envelope(eps).intersect, box_round(exact, 4 * eps))
                grown = touching(_call("pattern", near.cut, shape))
                if grown is not None and abs(vol(grown) - vol(exact)) < 1e-2 * vol(exact):
                    removed = grown
            except CadError:
                pass
    except CadError:
        pass
    try:   # a boss: the part outside its surfaces
        if env0 is None:
            env0 = envelope(0.0)
        exact = touching(_call("pattern", shape.intersect, _call("pattern", region.cut, env0)))
        added = exact
        if exact is not None:
            try:
                box = box_round(exact, 4 * eps)
                grown = touching(_call("pattern", shape.intersect, _call("pattern", box.cut, envelope(-eps))))
                if grown is not None and abs(vol(grown) - vol(exact)) < 1e-2 * vol(exact):
                    added = grown
            except CadError:
                pass
    except CadError:
        pass
    removed, added = _no_slivers(removed, added)
    if removed is None and added is None:
        raise CadError("pattern: no feature found at the picked faces")
    return removed, added


def pattern_volumes(shape, removed, added, matrices):
    """The part with the feature's volumes repeated at every matrix: removed ones cut, added ones
    joined."""
    def apply(out, vol, how):
        tools = [moved(vol, m) for m in matrices]
        try:   # all copies at once
            return _call("pattern", getattr(out, how), combine(tools) if len(tools) > 1 else tools[0])
        except CadError:
            for tool in tools:   # copies that touch each other: one at a time
                out = _call("pattern", getattr(out, how), tool)
            return out

    out = shape
    if removed is not None:
        out = apply(out, removed, "cut")
    if added is not None:
        out = apply(out, added, "fuse")
    return out


def pattern_feature(shape, face_ids, matrices):
    """Repeat a feature of a solid (the picked faces) at every matrix (the original stays)."""
    removed, added = feature_volumes(shape, face_ids)
    return pattern_volumes(shape, removed, added, matrices)


def pipe(path, outer_diameter: float, inner_diameter: float = 0.0, caps: str = "FLAT", solid: bool = True):
    """A pipe along a path (a wire): a round bar (inner 0), a hollow tube (inner > 0) or, with
    solid=False, the outer tube surface alone (no caps, no inside). Caps: FLAT ends, or ROUND ones:
    half balls on a bar, rounded lips on a hollow tube. A closed path gives a ring (no caps)."""
    ro, ri = outer_diameter / 2.0, inner_diameter / 2.0
    if ro <= 0:
        raise CadError("pipe: the outside diameter must be above 0")
    if solid and ri >= ro:
        raise CadError("pipe: the inside diameter must be smaller than the outside one")
    closed = wire_is_closed(path)

    def bar(r):
        disk = face_from_wires(wire([_call("pipe", _s.CenterArc, (0, 0, 0), r, 0, 360)]))
        return _call("pipe", _s.sweep, disk, path)

    body = bar(ro)
    if not solid:
        if closed:
            return _call("pipe", _s.stitch, list(body.faces()))
        return as_sheet(open_caps(body, [tuple(path.start), tuple(path.end)]))
    ends = [] if closed else [_vec(wire_ends(path)[0]), _vec(wire_ends(path)[1])]
    if ri > 0:
        body = _call("pipe", body.cut, bar(ri))
        if caps == "ROUND" and ends:
            size = max(float(body.bbox().diagonal), 1e-9)
            rim = [i for i, e in enumerate(body.edges())
                   if any(float(np.linalg.norm(_closest(e, q) - q)) < (ro + size * 1e-6)
                          and abs(float(np.linalg.norm(_vec(e.point_at(0.5)) - q)) - r) < size * 1e-5
                          for q in ends for r in (ro, ri))]
            if rim:
                body = fillet(body, rim, (ro - ri) / 2.0 * 0.98, explain=False)
    elif caps == "ROUND" and ends:
        for q in ends:
            ball = moved(_call("pipe", _s.Sphere, ro), [[1, 0, 0, q[0]], [0, 1, 0, q[1]], [0, 0, 1, q[2]], [0, 0, 0, 1]])
            body = _call("pipe", body.fuse, ball)
    return body


# ----------------------------------------------------------------------------- rebuild

def _bspline_basis(knots, p, n, ts):
    """(len(ts), n) B-spline basis matrix (clamped knots; the right end included)."""
    k = np.asarray(knots, dtype=float)
    ts = np.clip(np.asarray(ts, dtype=float), k[p], k[n])
    out = np.zeros((len(ts), n))
    for r, t in enumerate(ts):
        if t >= k[n]:
            out[r, n - 1] = 1.0
            continue
        # de Boor's triangle for the non-zero functions
        span = int(np.searchsorted(k, t, side="right") - 1)
        span = min(max(span, p), n - 1)
        N = np.zeros(p + 1)
        N[0] = 1.0
        left, right = np.zeros(p + 1), np.zeros(p + 1)
        for j in range(1, p + 1):
            left[j] = t - k[span + 1 - j]
            right[j] = k[span + j] - t
            saved = 0.0
            for r_ in range(j):
                den = right[r_ + 1] + left[j - r_]
                tmp = N[r_] / den if den != 0 else 0.0
                N[r_] = saved + right[r_ + 1] * tmp
                saved = left[j - r_] * tmp
            N[j] = saved
        out[r, span - p:span + 1] = N
    return out


def _uniform_knots(n, p):
    inner = n - p - 1
    return [0.0] * (p + 1) + [float(i) / (inner + 1) for i in range(1, inner + 1)] + [1.0] * (p + 1)


def _fit_curve_points(P, ts, degree, ncv):
    """Least-squares B-spline (clamped, uniform knots) through ordered points, ends exact."""
    p = int(degree)
    n = max(int(ncv), p + 1)
    knots = _uniform_knots(n, p)
    B = _bspline_basis(knots, p, n, ts)
    C = np.zeros((n, 3))
    C[0], C[-1] = P[0], P[-1]
    if n > 2:
        rhs = P - np.outer(B[:, 0], C[0]) - np.outer(B[:, -1], C[-1])
        Bi = B[:, 1:-1]
        C[1:-1] = np.linalg.lstsq(Bi, rhs, rcond=None)[0]
    return knots, C


def rebuild_wire(w, degree: int = 3, cv_count: int = 8, samples: int = 400):
    """(new edge, largest deviation): one B-spline of the given degree and number of CVs that runs
    like the wire (its ends exactly on the wire's ends). The deviation is measured from the old
    curve to the new one."""
    if wire_is_closed(w):
        raise CadError("rebuild: closed curves are not rebuilt yet (split it first)")
    PL = _Polyline(w, k=max(64, samples // max(len(list(w.edges())), 1)))
    fr = np.linspace(0.0, 1.0, samples)
    P = np.array([PL.at(f) for f in fr])
    ts = fr.copy()
    best = None
    for _it in range(12):   # fit, then move each point's parameter to where it lies on the fit, again
        knots, C = _fit_curve_points(P, ts, degree, cv_count)
        e = _call("rebuild", _s.Edge.from_nurbs, (int(degree), knots, [tuple(c) for c in C], None))
        dev_it = max(float(np.linalg.norm(_closest(e, q) - q)) for q in P[::max(1, samples // 60)])
        if best is None or dev_it < best[0]:
            best = (dev_it, e)
        # each point's parameter on the fit: nearest of a dense evaluation (the fit's own knot parameter)
        dense = np.linspace(0.0, 1.0, 4000)
        Q = _bspline_basis(knots, int(degree), len(C), dense) @ C
        d2 = (P * P).sum(1)[:, None] - 2.0 * P @ Q.T + (Q * Q).sum(1)[None, :]
        idx = np.argmin(d2, axis=1)
        new_ts = dense[idx]
        new_ts[0], new_ts[-1] = 0.0, 1.0
        if not np.all(np.diff(new_ts) >= -1e-9):
            break
        ts = np.maximum.accumulate(new_ts)
    e = best[1]
    dev = 0.0
    for q in P[::max(1, samples // 120)]:
        dev = max(dev, float(np.linalg.norm(_closest(e, q) - q)))
    return e, dev


def rebuild_face(shape, face_id: int, degree=(3, 3), cv_count=(8, 8), samples=None):
    """(body with the face rebuilt, largest deviation): the face's surface refitted with the given
    degrees and numbers of CVs (least squares; corners and borders follow the old ones closely).
    An untrimmed face is replaced; a trimmed one is cut out of the new surface along its old edges."""
    from importlib import import_module
    surfedit = import_module(__package__.rsplit(".", 1)[0] + ".surfedit")
    net, info = surfedit.face_net(shape, face_id)
    du, dv = int(degree[0]), int(degree[1])
    nu, nv = max(int(cv_count[0]), du + 1), max(int(cv_count[1]), dv + 1)
    mu, mv = (samples or (3 * nu + 10)), (samples or (3 * nv + 10))
    u0, u1 = net.ku[net.pu], net.ku[net.shape[0]]
    v0, v1 = net.kv[net.pv], net.kv[net.shape[1]]
    us, vs = np.linspace(u0, u1, mu), np.linspace(v0, v1, mv)
    S = net.evaluate(us, vs)                       # (mu, mv, 3)
    ku, kv = _uniform_knots(nu, du), _uniform_knots(nv, dv)
    Bu = _bspline_basis(ku, du, nu, (us - u0) / (u1 - u0))
    Bv = _bspline_basis(kv, dv, nv, (vs - v0) / (v1 - v0))
    Pu, Pv = np.linalg.pinv(Bu), np.linalg.pinv(Bv)
    C = np.einsum("ia,abk,jb->ijk", Pu, S, Pv)
    new = surfedit.Net((du, dv), (ku, kv), C, None)
    sheet = _call("rebuild", _s.Shell.from_nurbs, new.data())
    face_new = sheet.faces()[0]
    dev = 0.0
    face_old = list(shape.faces())[face_id]
    pts = S[:: max(1, mu // 12), :: max(1, mv // 12)].reshape(-1, 3)
    for q in pts:
        try:
            if info["trimmed"] and float(face_old.distance_to(tuple(q))) > 1e-9 * max(float(shape.bbox().diagonal), 1):
                continue   # beyond the trimmed face
        except Exception:
            pass
        dev = max(dev, float(face_new.distance_to(tuple(q))))
    # the new surface runs over 0..1: a trimmed face's inside point in those parameters; its edges are
    # carried onto the new surface (rebuild()'s free mode) and it is cut out again there
    info2 = dict(info)
    if info["trimmed"]:
        ui, vi = info["inside"]
        info2["inside"] = ((ui - u0) / (u1 - u0), (vi - v0) / (v1 - v0))
    body = surfedit.rebuild(shape, face_id, new, new.P, info2, "FREE")
    return body, dev


def round_faces(part, max_radius=None):
    """Faces that look like rounds (and their corner pieces): bent tightly against the part's size
    (a radius under a tenth of it) and meeting a neighbour smoothly along an edge."""
    faces = list(part.faces())
    size = max(body_size(part), 1e-12)
    out = []
    for i, f in enumerate(faces):
        ks = []
        pts = _face_samples(f, most=8)
        for p in pts:
            try:
                c = f.curvature_at(tuple(p))
                ks.append(max(abs(float(c.k1)), abs(float(c.k2))))
            except Exception:
                continue                  # (no curvature at a degenerate spot of the surface)
        if ks:
            k = float(np.median(ks))
        else:
            # the kernel gives none (a surface with a degenerate parameterization): how fast the
            # normal turns between points across the face
            k = 0.0
            try:
                N = [_unit(_vec(f.normal_at(tuple(p)))) for p in pts]
            except Exception:
                continue
            for a in range(len(pts)):
                for b in range(a + 1, len(pts)):
                    d = float(np.linalg.norm(pts[a] - pts[b]))
                    if d > size * 1e-6:
                        ang = math.acos(max(-1.0, min(1.0, float(np.dot(N[a], N[b])))))
                        k = max(k, ang / d)
        if k * size < 10.0 or (max_radius and 1.0 / max(k, 1e-300) > max_radius * 1.001):
            continue
        smooth = False
        for e in f.edges():
            others = [g for g in e.faces() if g != f]
            if not others:
                continue
            try:
                m = _fast_points(e, [0.5])[0]
                if float(np.dot(_unit(_vec(f.normal_at(tuple(m)))), _unit(_vec(others[0].normal_at(tuple(m)))))) > 0.999 \
                        and _runs_along_round(f, e, m):
                    smooth = True
                    break
            except Exception:
                continue
        if smooth:
            out.append(i)
    return out


def _runs_along_round(face, edge, m) -> bool:
    """Whether a smooth edge of a tightly bent face runs along it the way a round's side does: across
    the tight bend (a round's sides run along the edge it rounds), not round it (the ring where a
    tube, a handle's cylinder or a lofted body, meets the next face). A face bent the same both ways
    (a ball corner) passes."""
    try:
        c = face.curvature_at(tuple(m))
        k1, k2 = abs(float(c.k1)), abs(float(c.k2))
    except Exception:
        return True
    if max(k1, k2) <= 0 or abs(k1 - k2) < 0.25 * max(k1, k2):
        return True
    tight = _unit(_vec(c.dir1 if k1 > k2 else c.dir2))
    try:
        u = edge.param_at_point(tuple(m)) if hasattr(edge, "param_at_point") else 0.5
        tg = _unit(_vec(edge.tangent_at(float(u))))
    except Exception:
        return True
    return abs(float(np.dot(tg, tight))) < 0.5


def remove_fillet_faces(part, face_ids=None, max_radius=None):
    if not isinstance(part, _s.Part):
        raise CadError("remove fillets: works on solids")
    analytic = ("cylinder", "torus", "sphere", "cone")
    if not face_ids:
        # nothing picked: rounds on free-form faces (the kernel's own search fails slowly on them)
        # are found here and rebuilt around; the kernel's search for the rest
        found = round_faces(part, max_radius)
        if found and any(str(part.faces()[i].geom_type).lower() not in analytic for i in found):
            try:
                return rebuild_without(part, found)
            except CadError:
                pass
    elif any(str(f.geom_type).lower() not in analytic for f in _faces(part, face_ids)):
        try:    # free-form rounds: rebuilding around them is quick and sure; the kernel is neither
            return rebuild_without(part, face_ids)
        except CadError:
            pass
    faces = _faces(part, face_ids) if face_ids else None
    try:
        out = _call("remove fillets", part.remove_fillets, faces, max_radius=max_radius, partial=True)
    except CadError as ex:
        if not face_ids:
            raise
        out, first = None, ex
    if face_ids and (out is None or len(out.faces()) >= len(part.faces())):
        # the kernel took none out (rounds meeting at corners, corner patches it does not count as
        # rounds): extend the faces the rounds blend instead
        for heal in (heal_rounds, rebuild_without):
            try:
                return heal(part, face_ids)
            except CadError:
                continue
        if out is None:
            raise first
    return out


def rebuild_without(shape, face_ids):
    """The solid without some of its faces (rounds, their corner patches, chamfers): the faces
    around them grown past them (untrimmed: their whole surfaces) and the solid they close
    around found again, as Boundary Fill finds it; of its cells, the one the solid itself fills.
    Works for free-form faces, where heal_rounds (planes, cylinders, spheres) does not."""
    if not isinstance(shape, _s.Part):
        raise CadError("delete faces: works on solids")
    faces = list(shape.faces())
    drop = set(int(i) for i in face_ids)
    if not drop or len(drop) >= len(faces):
        raise CadError("delete faces: select some of the solid's faces")
    size = max(body_size(shape), 1e-12)
    # how wide the dropped faces are: the faces next to them grow several times that
    width = 0.0
    for i in drop:
        b = faces[i].bbox()
        ext = np.sort(_vec(b.max) - _vec(b.min))
        width = max(width, float(ext[1]) if ext[0] < size * 1e-9 else float(ext[0]))
    near = set()
    for i in drop:
        for e in faces[i].edges():
            for g in e.faces():
                j = next((k for k, h in enumerate(faces) if h == g), None)
                if j is not None and j not in drop:
                    near.add(j)
    # the faces next to them: their whole surfaces (enough where those reach past the deleted faces
    # already), or grown a little, or more; plain or along their tangents. Each way that closes up
    # gives the solid; the one with the fewest faces is kept (a whole surface can reach right
    # through the part and split faces on its far side), the first with no more faces than are
    # left taken at once.
    want = len(faces) - len(drop)
    best = None
    got = None
    lo_d = np.min([_vec(faces[i].bbox().min) for i in drop], axis=0)
    hi_d = np.max([_vec(faces[i].bbox().max) for i in drop], axis=0)
    keep_pts = []
    for k, f in enumerate(faces):
        # (a face bordered only by deleted faces, a corner piece between rounds, may go with them)
        nbrs = {j for e in f.edges() for g in e.faces() if g != f
                for j in [next((q for q, h in enumerate(faces) if h == g), None)] if j is not None}
        if k not in drop and not (nbrs and nbrs <= drop):
            try:
                ip = f.interior_point()
                keep_pts.append(_vec(getattr(ip, "point", ip)))
            except Exception:
                pass
    for grow, how in (("clip", None), (0.0, None), (width * 1.5, "natural"), (width * 1.5, "G1"),
                      (max(width * 4.0, size * 0.02), "natural"), (max(width * 4.0, size * 0.02), "G1")):
        sheets = []
        try:
            for k, f in enumerate(faces):
                if k in drop:
                    continue
                if k in near:
                    if grow == "clip":
                        sheets.append(_clipped_surface(f, lo_d, hi_d, max(width * 1.5, size * 0.01)))
                    elif grow == 0.0:
                        sheets.append(f.untrimmed())
                    else:
                        sheets.append(f.extend(float(grow), continuity=how))
                else:
                    sheets.append(f.to_shell())
        except Exception:
            continue
        cells = _sheet_cells(sheets, size)
        if not cells or not cells[0]:
            continue
        got = cells
        try:
            solid = _solid_of_cells(shape, cells[0])
        except CadError:
            continue
        # (every face kept must still bound it: a handle left out is not the solid)
        if any(float(solid.distance_to(tuple(q))) > size * 1e-5 for q in keep_pts):
            continue
        n = len(solid.faces())
        if best is None or n < best[0]:
            best = (n, solid)
        if n <= want:
            break
    if best is not None:
        return best[1]
    if best is None:
        # corner patches left out of the selection: faces that meet only deleted faces, smoothly
        more = set()
        for k, f in enumerate(faces):
            if k in drop:
                continue
            ok_ = True
            for e in f.edges():
                others = [g for g in e.faces() if g != f]
                js = [next((q for q, h in enumerate(faces) if h == g), None) for g in others]
                try:
                    m = _fast_points(e, [0.5])[0]
                    tangent = others and float(np.dot(_unit(_vec(f.normal_at(tuple(m)))),
                                                      _unit(_vec(others[0].normal_at(tuple(m)))))) > 0.999
                except Exception:
                    tangent = False
                if not js or any(j not in drop for j in js) or not tangent:
                    ok_ = False
                    break
            if ok_:
                more.add(k)
        if more and len(drop | more) < len(faces):
            return rebuild_without(shape, sorted(drop | more))
        if got and got[0]:
            raise CadError("delete faces: could not tell which closed region is the solid")
        raise CadError("delete faces: the faces around the deleted ones do not close up when grown "
                       "(select every face of the rounds, the corner pieces where they meet too)")


def _clipped_surface(face, lo, hi, margin):
    """A face's whole surface (holes and trims dropped), kept only within a box round the face and
    the faces being deleted, grown by margin: enough to close over them without reaching on through
    the part (a handle's cylinder would otherwise run right through the body and split its far
    side)."""
    un = face.untrimmed()
    b = face.bbox()
    a = np.minimum(_vec(b.min), lo) - margin
    c = np.maximum(_vec(b.max), hi) + margin
    ub = un.bbox()
    if np.all(_vec(ub.min) >= a) and np.all(_vec(ub.max) <= c):
        return un
    box = _s.Box(*[float(x) for x in (c - a)]).translate(tuple(float(x) for x in (a + c) / 2))
    piece = un.intersect(box)
    if not list(piece.faces()):
        return un
    return piece


def _solid_of_cells(shape, cells):
    """Of the closed cells grown faces make, the solid shape filled: one, or several joined."""
    # the cells the solid fills (the faces kept can part it into several: a handle's side grown up
    # into the body it joins splits the body), each told by points inside it: most of them inside
    # the solid. A cell the round alone made (the wedge of a concave round) is mostly outside.
    mine = []
    for c in cells:
        pts = _cell_points(c)
        if not pts:
            continue
        try:
            n = sum(1 for r in shape._classify([tuple(p) for p in pts]) if r[0] == "inside")
        except Exception:
            n = sum(1 for p in pts if shape.contains(tuple(p)))
        if n > len(pts) * 0.5:
            mine.append(c)
    if not mine:
        raise CadError("delete faces: could not tell which closed region is the solid")
    if len(mine) == 1:
        return mine[0]
    joined = _fill_result(mine, "ALL")
    if len(joined) != 1:
        raise CadError("delete faces: the regions of the solid did not join into one")
    return joined[0]


def _cell_points(cell, most: int = 40):
    """Points inside a closed cell: a grid over its box, the ones the cell holds (finer for a thin
    cell)."""
    b = cell.bbox()
    lo, hi = _vec(b.min), _vec(b.max)
    for n in (8, 16, 28):
        g = [np.linspace(lo[k], hi[k], n + 2)[1:-1] for k in range(3)]
        grid = np.stack(np.meshgrid(*g, indexing="ij"), -1).reshape(-1, 3)
        try:
            pts = [p for p, r in zip(grid, cell._classify([tuple(p) for p in grid])) if r[0] == "inside"]
        except Exception:
            pts = [p for p in grid if cell.contains(tuple(p))]
        if len(pts) >= 8:
            step = max(1, len(pts) // most)
            return pts[::step]
    return pts


def split(shape, plane_origin, plane_normal, keep: str = "both"):
    pl = _s.Plane(tuple(plane_origin), z_dir=tuple(plane_normal))
    return _call("split", _s.split, shape, pl, keep=keep.lower())


# ----------------------------------------------------------------------------- curves -> profiles

def bezier_segment(p0, h0, h1, p1):
    return _call("bezier", _s.Bezier, tuple(p0), tuple(h0), tuple(h1), tuple(p1))


def line(p0, p1):
    return _call("line", _s.Line, tuple(p0), tuple(p1))


def polyline(points, closed: bool):
    return _call("polyline", _s.Polyline, *[tuple(p) for p in points], close=closed)


def nurbs_curve(degree: int, knots, points, weights):
    w = None if weights is None or all(abs(x - 1.0) < 1e-12 for x in weights) else list(weights)
    return _call("nurbs", _s.Edge.from_nurbs, (degree, list(knots), [tuple(p) for p in points], w))


def spline_through(points, closed: bool):
    return _call("spline", _s.Spline, *[tuple(p) for p in points], closed=closed)


def wire(edges_or_wires):
    return _call("wire", _s.Wire, list(edges_or_wires))


def wire_is_closed(w) -> bool:
    return bool(w.is_closed)


def face_from_wires(outer, holes=()):
    return _call("region", _s.make_face, outer, *holes)


def three_point_arc(start, through, end):
    return _call("arc", _s.ThreePointArc, tuple(start), tuple(through), tuple(end))


def circle_edge(center, radius: float):
    return _call("circle", _s.CenterArc, tuple(center), float(radius), 0.0, 360.0)


def region_from_loops(polygons_2d, curves_of):
    """A planar region (z = 0) from closed loops, nesting by the even-odd rule: a loop inside a
    loop is a hole, a loop inside a hole an island; crossing loops are resolved by 2D Booleans.

    polygons_2d: one (k, 2) array per loop that follows it closely (no repeated end point).
    curves_of(i): fresh kernel edges (z = 0) of loop i.
    """
    def raw(i):
        return [e._copy_curve() for e in curves_of(i)]

    try:
        from smlibpy import regions as _regions
        plan = _regions.plan([np.asarray(p, dtype=float) for p in polygons_2d], "evenodd")
        return _call("sketch", _regions.build, plan, raw, _s.Plane.XY, "sketch",
                     "the loops must not cross themselves")
    except (ImportError, AttributeError, TypeError):
        # fallback without the private region builder: largest loop outlines, the rest are holes
        order = sorted(range(len(polygons_2d)), key=lambda i: -abs(_signed_area(polygons_2d[i])))
        wires = [wire(curves_of(i)) for i in order]
        return face_from_wires(wires[0], wires[1:])


def _pieces(x, min_area: float) -> list:
    """The faces of a 2D Boolean result, each as its own one-face region."""
    out = []
    try:
        faces = list(x.faces())
    except Exception:
        return out
    for f in faces:
        try:
            if float(f.area) > min_area:
                out.append(f.to_sketch())
        except Exception:
            pass
    return out


def arrangement(loop_wires, cutter_wires=()) -> list:
    """The smallest regions (z = 0) a sketch's curves bound: overlapping loops are cut into all
    their overlaps, and open chains that run across a region split it in two. Chains that end
    inside a region (dangling) don't split it."""
    if not loop_wires:
        return []
    faces = [face_from_wires(w) for w in loop_wires]
    size = max(float(f.bbox().diagonal) for f in faces)
    tiny = (size * 1e-9) ** 2
    regions: list = []
    for F in faces:
        new = []
        for R in regions:
            for op in ("intersect", "cut"):
                try:
                    new += _pieces(getattr(R, op)(F), tiny)
                except Exception:
                    if op == "cut":
                        new.append(R)
        rest = F
        try:
            for R in regions:
                rest = rest.cut(R)
            new += _pieces(rest, tiny)
        except Exception:
            pass
        regions = new
    for w in cutter_wires:
        split_out = []
        for R in regions:
            try:
                pieces = list(R.project(w, (0, 0, -1)))
                if pieces:
                    got = R.trim(pieces, keep="split")
                    parts = _pieces(got, tiny)
                    if len(parts) > 1:
                        split_out += parts
                        continue
            except Exception:
                pass  # the chain does not run across this region
            split_out.append(R)
        regions = split_out
    return regions


def union_regions(regions):
    if not regions:
        raise CadError("no regions picked")
    out = regions[0]
    for r in regions[1:]:
        out = _call("region union", out.fuse, r)
    return out


def region_loops(region, n: int = 64) -> list:
    """Boundary loops of a one-face region as (k, 2) arrays: the outline first, then holes."""
    f = region.faces()[0]
    loops = []
    for w in [f.outer_wire()] + list(f.inner_wires()):
        edges = list(w.edges())
        lengths = np.array([max(float(e.length), 0.0) for e in edges])
        total = float(lengths.sum()) or 1.0
        ts = []
        start = 0.0
        for e, L in zip(edges, lengths):
            k = 1 if str(e.geom_type).lower() == "line" else max(4, int(n * L / total) + 2)
            ts += [(start + L * j / k) / total for j in range(k)]  # includes every corner
            start += L
        pts = np.array([tuple(w.point_at(min(t, 1.0)))[:2] for t in ts], dtype=float)
        loops.append(pts)
    return loops


def region_area(region) -> float:
    return float(region.area)


def _signed_area(poly) -> float:
    p = np.asarray(poly, dtype=float)
    x, y = p[:, 0], p[:, 1]
    return 0.5 * float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))


def face_plane(shape, face_id: int):
    """(origin, x_dir, y_dir, z_dir) of a planar face in the shape's space (z = outward), or None."""
    face = shape.faces()[face_id]
    if not bool(face.is_planar):
        return None
    pl = _call("plane", _s.Plane, face)
    return tuple(pl.origin), tuple(pl.x_dir), tuple(pl.y_dir), tuple(pl.z_dir)


def shape_snap_points(shape):
    """Snap points of a whole part in its own space: [(point, kind)] for its corners, edge midpoints
    and the centers of circular edges."""
    out, seen = [], []

    def add(p, kind):
        p = np.asarray(tuple(p)[:3], dtype=float)
        for q in seen:
            if float(np.linalg.norm(q - p)) < 1e-9:
                return
        seen.append(p)
        out.append((tuple(p), kind))

    for e in shape.edges():
        gt = str(e.geom_type).lower()
        if not bool(e.is_closed):
            add(e.start, "corner")
            add(e.end, "corner")
            add(e.point_at(0.5), "edge mid")
        if "circle" in gt or "arc" in gt:
            try:
                add(e.arc_center, "center")
            except Exception:
                pass
        elif gt != "line":
            c = _circle_center_of(e)       # (a circle the kernel keeps as a B-spline: a loft's end)
            if c is not None:
                add(c, "center")
        if gt != "line":
            for q in _quadrants(e):
                add(q, "quadrant")
    # the middle of each flat face (as a sketch on it snaps to)
    for f in shape.faces():
        if str(f.geom_type).lower() == "plane":
            try:
                add(f.center(), "face center")
            except Exception:
                pass
    return out


def _quadrants(e):
    """The quadrant points of a circular edge (or of the part of them an arc covers): the circle's
    furthest points along the part's X, Y and Z, as the circle shows its outline from a front, side
    or top view (a closed circle has no corners to snap to)."""
    try:
        got = circle_of(e)
    except Exception:
        got = None
    if got is None:
        return []
    c, n, r = got
    if not r > 0:
        return []
    closed = bool(e.is_closed)
    out = []
    for ax in np.eye(3):
        d = ax - float(np.dot(ax, n)) * n
        L = float(np.linalg.norm(d))
        if L < 1e-6:
            continue
        for sgn in (1.0, -1.0):
            q = c + sgn * r * d / L
            if not closed:
                try:
                    if float(np.linalg.norm(_vec(e.closest_point(tuple(q))) - q)) > r * 1e-6:
                        continue
                except Exception:
                    continue
            out.append(q)
    return out


def circle_of(e):
    """(center, unit normal, radius) of an edge that is a circle or an arc of 45 degrees or more of
    one (any curve type), else None."""
    gt = str(e.geom_type).lower()
    if "circle" in gt or "arc" in gt:
        try:
            return _vec(e.arc_center), _unit(_vec(e.normal)), float(e.radius)
        except Exception:
            pass
    if gt == "line":
        return None
    c = _circle_center_of(e)
    if c is None:
        return None
    try:
        P = np.array(_fast_points(e, np.linspace(0.0, 1.0, 9)))
    except Exception:
        return None
    _u, _s, vt = np.linalg.svd(P - P.mean(axis=0))
    return c, _unit(vt[2]), float(np.mean(np.linalg.norm(P - c, axis=1)))


def part_axis(shape):
    """The axis a round part is built about, in its own space: (point, unit direction), or None.
    The line the most of its circles (circular edges of any curve type, the ends and sections of a
    loft, a cylinder's rims) are centred on and square to, the ones with the most length breaking
    a tie; a cylinder or cone face counts as its axis too."""
    size = max(body_size(shape), 1e-12)
    lines = []                                  # [point, direction, {centers}, length]

    def put(c, d, length, circle=True):
        d = _unit(d)
        for L in lines:
            if float(np.linalg.norm(np.cross(L[1], d))) < 1e-5 and \
                    float(np.linalg.norm(np.cross(c - L[0], L[1]))) < size * 1e-5:
                if circle:
                    L[2].add(round(float(np.dot(c - L[0], L[1])) / (size * 1e-4)))
                L[3] += length
                return
        lines.append([c, d, {0} if circle else set(), length])

    for e in shape.edges():
        got = circle_of(e)
        if got is not None:
            c, n, r = got
            put(c, n, float(e.length))
    for f in shape.faces():
        if str(f.geom_type).lower() in ("cylinder", "cone"):
            try:
                ax = f.axis
                put(_vec(ax.origin), _vec(ax.direction), float(f.area) / max(_face_radius(f), 1e-12), circle=False)
            except Exception:
                pass
    if not lines:
        return None
    best = max(lines, key=lambda L: (len(L[2]), L[3]))
    return best[0], best[1]


def _face_radius(f) -> float:
    try:
        return float(f.radius)
    except Exception:
        return 1.0


def _circle_center_of(e, n: int = 24):
    """The center of an edge that is a circle or an arc of one, whatever curve type carries it
    (within a ten-thousandth of its radius), else None."""
    try:
        ts = np.linspace(0.0, 1.0, n, endpoint=not bool(e.is_closed))
        P = np.array(_fast_points(e, ts))
    except Exception:
        return None
    c0 = P.mean(axis=0)
    _u, s, vt = np.linalg.svd(P - c0)
    span = float(s[0]) if len(s) else 0.0
    if span <= 0 or float(s[2]) > span * 1e-5:
        return None                            # not flat
    ax, ay = vt[0], vt[1]
    x, y = (P - c0) @ ax, (P - c0) @ ay
    A = np.c_[2 * x, 2 * y, np.ones(len(x))]
    try:
        (a, b, k), *_ = np.linalg.lstsq(A, x * x + y * y, rcond=None)
    except Exception:
        return None
    r2 = k + a * a + b * b
    if r2 <= 0:
        return None
    r = math.sqrt(r2)
    dev = np.abs(np.hypot(x - a, y - b) - r)
    if float(dev.max()) > r * 1e-4:
        return None
    # an arc of a few degrees is too flat to give a center worth snapping to
    ang = np.unwrap(np.arctan2(y - b, x - a))
    if not bool(e.is_closed) and abs(float(ang[-1] - ang[0])) < math.radians(45):
        return None
    return c0 + a * ax + b * ay


def face_snap_data(shape, face_id: int, samples: int = 48):
    """Snap targets of a face in the shape's space: ([(point, kind)], [polyline (k, 3)]).

    Points: the corners of its edges, edge midpoints, centers of circular edges, the face center.
    Polylines: every edge, for snapping onto an edge (and taking its direction)."""
    face = shape.faces()[face_id]
    pts, lines = [], []
    seen = []

    def add(p, kind):
        p = np.asarray(tuple(p)[:3], dtype=float)
        for q, _k in seen:
            if float(np.linalg.norm(q - p)) < 1e-9:
                return
        seen.append((p, kind))

    for e in face.edges():
        gt = str(e.geom_type)
        closed = bool(e.is_closed)
        if not closed:
            add(e.start, "corner")
            add(e.end, "corner")
            add(e.point_at(0.5), "edge mid")
        if "circle" in gt.lower() or "arc" in gt.lower():
            try:
                add(e.arc_center, "center")
                if closed:
                    for t in (0.0, 0.25, 0.5, 0.75):
                        add(e.point_at(t), "quadrant")
            except Exception:
                pass
        k = 2 if gt.lower() == "line" else samples
        lines.append(np.array([tuple(e.point_at(t))[:3] for t in np.linspace(0.0, 1.0, k)]))
    try:
        add(face.center(), "face center")
    except Exception:
        pass
    pts = [(tuple(p), kind) for p, kind in seen]
    return pts, lines


def _unit(v):
    v = np.asarray(tuple(v), dtype=float)
    n = float(np.linalg.norm(v))
    return v / n if n > 1e-12 else v


def face_frame(shape, face_id: int):
    """(point on the face near its middle, outward unit normal there), in shape space."""
    face = shape.faces()[face_id]
    p = face.center()
    try:
        p = face.closest_point(p)
    except Exception:
        p = face.interior_point()
    if hasattr(p, "point"):
        p = p.point
    return tuple(float(c) for c in tuple(p)[:3]), tuple(_unit(face.normal_at(p)))


def edge_frame(shape, edge_id: int):
    """(edge midpoint, outward bisector of the two faces' normals there), in shape space.

    For a box edge that is the 45 degree direction between the two faces."""
    edge = shape.edges()[edge_id]
    m = edge.point_at(0.5)
    normals = []
    try:
        for f in edge.faces():
            normals.append(_unit(f.normal_at(m)))
    except Exception:
        pass
    d = _unit(sum(normals)) if normals else np.zeros(3)
    if float(np.linalg.norm(d)) < 1e-9:  # a smooth edge (normals cancel or one face): use one normal
        d = normals[0] if normals else np.array([0.0, 0.0, 1.0])
    return tuple(float(c) for c in tuple(m)[:3]), tuple(float(c) for c in d)


def profile_center(profile):
    try:
        c = profile.center()
        return tuple(float(x) for x in tuple(c)[:3])
    except Exception:
        b = profile.bbox()
        return tuple((np.asarray(tuple(b.min)) + np.asarray(tuple(b.max))) / 2)


def max_hint(message: str):
    """The largest value the kernel says would fit ("largest possible setback here: 0.242"), or None."""
    import re
    m = re.search(r"largest possible[^:]*:\s*([0-9.eE+-]+)", message or "")
    if not m:
        return None
    try:
        return float(m.group(1))
    except ValueError:
        return None


def face_vertices(shape, face_id: int) -> list[tuple]:
    try:
        return [tuple(v) if not hasattr(v, "center") else tuple(v.center()) for v in shape.faces()[face_id].vertices()]
    except Exception:
        return []


def extrude(profile, amount: float, both: bool = False, taper: float = 0.0):
    return _call("extrude", _s.extrude, profile, amount, both=both, taper=taper)


def extrude_surface(w, amount: float, both: bool = False, direction=(0.0, 0.0, 1.0)):
    """A surface from a curve (open or closed: a closed loop gives a tube without caps), along
    `direction` (the sketch's normal)."""
    edges = list(w.edges()) if type(w).__name__ == "Wire" else [w]
    if type(w).__name__ == "Wire" and not wire_is_closed(w):
        return _call("extrude", _s.extrude, w, amount, both=both, direction=tuple(direction))
    pieces = [_call("extrude", _s.extrude, e, amount, both=both, direction=tuple(direction)) for e in edges]
    return combine(pieces)


def revolve_surface(w, axis_origin, axis_dir, angle: float = 360.0):
    """A surface of revolution from a curve (a closed loop gives a ring without caps)."""
    ax = _s.Axis(tuple(axis_origin), tuple(axis_dir))
    if type(w).__name__ == "Wire" and not wire_is_closed(w):
        return _call("revolve", _s.revolve, w, ax, angle)
    edges = list(w.edges()) if type(w).__name__ == "Wire" else [w]
    return combine([_call("revolve", _s.revolve, e, ax, angle) for e in edges])


def as_sheet(x):
    """A lone face as a sheet body (bodies pass through)."""
    return _call("sheet", _s.stitch, x) if type(x).__name__ == "Face" else x


def open_caps(shape, sections):
    """A lofted solid without the faces lying on its first and last sections (a surface)."""
    if not isinstance(shape, _s.Part):
        return shape
    faces = list(shape.faces())
    caps = []
    for sec in (sections[0], sections[-1]):
        try:
            if isinstance(sec, (tuple, list, np.ndarray)):
                c = np.asarray(sec, dtype=float)[:3]
            else:
                c = np.asarray(tuple(sec.center())[:3], dtype=float) if hasattr(sec, "center") else None
        except Exception:
            c = None
        best = None
        for i, f in enumerate(faces):
            if not bool(f.is_planar):
                continue
            fc = np.asarray(tuple(f.center())[:3], dtype=float)
            d = float(np.linalg.norm(fc - c)) if c is not None else 0.0
            if best is None or d < best[0]:
                best = (d, i)
        if best is not None:
            caps.append(best[1])
    rest, _gone = unstitch(shape, caps)
    return rest if rest is not None else shape


def revolve(profile, axis_origin, axis_dir, angle: float = 360.0):
    ax = _s.Axis(tuple(axis_origin), tuple(axis_dir))
    return _call("revolve", _s.revolve, profile, ax, angle)


def loft(sections, ruled: bool = False, align: bool = True, start_tangent=None, end_tangent=None):
    """A loft through sections. start_tangent / end_tangent: a face the loft continues (G1) at its
    first / last section (a surface whose edge the section is)."""
    sections = list(sections)
    if align:
        aligned = align_loft_sections(sections)
        if aligned is not None:
            sections = aligned
        else:
            sections = align_open_sections(sections)
    kw = {}
    if start_tangent is not None:
        kw["start_tangent"] = start_tangent
    if end_tangent is not None:
        kw["end_tangent"] = end_tangent
    if not kw:
        # open curves: one untrimmed NURBS patch through them (the kernel would make a trimmed
        # plane of curves lying in one plane)
        got = _open_skin(sections, ruled=ruled)
        if got is not None:
            return got
    return _call("loft", _s.loft, sections, ruled=ruled, **kw)


def align_open_sections(sections):
    """Open sections all running the same way (each starts at the end nearer the previous start),
    so a loft between them does not cross over itself."""
    out = []
    for sec in sections:
        if type(sec).__name__ not in ("Wire", "Edge") or bool(sec.is_closed) or not out:
            out.append(sec)
            continue
        prev = out[-1]
        try:
            ps, pe = _vec(prev.start), _vec(prev.end)
            s0, e0 = _vec(sec.start), _vec(sec.end)
        except Exception:
            out.append(sec)
            continue
        same = np.linalg.norm(s0 - ps) + np.linalg.norm(e0 - pe)
        flip = np.linalg.norm(s0 - pe) + np.linalg.norm(e0 - ps)
        out.append(sec.reversed() if flip < same else sec)
    return out


def edge_sections(shape, edge_ids):
    """Loft sections from picked edges: [(wire, face it borders or None)], one per connected run of
    edges. The face is given when the run lies on the border of a surface (one face there): a loft
    can continue that face."""
    edges = list(shape.edges())
    picked = [edges[i] for i in sorted(set(edge_ids)) if 0 <= i < len(edges)]
    size = max(float(shape.bbox().diagonal), 1e-9)
    tol = 1e-7 * size
    runs = []
    for e in picked:
        a, b = _vec(e.start), _vec(e.end)
        hit = [r for r in runs if any(np.linalg.norm(a - p) < tol or np.linalg.norm(b - p) < tol
                                      for q in r for p in (_vec(q.start), _vec(q.end)))]
        merged = [e] + [q for r in hit for q in r]
        runs = [r for r in runs if r not in hit] + [merged]
    out = []
    for r in runs:
        w = wire(r) if len(r) > 1 else wire([r[0]])
        face = None
        try:
            adj = [list(q.faces()) for q in r]
            if all(len(a) == 1 for a in adj):
                # an open edge of one surface; a run along several surfaces' open edges: all of them
                # (a tuple: what each part of the curve borders is found where it is needed)
                fs = []
                for a in adj:
                    if not any(a[0].is_same(g) if hasattr(a[0], "is_same") else a[0] == g for g in fs):
                        fs.append(a[0])
                face = fs[0] if len(fs) == 1 else tuple(fs)
        except Exception:
            face = None
        out.append((w, face))
    return out


def face_sections(shape, face_ids):
    """Loft sections from picked faces: the planar faces themselves (a solid loft), else their outer
    outline as a closed wire."""
    faces = list(shape.faces())
    out = []
    for i in sorted(set(face_ids)):
        if not 0 <= i < len(faces):
            continue
        f = faces[i]
        out.append(f if bool(f.is_planar) and not list(f.inner_wires()) else f.outer_wire())
    return out


# ----------------------------------------------------------------------------- loft section alignment

def _vec(p):
    return np.asarray(tuple(p)[:3], dtype=float)


def _ordered_loop(w):
    """The edges of a closed wire, head to tail, each oriented along the walk."""
    edges = list(w.edges())
    if len(edges) <= 1:
        return edges
    tol = max(float(w.bbox().diagonal), 1e-9) * 1e-7
    out = [edges[0]]
    # orient the first edge so its end meets the second
    s0, e0 = _vec(edges[0].start), _vec(edges[0].end)
    s1, e1 = _vec(edges[1].start), _vec(edges[1].end)
    if min(np.linalg.norm(s0 - s1), np.linalg.norm(s0 - e1)) < min(np.linalg.norm(e0 - s1), np.linalg.norm(e0 - e1)):
        out[0] = edges[0].reversed()
    rest = edges[1:]
    while rest:
        tail = _vec(out[-1].end)
        best = min(range(len(rest)), key=lambda i: min(np.linalg.norm(_vec(rest[i].start) - tail),
                                                         np.linalg.norm(_vec(rest[i].end) - tail)))
        e = rest.pop(best)
        if np.linalg.norm(_vec(e.end) - tail) < np.linalg.norm(_vec(e.start) - tail) - tol:
            e = e.reversed()
        out.append(e)
    return out


def _loop_samples(edges, per: int = 8) -> np.ndarray:
    pts = []
    for e in edges:
        pts += [_vec(e.point_at(i / per)) for i in range(per)]
    return np.array(pts)


def _newell(pts) -> np.ndarray:
    n = np.zeros(3)
    for a, b in zip(pts, np.roll(pts, -1, axis=0)):
        n += np.array([(a[1] - b[1]) * (a[2] + b[2]), (a[2] - b[2]) * (a[0] + b[0]), (a[0] - b[0]) * (a[1] + b[1])])
    L = float(np.linalg.norm(n))
    return n / L if L > 1e-15 else np.array([0.0, 0.0, 1.0])


def _reverse_loop(edges):
    return [e.reversed() for e in reversed(edges)]


def _is_smooth_loop(edges, angle_deg: float = 2.0) -> bool:
    """A closed loop without corners: one closed curve, or edges that meet tangentially."""
    if len(edges) == 1:
        return True
    lim = math.cos(math.radians(angle_deg))
    for prev, cur in zip([edges[-1]] + edges[:-1], edges):
        try:
            a = _unit(prev.tangent_at(1.0))
            b = _unit(cur.tangent_at(0.0))
        except Exception:
            return False
        if float(np.dot(a, b)) < lim:
            return False
    return True


def _reseam_smooth(edges, seam_dir, center, normal):
    """The same smooth closed loop, starting where seam_dir points from its center.

    Exact circles stay exact circles; any other smooth loop becomes one closed spline through
    dense points of it (within the loop's own accuracy)."""
    x = seam_dir - normal * float(np.dot(seam_dir, normal))
    if float(np.linalg.norm(x)) < 1e-9:
        x = _vec(edges[0].start) - center
    x = x / max(float(np.linalg.norm(x)), 1e-12)
    if len(edges) == 1 and str(edges[0].geom_type).lower() == "circle":
        e = edges[0]
        plane = _s.Plane(tuple(_vec(e.arc_center)), x_dir=tuple(x), z_dir=tuple(normal))
        return [_call("loft section", _s.CenterArc, (0, 0, 0), float(e.radius), 0.0, 360.0, plane=plane)]
    lengths = np.array([max(float(e.length), 1e-12) for e in edges])
    counts = np.maximum(4, np.round(720 * lengths / lengths.sum())).astype(int)
    pts = np.vstack([np.array([_vec(e.point_at(i / k)) for i in range(k)]) for e, k in zip(edges, counts)])
    rel = pts - center
    rel /= np.maximum(np.linalg.norm(rel, axis=1, keepdims=True), 1e-12)
    start = int(np.argmax(rel @ x))
    pts = np.roll(pts, -start, axis=0)
    pick = pts[np.linspace(0, len(pts), 64, endpoint=False).astype(int)]
    return [spline_through([tuple(p) for p in pick], True)]


def _split_smooth_at(edges, directions, center, normal):
    """Split a re-seamed smooth loop (one edge, starting at directions[0]) into len(directions)
    edges, at the points that lie in those directions from its center (in traversal order)."""
    if len(edges) != 1 or len(directions) < 2:
        return edges
    e = edges[0]
    proj = []
    for d in directions:
        v = np.asarray(d, dtype=float) - normal * float(np.dot(d, normal))
        n = float(np.linalg.norm(v))
        if n < 1e-12:
            return edges
        proj.append(v / n)
    if str(e.geom_type).lower() == "circle":
        c, r = _vec(e.arc_center), float(e.radius)
        x = proj[0]
        y = np.cross(normal, x)
        plane = _s.Plane(tuple(c), x_dir=tuple(x), z_dir=tuple(normal))
        ang = [0.0] + [math.degrees(math.atan2(float(np.dot(p, y)), float(np.dot(p, x)))) % 360.0 for p in proj[1:]]
        if any(b <= a for a, b in zip(ang, ang[1:])):
            return edges  # directions not in traversal order: leave the circle whole
        ang.append(360.0)
        return [_call("loft section", _s.CenterArc, (0, 0, 0), r, a, b - a, plane=plane) for a, b in zip(ang, ang[1:])]
    # a smooth spline: cut at the points closest to each direction, walking along the loop
    dense = np.array([_vec(e.point_at(i / 720)) for i in range(720)])
    rel = dense - center
    rel /= np.maximum(np.linalg.norm(rel, axis=1, keepdims=True), 1e-12)
    idx = [int(np.argmax(rel @ p)) for p in proj[1:]]
    if any(b <= a for a, b in zip([0] + idx, idx)):
        return edges
    pieces, tail = [], e
    for i in idx:
        a, b = tail.split(tuple(dense[i]))
        pieces.append(a)
        tail = b
    pieces.append(tail)
    return pieces


def section_center(section) -> np.ndarray:
    try:
        return _vec(section.center())
    except Exception:
        b = section.bbox()
        return (_vec(b.min) + _vec(b.max)) / 2


def order_sections(centers) -> list[int]:
    """An order through section centers that never doubles back: start at one end of the
    stack (along its main direction), then always step to the nearest remaining section."""
    C = np.asarray(centers, dtype=float)
    n = len(C)
    if n <= 2:
        return list(range(n))
    X = C - C.mean(axis=0)
    axis = np.linalg.svd(X, full_matrices=False)[2][0]
    proj = X @ axis
    order = [int(np.argmin(proj))]
    left = set(range(n)) - set(order)
    while left:
        last = C[order[-1]]
        nxt = min(left, key=lambda i: float(np.linalg.norm(C[i] - last)))
        order.append(nxt)
        left.remove(nxt)
    return order


def align_loft_sections(sections):
    """Closed wires for a loft: same winding for all, and each loop starting at the vertex that
    matches the previous loop's start, so the loft neither twists nor turns inside out.
    Returns None when a section can't be aligned (holes, several pieces): loft them as given."""
    loops = []
    for sec in sections:
        if type(sec).__name__ == "Wire":
            if not sec.is_closed:
                return None
            w = sec
        else:
            try:
                faces = list(sec.faces())
            except Exception:
                return None
            if len(faces) != 1 or list(faces[0].inner_wires()):
                return None
            w = faces[0].outer_wire()
        loops.append(_ordered_loop(w))

    ref_normal = None
    info = []
    prev_rel = None   # previous loop's vertices relative to its center, scale-free
    prev_seam = None  # previous loop's start direction
    out = []
    for edges in loops:
        samples = _loop_samples(edges)
        c = samples.mean(axis=0)
        n = _newell(samples)
        if ref_normal is None:
            ref_normal = n
        elif float(np.dot(n, ref_normal)) < 0:
            edges = _reverse_loop(edges)
            samples = _loop_samples(edges)
            n = -n
        size = max(float(np.linalg.norm(samples - c, axis=1).mean()), 1e-12)

        if _is_smooth_loop(edges):
            # no corners to match: start the loop where the previous one starts (or where it
            # already starts, for the first section)
            seam = prev_seam if prev_seam is not None else _vec(edges[0].start) - c
            try:
                edges = _reseam_smooth(edges, seam, c, n)
            except CadError:
                pass
        elif prev_seam is not None:
            if False:
                pass
            else:
                verts = np.array([_vec(e.start) for e in edges])
                rel = (verts - c) / size
                if prev_rel is not None and len(prev_rel) == len(rel):
                    costs = [float(np.sum((np.roll(rel, -k, axis=0) - prev_rel) ** 2)) for k in range(len(rel))]
                else:
                    dirs = rel / np.maximum(np.linalg.norm(rel, axis=1, keepdims=True), 1e-12)
                    costs = [-float(np.dot(d, prev_seam)) for d in dirs]
                k = int(np.argmin(costs))
                edges = edges[k:] + edges[:k]
        verts = np.array([_vec(e.start) for e in edges])
        prev_rel = (verts - c) / size
        d0 = verts[0] - c
        prev_seam = d0 / max(float(np.linalg.norm(d0)), 1e-12)
        info.append({"edges": edges, "center": c, "normal": n, "smooth": len(edges) == 1})

    # Smooth loops next to a loop with corners get the same number of edges, cut in the
    # directions of those corners, so the kernel maps corner to matching point.
    for k, it in enumerate(info):
        if not it["smooth"]:
            continue
        near = None
        for j in sorted(range(len(info)), key=lambda j: (abs(j - k), j > k)):
            if j != k and not info[j]["smooth"]:
                near = info[j]
                break
        if near is None:
            continue
        dirs = [_vec(e.start) - near["center"] for e in near["edges"]]
        try:
            it["edges"] = _split_smooth_at(it["edges"], dirs, it["center"], it["normal"])
        except Exception:
            pass
    return [_call("loft section", _s.Wire, it["edges"], sort=False) for it in info]


# ----------------------------------------------------------------------------- bridging two faces

_BRIDGE_ROWS = {"G0": 1, "G1": 2, "G2": 3, "G3": 4}

# handle step / chord for a curve that runs like a circular arc (turning angle 0), by degree:
# cubic (G1-G1): 1/3, quintic (G2-G2): 4/25 (its midpoint lies on the arc); between: interpolated
_ARC_STEP = {1: 0.0, 2: 0.5, 3: 1.0 / 3.0, 4: 0.24, 5: 4.0 / 25.0}


def arc_step(pa, da, pb, db, deg: int) -> float:
    """The handle step that makes the curve from pa (leaving along da) to pb (arriving against db,
    i.e. db points away from pb's side) run like a circular arc: c / cos^2(theta / 4) times a
    per-degree constant, c the chord and theta the turning angle. Exact for cubic arcs (the classic
    4/3 tan(theta / 4) r), the midpoint on the arc for quintics."""
    c = float(np.linalg.norm(np.asarray(pb) - np.asarray(pa)))
    t0, t1 = _unit(da), -_unit(db)
    cos_t = float(np.clip(np.dot(t0, t1), -1.0, 1.0))
    theta = math.acos(cos_t)
    q = math.cos(theta / 4.0) ** 2
    return _ARC_STEP.get(deg, 1.0 / max(deg, 1)) * c / max(q, 1e-3)


def _closest(e, p) -> np.ndarray:
    q = e.closest_point(tuple(p))
    return _vec(getattr(q, "point", q))


def _wall_direction(free_edges, p, n_face):
    """Across the open rim at p, along the wall: the wall's tangent perpendicular to the rim,
    pointing away from the part."""
    e = min(free_edges, key=lambda x: float(np.linalg.norm(_closest(x, p) - p)))
    try:
        t = _unit(e.tangent_at(e.param_at_point(tuple(p))))
    except Exception:
        t = _unit(_vec(e.end) - _vec(e.start))
    w = _unit(e.faces()[0].normal_at(tuple(p)))
    d = _unit(np.cross(t, w))
    return d if float(np.dot(d, n_face)) >= 0 else -d


def _corner_direction(shell, p, n_face, tol):
    """At a corner of the rim: along the part's edge between the two walls, away from the part
    (it lies in both walls, so both neighbouring patches stay tangent to their own wall)."""
    for e in shell.edges():
        if len(e.faces()) != 2:
            continue
        if np.linalg.norm(_vec(e.start) - p) < tol:
            d = -_unit(e.tangent_at(0.0))
        elif np.linalg.norm(_vec(e.end) - p) < tol:
            d = _unit(e.tangent_at(1.0))
        else:
            continue
        if float(np.dot(d, n_face)) > 1e-9:
            return d
    return None


def _rotation_between(u, v, fallback_axis):
    """3x3 rotation taking unit vector u onto unit vector v (about fallback_axis when opposite)."""
    u, v = _unit(u), _unit(v)
    c = float(np.clip(np.dot(u, v), -1.0, 1.0))
    axis = np.cross(u, v)
    if float(np.linalg.norm(axis)) < 1e-9:
        if c > 0:
            return np.eye(3)
        axis = fallback_axis - u * float(np.dot(fallback_axis, u))
        if float(np.linalg.norm(axis)) < 1e-9:
            axis = np.cross(u, [1.0, 0.0, 0.0]) if abs(u[0]) < 0.9 else np.cross(u, [0.0, 1.0, 0.0])
    k = _unit(axis)
    angle = math.acos(c)
    K = np.array([[0, -k[2], k[1]], [k[2], 0, -k[0]], [-k[1], k[0], 0]])
    return np.eye(3) + math.sin(angle) * K + (1 - math.cos(angle)) * K @ K


def _align_bridge_rims(wire_a, wire_b, n_a, n_b, c_a, c_b):
    """Matching edges of two face outlines for a bridge.

    The bridge leaves face A along n_a and arrives into face B along -n_b, turning on the way
    (half a turn when both faces point the same way, as across the gap of a U). The outline of B
    is carried into A's frame by that turn before corners are matched, so each side of A meets
    the side of B it really faces, and both get the same winding."""
    R = _rotation_between(n_a, -n_b, np.cross(n_a, c_b - c_a))
    to_a = np.eye(4)
    to_a[:3, :3] = R.T
    to_a[:3, 3] = c_a - R.T @ c_b
    from_a = np.linalg.inv(to_a)
    b_in_a = moved(wire_b, to_a)
    la, lb = _ordered_loop(wire_a), _ordered_loop(b_in_a)
    if len(la) == len(lb) > 1:
        # the same number of edges (a slot to a slot, smooth or not): corner to corner, the
        # edges kept exactly as they are (no refit of smooth loops)
        Sa, Sb = _loop_samples(la), _loop_samples(lb)
        if float(np.dot(_newell(Sa), _newell(Sb))) < 0:
            lb = _reverse_loop(lb)
        va = np.array([_vec(e.start) for e in la])
        vb = np.array([_vec(e.start) for e in lb])
        ra_ = (va - Sa.mean(axis=0)) / max(float(np.linalg.norm(Sa - Sa.mean(axis=0), axis=1).mean()), 1e-12)
        rb_ = (vb - Sb.mean(axis=0)) / max(float(np.linalg.norm(Sb - Sb.mean(axis=0), axis=1).mean()), 1e-12)
        costs = [float(np.sum((np.roll(rb_, -k, axis=0) - ra_) ** 2)) for k in range(len(lb))]
        k = int(np.argmin(costs))
        lb = lb[k:] + lb[:k]
        return list(la), [moved(e, from_a) for e in lb]
    aligned = align_loft_sections([wire_a, b_in_a])
    if aligned is None:
        raise CadError("bridge: these faces' outlines can't be matched")
    ea = list(aligned[0].edges())
    eb = [moved(e, from_a) for e in aligned[1].edges()]
    return ea, eb


def bridge_auto_takeoff(a, face_a: int, b, face_b: int, cont_a: str = "G1", cont_b: str = "G1") -> float:
    """The take-off a bridge gets by default (at the middle of the faces): round, like an arc."""
    fa = a.faces()[face_a]
    fb = (a if b is None else b).faces()[face_b]
    deg_v = _BRIDGE_ROWS[cont_a] + _BRIDGE_ROWS[cont_b] - 1
    if deg_v <= 1:
        return 0.0
    return deg_v * arc_step(_vec(fa.center()), _unit(fa.normal_at()), _vec(fb.center()), _unit(fb.normal_at()),
                            deg_v)


def bridge_faces(a, face_a: int, b, face_b: int, cont_a: str = "G1", cont_b: str = "G1",
                 takeoff_a: float | None = None, takeoff_b: float | None = None, rail: bool = True,
                 join: bool = True):
    """A solid bridge between a face of part `a` and a face of part `b` (b may be a itself, for
    a second face of the same part). Both faces are opened, a NURBS patch is built for each pair
    of matching rim edges and everything is sewn into one solid.

    Continuity per end: "G0" (straight from the rim), "G1" (tangent to the walls around the
    face), "G2" (curvature continuous as well; exact for walls that are straight across the rim,
    as on boxes, drafted extrusions and cylinders). takeoff_*: how far the bridge runs along the
    walls before it turns, at the middle of the faces (default: round, like an arc).

    rail=True (default): every point of the rim gets its own take-off, in proportion to how far it
    has to go (its chord) and how much it turns, so the bridge follows the path between the face
    centres like a bent pipe: the inner side of a bend gets short handles, the outer side long ones,
    and the cross-section keeps its size instead of pinching on the inside. rail=False: the same
    take-off everywhere (the classic loft, which collapses on the inside of a bend).

    join=False: the bridge alone, a solid closed by the two faces (the parts are left as they are).
    """
    for c in (cont_a, cont_b):
        if c not in _BRIDGE_ROWS:
            raise CadError(f"bridge: continuity must be G0, G1, G2 or G3, not {c!r}")
    same = b is None or b is a
    fa = a.faces()[face_a]
    fb = (a if same else b).faces()[face_b]
    for f in (fa, fb):
        if list(f.inner_wires()):
            raise CadError("bridge: faces with holes can't be bridged yet")
    na, nb = _unit(fa.normal_at()), _unit(fb.normal_at())
    D = float(np.linalg.norm(_vec(fa.center()) - _vec(fb.center())))
    if D < 1e-9:
        raise CadError("bridge: the two faces touch; pick faces that face each other across a gap")
    ca_, cb_ = _vec(fa.center()), _vec(fb.center())

    if same:
        opened_a = opened_b = _call("bridge", _s.stitch,
                                    [f for i, f in enumerate(a.faces()) if i not in (face_a, face_b)])
        keep = list(opened_a.faces())
    else:
        opened_a = _call("bridge", _s.stitch, [f for i, f in enumerate(a.faces()) if i != face_a])
        opened_b = _call("bridge", _s.stitch, [f for i, f in enumerate(b.faces()) if i != face_b])
        keep = list(opened_a.faces()) + list(opened_b.faces())
    free_a = [e for e in opened_a.edges() if len(e.faces()) == 1]
    free_b = [e for e in opened_b.edges() if len(e.faces()) == 1]
    size = max(float(a.bbox().diagonal), float((a if same else b).bbox().diagonal))
    tol = size * 1e-7

    ea, eb = _align_bridge_rims(fa.outer_wire(), fb.outer_wire(), na, nb,
                                _vec(fa.center()), _vec(fb.center()))
    if len(ea) != len(eb):
        raise CadError(f"bridge: the faces have {len(ea)} and {len(eb)} corners; pick faces with the same "
                       "number of corners, or a round one")
    ra, rb = _BRIDGE_ROWS[cont_a], _BRIDGE_ROWS[cont_b]
    deg_v = ra + rb - 1
    steps = max(deg_v, 1)
    # the rail: from face centre to face centre, leaving / arriving along the face normals
    h_rail = arc_step(ca_, na, cb_, nb, deg_v) if deg_v > 1 else 0.0
    sa = (float(takeoff_a) / steps / h_rail) if (takeoff_a and h_rail > 1e-12) else 1.0
    sb = (float(takeoff_b) / steps / h_rail) if (takeoff_b and h_rail > 1e-12) else 1.0
    patches = []
    for ea_i, eb_i in zip(ea, eb):
        a2, b2 = _call("bridge", _s.make_compatible, ea_i, eb_i)
        Na, Nb = a2.nurbs(), b2.nurbs()
        Pa, Pb = [_vec(p) for p in Na.points], [_vec(p) for p in Nb.points]
        Wa = list(Na.weights) if Na.weights is not None else [1.0] * len(Pa)
        Wb = list(Nb.weights) if Nb.weights is not None else [1.0] * len(Pb)
        rows, wts = [], []
        for j, (pa, pb) in enumerate(zip(Pa, Pb)):
            qa, qb = _closest(ea_i, pa), _closest(eb_i, pb)
            end = j in (0, len(Pa) - 1)
            da = _corner_direction(opened_a, qa, na, tol * 10) if end else None
            db = _corner_direction(opened_b, qb, nb, tol * 10) if end else None
            if da is None:
                da = _wall_direction(free_a, qa, na)
            if db is None:
                db = _wall_direction(free_b, qb, nb)
            if rail:
                h_j = arc_step(qa, da, qb, db, deg_v)
                ha, hb = sa * h_j, sb * h_j
            else:
                ha, hb = sa * h_rail, sb * h_rail
            col = [pa + k * ha * da for k in range(ra)] + [pb + k * hb * db for k in reversed(range(rb))]
            rows.append([tuple(c) for c in col])
            wts.append([Wa[j]] * ra + [Wb[j]] * rb)
        rational = Na.weights is not None or Nb.weights is not None
        kv = [0.0] * (deg_v + 1) + [1.0] * (deg_v + 1)
        patch = _call("bridge", _s.nurbs_surface, rows, knots=(list(Na.knots), kv), degrees=(Na.degree, deg_v),
                      weights=wts if rational else None)
        patches += list(patch.faces())
    body = _call("bridge", _s.stitch, (keep if join else [fa, fb]) + patches)
    if not is_solid(body):
        raise CadError("bridge: the bridge did not close into a solid (try G0, or faces that face each other)")
    if not body.is_valid():
        raise CadError("bridge: the result is not a valid solid (the bridge crosses itself? try a smaller take-off)")
    return body


def _closed_fit(edges, size, tol_frac=1e-5):
    """One closed B-spline edge through a closed loop of edges (least squares, more control points
    until it keeps within tol_frac of the size), starting where the loop starts."""
    per = max(16, 400 // max(len(edges), 1))
    P = []
    for e in edges:
        P += [_vec(e.point_at(i / per)) for i in range(per)]
    P.append(P[0])
    P = np.array(P)
    d = np.concatenate([[0.0], np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))])
    ts = d / max(d[-1], 1e-300)
    best = None
    for ncv in (12, 20, 32, 48, 72, 100):
        knots, C = _fit_curve_points(P, ts, 3, ncv)
        e = _call("profile", _s.Edge.from_nurbs, (3, list(knots), [tuple(map(float, c)) for c in C], None))
        dev = max(float(e.distance_to(tuple(q))) for q in P[::max(1, len(P) // 120)])
        best = e
        if dev <= tol_frac * size:
            break
    return best


def _split_closed_at(edge, fractions):
    """A closed edge cut into pieces at fractions of its length (from its start)."""
    us = np.linspace(0.0, 1.0, 801)
    pts = np.array([_vec(edge.point_at(float(u))) for u in us])
    s = np.concatenate([[0.0], np.cumsum(np.linalg.norm(np.diff(pts, axis=0), axis=1))])
    s /= max(s[-1], 1e-300)
    cuts = [0.0] + [float(np.interp(f, s, us)) for f in fractions] + [1.0]
    return [_call("profile", edge.trim, cuts[k], cuts[k + 1]) for k in range(len(cuts) - 1)]


def _split_loop_at(edges, fractions, own=()):
    """A loop of edges (head to tail) with extra cuts at fractions of its whole length (cuts at
    its own corners, `own`, are not made again): the pieces, in order, exactly on the edges."""
    L = np.array([float(e.length) for e in edges])
    total = float(L.sum())
    starts = np.concatenate([[0.0], np.cumsum(L)[:-1]]) / total
    out = []
    for k, e in enumerate(edges):
        lo, hi = starts[k], starts[k] + L[k] / total
        cuts = sorted(f for f in fractions if lo + 1e-9 < f < hi - 1e-9)
        if not cuts:
            out.append(e)
            continue
        us = np.linspace(0.0, 1.0, 801)
        pts = np.array([_vec(e.point_at(float(u))) for u in us])
        s = np.concatenate([[0.0], np.cumsum(np.linalg.norm(np.diff(pts, axis=0), axis=1))])
        s /= max(s[-1], 1e-300)
        ps = [0.0] + [float(np.interp((f - lo) / (hi - lo), s, us)) for f in cuts] + [1.0]
        out += [_call("profile", e.trim, ps[j], ps[j + 1]) for j in range(len(ps) - 1)]
    return out


def bridge_face_profile(a, face_a: int, profile, cont_a: str = "G1", takeoff: float | None = None,
                        rail: bool = True, join: bool = True):
    """A solid bridge from a face of part `a` to a flat closed profile (a sketch's loop, in a's
    space): the face is opened, a NURBS patch runs from each edge of its rim to the matching piece
    of the profile, and the profile closes the end as a flat cap; all sewn into one solid with the
    part. It leaves the part with cont_a (G0 .. G3, as Bridge Faces) and meets the profile with
    G0 (a profile has no surface to continue). A profile with a different number of corners
    than the face (a circle onto a square face) is cut to match: its loop is refitted as one curve
    (within 1e-5 of the part's size) and cut at the rim's corners, by length.
    join=False: the bridge alone, a solid closed by the face and the cap (the part is left as it is)."""
    if cont_a not in _BRIDGE_ROWS:
        raise CadError(f"bridge: continuity must be G0, G1, G2 or G3, not {cont_a!r}")
    fa = a.faces()[face_a]
    if list(fa.inner_wires()):
        raise CadError("bridge: faces with holes can't be bridged yet")
    if type(profile).__name__ == "Wire":
        pw = profile
        if not pw.is_closed:
            raise CadError("bridge: the sketch's profile must be a closed loop")
    else:
        pfs = list(profile.faces())
        if len(pfs) != 1:
            raise CadError("bridge: the sketch must have one closed loop to bridge to")
        if list(pfs[0].inner_wires()):
            raise CadError("bridge: a profile with holes can't be bridged to yet")
        pw = pfs[0].outer_wire()
    loop = _ordered_loop(pw)
    S = _loop_samples(loop, 16)
    cb, n_s = S.mean(axis=0), _newell(S)
    na, ca_ = _unit(fa.normal_at()), _vec(fa.center())
    if float(np.linalg.norm(cb - ca_)) < 1e-9:
        raise CadError("bridge: the profile lies on the face; move the sketch away from it")
    if max(abs(float(np.dot(q - cb, n_s))) for q in S) > 1e-6 * max(float(pw.bbox().diagonal), 1e-9):
        raise CadError("bridge: the profile is not flat")
    # the cap's outward normal points away from the part; the bridge arrives against nb
    n_cap = n_s if float(np.dot(n_s, cb - ca_)) > 0 else -n_s
    nb = -n_cap
    opened_a = _call("bridge", _s.stitch, [f for i, f in enumerate(a.faces()) if i != face_a])
    keep = list(opened_a.faces())
    free_a = [e for e in opened_a.edges() if len(e.faces()) == 1]
    size = max(float(a.bbox().diagonal), float(pw.bbox().diagonal))
    tol = size * 1e-7
    ea, eb = _align_bridge_rims(fa.outer_wire(), pw, na, nb, ca_, cb)
    if len(ea) != len(eb):
        La = np.array([float(e.length) for e in ea])
        fa_fr = list(np.cumsum(La)[:-1] / La.sum())
        Lb = np.array([float(e.length) for e in eb])
        fb_fr = list(np.cumsum(Lb)[:-1] / Lb.sum())
        if len(eb) < len(ea) and all(min(abs(f - g) for g in fa_fr) < 2e-2 for f in fb_fr):
            # the profile's own corners sit at the rim's: cut its edges, exactly, at the other
            # corners (a circle, one edge, cut in four for a square face)
            eb = _split_loop_at(eb, [f for f in fa_fr if min([abs(f - g) for g in fb_fr] + [1.0]) >= 2e-2],
                                fb_fr)
        if len(eb) != len(ea):
            # corners that do not match: the profile refitted as one curve, cut at the rim's corners
            one = _closed_fit(loop, float(pw.bbox().diagonal), 1e-6)
            ea, eb1 = _align_bridge_rims(fa.outer_wire(), wire([one]), na, nb, ca_, cb)
            if len(eb1) != 1:
                raise CadError("bridge: the profile can't be matched to the face's corners")
            La = np.array([float(e.length) for e in ea])
            eb = _split_closed_at(eb1[0], list(np.cumsum(La)[:-1] / La.sum()))
    ra = _BRIDGE_ROWS[cont_a]
    deg_v = ra                    # (ra rows from the face, one at the profile)
    steps = max(deg_v, 1)
    h_rail = arc_step(ca_, na, cb, nb, deg_v) if deg_v > 1 else 0.0
    sa = (float(takeoff) / steps / h_rail) if (takeoff and h_rail > 1e-12) else 1.0
    patches = []
    for ea_i, eb_i in zip(ea, eb):
        a2, b2 = _call("bridge", _s.make_compatible, ea_i, eb_i)
        Na, Nb = a2.nurbs(), b2.nurbs()
        Pa, Pb = [_vec(p) for p in Na.points], [_vec(p) for p in Nb.points]
        Wa = list(Na.weights) if Na.weights is not None else [1.0] * len(Pa)
        Wb = list(Nb.weights) if Nb.weights is not None else [1.0] * len(Pb)
        rows, wts = [], []
        for j, (pa, pb) in enumerate(zip(Pa, Pb)):
            qa = _closest(ea_i, pa)
            end = j in (0, len(Pa) - 1)
            da = _corner_direction(opened_a, qa, na, tol * 10) if end else None
            if da is None:
                da = _wall_direction(free_a, qa, na)
            ha = sa * (arc_step(qa, da, pb, nb, deg_v) if rail else h_rail) if deg_v > 1 else 0.0
            col = [pa + k * ha * da for k in range(ra)] + [pb]
            rows.append([tuple(c) for c in col])
            wts.append([Wa[j]] * ra + [Wb[j]])
        rational = Na.weights is not None or Nb.weights is not None
        kv = [0.0] * (deg_v + 1) + [1.0] * (deg_v + 1)
        patch = _call("bridge", _s.nurbs_surface, rows, knots=(list(Na.knots), kv), degrees=(Na.degree, deg_v),
                      weights=wts if rational else None)
        patches += list(patch.faces())
    cap = face_from_wires(wire(list(eb)))
    body = _call("bridge", _s.stitch, (keep if join else [fa]) + patches + list(cap.faces()))
    if not is_solid(body):
        raise CadError("bridge: the bridge to the profile did not close into a solid (try G0, or a profile "
                       "that faces the face)")
    if not body.is_valid():
        raise CadError("bridge: the result is not a valid solid (the bridge crosses itself? try a smaller take-off)")
    return body


def _surface_out(face, e, q):
    """At point q of edge e on the border of a face: the face's direction across the edge, pointing
    away from the face (the way the surface would go on)."""
    try:
        t = _unit(e.tangent_at(e.param_at_point(tuple(q))))
    except Exception:
        t = _unit(_vec(e.end) - _vec(e.start))
    n = _unit(face.normal_at(tuple(q)))
    d = _unit(np.cross(t, n))
    size = max(float(face.bbox().diagonal), 1e-9)
    eps = size * 1e-3
    out_p, in_p = q + d * eps, q - d * eps
    if float(face.distance_to(tuple(out_p))) < float(face.distance_to(tuple(in_p))):
        d = -d
    return d


def blend_edges(edge_a, face_a, edge_b, face_b, cont_a="G1", cont_b="G1", takeoff=None, rail=True):
    """A surface between two edges, leaving each surface (face_*) with G0 / G1 / G2 (a face of None
    gives G0 there): one NURBS patch, rows along the surfaces' directions across their edges."""
    for c in (cont_a, cont_b):
        if c not in _BRIDGE_ROWS:
            raise CadError(f"blend: continuity must be G0, G1, G2 or G3, not {c!r}")
    ra = _BRIDGE_ROWS[cont_a] if face_a is not None else 1
    rb = _BRIDGE_ROWS[cont_b] if face_b is not None else 1
    # both edges run the same way
    sa, ea_ = _vec(edge_a.start), _vec(edge_a.end)
    sb, eb_ = _vec(edge_b.start), _vec(edge_b.end)
    if np.linalg.norm(sa - eb_) + np.linalg.norm(ea_ - sb) < np.linalg.norm(sa - sb) + np.linalg.norm(ea_ - eb_):
        edge_b = edge_b.reversed()
    D = float(np.linalg.norm(_vec(edge_a.center()) - _vec(edge_b.center())))
    if D < 1e-9:
        raise CadError("blend: the two edges touch")
    a2, b2 = _call("blend", _s.make_compatible, edge_a, edge_b)
    Na, Nb = a2.nurbs(), b2.nurbs()
    Pa, Pb = [_vec(p) for p in Na.points], [_vec(p) for p in Nb.points]
    Wa = list(Na.weights) if Na.weights is not None else [1.0] * len(Pa)
    Wb = list(Nb.weights) if Nb.weights is not None else [1.0] * len(Pb)
    deg_v = ra + rb - 1
    steps = max(deg_v, 1)
    dirs = []
    for pa, pb in zip(Pa, Pb):
        chord = _unit(pb - pa) if np.linalg.norm(pb - pa) > 1e-12 else np.array([0.0, 0.0, 1.0])
        da = _surface_out(face_a, edge_a, _closest(edge_a, pa)) if ra > 1 else chord
        db = _surface_out(face_b, edge_b, _closest(edge_b, pb)) if rb > 1 else -chord
        dirs.append((da, db))
    hs = [arc_step(pa, da, pb, db, deg_v) if deg_v > 1 else 0.0 for (pa, pb), (da, db) in zip(zip(Pa, Pb), dirs)]
    mid = len(hs) // 2
    h_mid = hs[mid] if hs else 0.0
    scale = (float(takeoff) / steps / h_mid) if (takeoff and h_mid > 1e-12) else 1.0
    rows, wts = [], []
    for j, (pa, pb) in enumerate(zip(Pa, Pb)):
        da, db = dirs[j]
        h = scale * (hs[j] if rail else h_mid)
        col = [pa + k * h * da for k in range(ra)] if ra > 1 else [pa]
        col += [pb + k * h * db for k in reversed(range(rb))] if rb > 1 else [pb]
        rows.append([tuple(c) for c in col])
        wts.append([Wa[j]] * ra + [Wb[j]] * rb)
    rational = Na.weights is not None or Nb.weights is not None
    kv = [0.0] * (deg_v + 1) + [1.0] * (deg_v + 1)
    return _call("blend", _s.nurbs_surface, rows, knots=(list(Na.knots), kv), degrees=(Na.degree, deg_v),
                 weights=wts if rational else None)


def bridge_frame(a, face_a: int):
    """(face center, outward normal) of the first face: where the take-off handle sits."""
    f = a.faces()[face_a]
    return tuple(_vec(f.center())), tuple(_unit(f.normal_at()))


def sweep(profile, path, rail=None, anchor=None, twist: float = 0.0, scale_end: float = 1.0):
    """Sweep a profile along a path; with a rail (an open profile from the path to the rail) the
    profile is moved, turned and scaled to keep its ends on both: a surface between two rails.
    anchor: a point of the profile that goes on the path (keeps a profile where it is drawn).
    twist: degrees the profile turns about the path over its length; scale_end: its size at the
    end (1 at the start, changing evenly)."""
    if rail is not None:
        return _call("sweep", _s.sweep, profile, path, rails=rail)
    kw = {}
    if anchor is not None:
        kw["anchor"] = tuple(anchor)
    if abs(twist) > 1e-12:
        kw["twist"] = float(twist)
    if abs(scale_end - 1.0) > 1e-12:
        kw["scale"] = (1.0, float(scale_end))
    return _call("sweep", _s.sweep, profile, path, **kw)


class _Polyline:
    """A wire sampled densely, for points at fractions of its length."""

    def __init__(self, w, reverse=False, k: int = 160):
        pts = []
        for e in _ordered_chain(list(w.edges())):
            for t in np.linspace(0.0, 1.0, k + 1)[(1 if pts else 0):]:
                pts.append(_vec(e.point_at(float(t))))
        P = np.array(pts)
        if reverse:
            P = P[::-1]
        self.P = P
        d = np.linalg.norm(np.diff(P, axis=0), axis=1)
        self.s = np.concatenate([[0.0], np.cumsum(d)])
        self.L = float(self.s[-1])

    def at(self, f):
        x = min(max(float(f), 0.0), 1.0) * self.L
        i = int(np.clip(np.searchsorted(self.s, x) - 1, 0, len(self.P) - 2))
        seg = max(self.s[i + 1] - self.s[i], 1e-300)
        a = (x - self.s[i]) / seg
        return self.P[i] * (1 - a) + self.P[i + 1] * a

    def tangent(self, f, h=1e-3):
        return _unit(self.at(min(f + h, 1.0)) - self.at(max(f - h, 0.0)))


def _affine_edge(e, M3, t3):
    """An edge mapped through an affine map x -> M3 x + t3 (exact: NURBS control points)."""
    n = e.nurbs()
    pts = [tuple(M3 @ _vec(q) + t3) for q in n.points]
    return _call("sweep", _s.Edge.from_nurbs, (n.degree, list(n.knots), pts, None if n.weights is None else list(n.weights)))


def _rail_frame(a, b, tangent, ref_up=None):
    e1 = _unit(b - a)
    t = tangent - e1 * float(np.dot(tangent, e1))
    if float(np.linalg.norm(t)) < 1e-9:
        t = ref_up if ref_up is not None else np.cross(e1, [0.0, 0.0, 1.0])
    e3 = _unit(t)
    e2 = np.cross(e3, e1)
    return np.column_stack([e1, e2, e3])


def sweep_two_rails(profile, rail_a, rail_b, sections: int = 24, scale: str = "UNIFORM", solid: bool = True):
    """A profile (closed or open) swept between two rails it touches: at every step the profile is
    moved and turned so the points where it touched the rails stay on them, and scaled to the
    rails' distance (UNIFORM in every direction, or WIDTH only along the line between the rails).
    The rails are matched by the fraction of their length from where the profile touches them.
    A closed profile gives a solid (solid=True) or a tube."""
    size = max(float(profile.bbox().diagonal), 1e-9)
    edges = _ordered_chain(list(profile.edges()))

    def touch(rail):
        s0, e0 = wire_ends(rail)
        d0 = min(float(np.linalg.norm(_closest(x, s0) - s0)) for x in edges)
        d1 = min(float(np.linalg.norm(_closest(x, e0) - e0)) for x in edges)
        return (d1 < d0), min(d0, d1)

    rev_a, da = touch(rail_a)
    rev_b, db = touch(rail_b)
    tol = max(size, float(rail_a.bbox().diagonal), float(rail_b.bbox().diagonal)) * 1e-4
    if da > tol or db > tol:
        raise CadError("sweep: each rail must start on the profile (an end of each rail on the profile curve)")
    RA, RB = _Polyline(rail_a, rev_a), _Polyline(rail_b, rev_b)
    a0, b0 = RA.at(0.0), RB.at(0.0)
    w0 = float(np.linalg.norm(b0 - a0))
    if w0 < tol:
        raise CadError("sweep: the two rails start at the same point of the profile")
    F0 = _rail_frame(a0, b0, 0.5 * (RA.tangent(0.0) + RB.tangent(0.0)))
    secs = []
    up = F0[:, 2]
    for f in np.linspace(0.0, 1.0, max(int(sections), 3)):
        A, B = RA.at(f), RB.at(f)
        F = _rail_frame(A, B, 0.5 * (RA.tangent(f) + RB.tangent(f)), up)
        up = F[:, 2]
        k = float(np.linalg.norm(B - A)) / w0
        S = np.diag([k, k, k]) if scale == "UNIFORM" else np.diag([k, 1.0, 1.0])
        M3 = F @ S @ F0.T
        t3 = A - M3 @ a0
        secs.append(wire([_affine_edge(e, M3, t3) for e in edges]))
    closed = wire_is_closed(profile)
    if closed and solid:
        faces = [face_from_wires(x) for x in secs]
        return _call("sweep", _s.loft, faces)
    if closed:
        faces = [face_from_wires(x) for x in secs]
        tube = open_caps(_call("sweep", _s.loft, faces), faces)
        return _call("sweep", _s.stitch, tube) if type(tube).__name__ == "Face" else tube
    return _call("sweep", _s.loft, secs)


def fill(boundary, tangent: bool = False):
    """A patch filling a closed loop of curves (G0), or meeting the sheets whose edges they are
    tangentially (G1, tangent=True)."""
    return _call("patch", _s.fill, list(boundary), tangent=tangent)


def loft_rails(sections, rails):
    """A surface through open sections and along rails (guide curves) that cross every section."""
    return _call("loft", _s.loft, list(sections), rails=list(rails))


def edge_chains(edges, tol=None):
    """Edges grouped into chains joined end to end, each ordered head to tail."""
    edges = list(edges)
    if not edges:
        return []
    if tol is None:
        tol = max(max(float(e.bbox().diagonal) for e in edges), 1e-9) * 1e-7
    groups = []
    for e in edges:
        ends = (_vec(e.start), _vec(e.end))
        hit = [g for g in groups if any(float(np.linalg.norm(p - q)) < tol for f in g
                                        for q in (_vec(f.start), _vec(f.end)) for p in ends)]
        merged = [e] + [f for g in hit for f in g]
        groups = [g for g in groups if g not in hit] + [merged]
    return [_ordered_chain(g) for g in groups]


def edge_data(e) -> dict:
    """An edge's exact NURBS data, JSON-ready."""
    n = e.nurbs()
    return {"d": int(n.degree), "k": [float(x) for x in n.knots],
            "p": [[float(c) for c in tuple(q)[:3]] for q in n.points],
            "w": None if n.weights is None else [float(x) for x in n.weights]}


def edge_from_data(d):
    return _call("curve", _s.Edge.from_nurbs, (d["d"], d["k"], d["p"], d["w"]))


def profile_wires(prof):
    """The curves of a profile: a wire as it is; a region (sketch or face) as its outline and holes."""
    if type(prof).__name__ in ("Wire", "Edge"):
        return [prof if type(prof).__name__ == "Wire" else wire([prof])]
    faces = list(prof.faces()) if hasattr(prof, "faces") else [prof]
    out = []
    for f in faces:
        out.append(f.outer_wire())
        out += list(f.inner_wires())
    return out


def planar_loops_face(wires, tol_rel: float = 1e-7):
    """A flat face filling closed curves that lie in one plane (the largest the outline, those inside
    it holes), or None when they are not flat or do not close."""
    edges = [e for w in wires for e in w.edges()]
    pts = np.array([_vec(e.point_at(t)) for e in edges for t in np.linspace(0.0, 1.0, 9)])
    size = max(float(np.ptp(pts, axis=0).max()), 1e-9)
    c = pts.mean(axis=0)
    _u, sv, vt = np.linalg.svd(pts - c)
    n = vt[2]
    if float(np.abs((pts - c) @ n).max()) > size * tol_rel * 10:
        return None
    loops = []
    for ch in edge_chains(edges):
        w = wire(ch)
        if not wire_is_closed(w):
            return None
        loops.append(w)
    loops.sort(key=lambda w: -float(w.bbox().diagonal))
    try:
        region = face_from_wires(loops[0], loops[1:])
        faces = list(region.faces()) if hasattr(region, "faces") else [region]
        return _call("patch", _s.stitch, faces) if len(faces) > 1 else as_sheet(faces[0])
    except Exception:
        return None


def wire_length(w) -> float:
    return float(sum(float(e.length) for e in w.edges()))


def wire_ends(w):
    """(start point, end point) of an open wire (its edges joined head to tail)."""
    edges = _ordered_chain(list(w.edges()))
    return _vec(edges[0].start), _vec(edges[-1].end)


def _ordered_chain(edges):
    """Edges of an open chain, head to tail, each oriented along the walk."""
    if len(edges) <= 1:
        return edges
    tol = max(sum(float(e.length) for e in edges), 1e-9) * 1e-6
    rest = list(edges)
    # start from an edge with a free end
    def touches(p, e):
        return min(np.linalg.norm(p - _vec(e.start)), np.linalg.norm(p - _vec(e.end))) < tol
    start = None
    for e in rest:
        for p, flip in ((_vec(e.start), False), (_vec(e.end), True)):
            if not any(touches(p, f) for f in rest if f is not e):
                start = e.reversed() if flip else e
                break
        if start is not None:
            rest.remove(e)
            break
    if start is None:
        start = rest.pop(0)
    out = [start]
    while rest:
        p = _vec(out[-1].end)
        nxt = None
        for e in rest:
            if np.linalg.norm(p - _vec(e.start)) < tol:
                nxt = e
            elif np.linalg.norm(p - _vec(e.end)) < tol:
                nxt = e.reversed()
            if nxt is not None:
                rest.remove(e)
                break
        if nxt is None:
            break
        out.append(nxt)
    return out


def _wire_samples(w, n: int = 24):
    pts = []
    for e in w.edges():
        for k in range(n + 1):
            pts.append(_vec(e.point_at(k / n)))
    return np.array(pts)


def wire_distance(a, b) -> float:
    """The smallest distance between two wires (sampled on a, exact onto b's edges)."""
    eb = list(b.edges())
    best = float("inf")
    for p in _wire_samples(a):
        for e in eb:
            try:
                best = min(best, float(np.linalg.norm(_closest(e, p) - p)))
            except Exception:   # the kernel's closest point fails now and then on degenerate spots
                continue
    return best


def network_families(wires, tol=None):
    """Split curves into two families where every curve of one meets every curve of the other and
    curves of the same family do not meet (sections and rails of a loft, the sides of a patch), or
    None when they do not form such a network."""
    n = len(wires)
    if n < 3:
        return None
    if tol is None:
        size = max(max(float(w.bbox().diagonal) for w in wires), 1e-9)
        tol = size * 1e-4
    meet = [[False] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            meet[i][j] = meet[j][i] = wire_distance(wires[i], wires[j]) <= tol
    color = [None] * n
    color[0] = 0
    stack = [0]
    while stack:
        i = stack.pop()
        for j in range(n):
            if meet[i][j]:
                if color[j] is None:
                    color[j] = 1 - color[i]
                    stack.append(j)
                elif color[j] == color[i]:
                    return None
    if any(c is None for c in color):
        return None
    A = [i for i in range(n) if color[i] == 0]
    B = [i for i in range(n) if color[i] == 1]
    if not A or not B or any(not meet[i][j] for i in A for j in B):
        return None
    return A, B


def edge_runs(shape, edge_ids, tangent_only: bool = True, angle_deg: float = 1.0):
    """Picked edges as curves: [(wire, face it borders or None)], edges joined where they meet
    (tangentially only, with tangent_only: then the sides of a loop stay apart)."""
    edges = list(shape.edges())
    picked = [edges[i] for i in sorted(set(edge_ids)) if 0 <= i < len(edges)]
    size = max(float(shape.bbox().diagonal), 1e-9)
    tol = 1e-7 * size
    cos_max = math.cos(math.radians(angle_deg))

    def joins(e, f):
        for pe, te in ((_vec(e.start), e.tangent_at(0.0)), (_vec(e.end), e.tangent_at(1.0))):
            for pf, tf in ((_vec(f.start), f.tangent_at(0.0)), (_vec(f.end), f.tangent_at(1.0))):
                if np.linalg.norm(pe - pf) < tol:
                    if not tangent_only:
                        return True
                    if abs(float(np.dot(_unit(te), _unit(tf)))) >= cos_max:
                        return True
        return False

    runs = []
    for e in picked:
        hit = [r for r in runs if any(joins(e, q) for q in r)]
        merged = [e] + [q for r in hit for q in r]
        runs = [r for r in runs if r not in hit] + [merged]
    out = []
    for r in runs:
        w = wire(_ordered_chain(r) if len(r) > 1 else r)
        face = None
        try:
            adj = [list(q.faces()) for q in r]
            if all(len(a) == 1 for a in adj):
                # an open edge of one surface; a run along several surfaces' open edges: all of them
                # (a tuple: what each part of the curve borders is found where it is needed)
                fs = []
                for a in adj:
                    if not any(a[0].is_same(g) if hasattr(a[0], "is_same") else a[0] == g for g in fs):
                        fs.append(a[0])
                face = fs[0] if len(fs) == 1 else tuple(fs)
        except Exception:
            face = None
        out.append((w, face))
    return out


def thicken(shape, thickness: float):
    return _call("thicken", shape.thicken, thickness)


# ----------------------------------------------------------------------------- surfaces: split, trim, stitch

def combine(shapes):
    """One body from several: sheets and faces sewn where they meet (a Part when they close a
    volume, else a Shell, possibly of separate pieces); parts fused."""
    shapes = [x for x in shapes if x is not None]
    if not shapes:
        raise CadError("nothing to combine")
    if len(shapes) == 1:
        return shapes[0]
    if all(isinstance(x, _s.Part) for x in shapes):
        out = shapes[0]
        for x in shapes[1:]:
            out = _call("union", out.fuse, x)
        return out
    return _call("stitch", _s.stitch, *shapes)


def stitch(shapes, tolerance=None):
    """(body, free edges left, widest gap closed): pieces sewn along their common edges."""
    body, rep = _call("stitch", _s.stitch, *shapes, tolerance=tolerance, report=True)
    free = getattr(rep, "open_edges", 0)
    return body, (len(free) if hasattr(free, "__len__") else int(free or 0)), float(getattr(rep, "max_gap", 0.0) or 0.0)


def _edge_key(e, tol):
    m = np.asarray(tuple(e.point_at(0.5))[:3], dtype=float)
    return m, float(e.length)


def face_groups(shell, cut_curves, tol: float = 1e-6):
    """The faces of a sheet in connected pieces: faces sharing an edge belong together unless that
    edge lies on one of the cut curves. Returns [[face, ...], ...]."""
    faces = list(shell.faces())
    n = len(faces)
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    size = max(float(shell.bbox().diagonal), 1e-9)
    tol = max(tol, 1e-7 * size)
    mids = [[_edge_key(e, tol) for e in f.edges()] for f in faces]

    def on_cut(m):
        return any(float(c.distance_to(tuple(m))) <= tol * 10 for c in cut_curves)

    for i in range(n):
        for j in range(i + 1, n):
            for mi, li in mids[i]:
                if any(float(np.linalg.norm(mi - mj)) <= tol * 10 and abs(li - lj) <= tol * 10 for mj, lj in mids[j]):
                    if not on_cut(mi):
                        parent[find(i)] = find(j)
                    break
    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(faces[i])
    return list(groups.values())


def _plane_sheet(origin, normal, size):
    """A square planar sheet (a big rectangle) through origin with the given normal."""
    n = _unit(normal)
    x = np.cross(n, (0, 0, 1) if abs(n[2]) < 0.9 else (1, 0, 0))
    x = x / np.linalg.norm(x)
    y = np.cross(n, x)
    o = np.asarray(origin, dtype=float)
    pts = [o + (sx * x + sy * y) * size for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    return _call("plane sheet", _s.make_face, polyline([tuple(p) for p in pts], True))


def cut_curves(target, cutter, direction=None):
    """Curves along which a cutter crosses a target body: a body's intersection curves, or curves
    (edges / wires) projected onto the target along `direction`."""
    if isinstance(cutter, (_s.Part, _s.Shell)) or type(cutter).__name__ in ("Face", "Sketch"):
        return list(_call("intersection curves", target.intersection_curves, cutter))
    curves = list(cutter) if isinstance(cutter, (list, tuple)) else [cutter]
    out = []
    for c in curves:
        if direction is None:
            out.append(c)
        else:
            out += list(_call("project", target.project, c, tuple(direction)))
    return out


def split_pieces(target, cutter, direction=None):
    """The pieces of a solid or surface cut by a cutter: a solid or surface body, a planar sketch
    region, or curves (projected along `direction` onto a surface; extruded along it through a
    solid). Returns [piece, ...] (Parts or Shells)."""
    size = max(float(target.bbox().diagonal), 1e-9)
    if isinstance(target, _s.Part):
        if isinstance(cutter, _s.Part):
            inside = _call("intersect", target.intersect, cutter)
            outside = _call("cut", target.cut, cutter)
            return [p for x in (outside, inside) for p in _solids(x)]
        if not isinstance(cutter, _s.Shell) and type(cutter).__name__ not in ("Face", "Sketch"):
            # curves, carried along the direction through the whole part: a closed loop cuts out a
            # prism (its inside and the rest), an open curve a sheet
            if direction is None:
                raise CadError("curves need a direction to cut a solid")
            d = _unit(direction) * size * 2
            back = [[1, 0, 0, -d[0]], [0, 1, 0, -d[1]], [0, 0, 1, -d[2]], [0, 0, 0, 1]]
            pieces = [target]
            for c in (cutter if isinstance(cutter, (list, tuple)) else [cutter]):
                w = moved(c if type(c).__name__ == "Wire" else wire([c]), back)
                if wire_is_closed(w):
                    tool = _call("cutting prism", _s.extrude, face_from_wires(w), size * 4,
                                 direction=tuple(_unit(direction)))
                else:
                    tool = _call("cutting sheet", _s.extrude, w, size * 4, direction=tuple(_unit(direction)))
                nxt = []
                for p in pieces:
                    try:
                        nxt += split_pieces(p, tool)
                    except CadError:
                        nxt.append(p)
                pieces = nxt
            return [p for p in pieces if float(p.volume) > 1e-12 * size ** 3]
        res = _call("split", target.split, cutter, keep="both")
        return [p for x in (res if isinstance(res, tuple) else [res]) for p in _solids(x)]
    # a surface: cut along the curves, then the pieces between them
    curves = cut_curves(target, cutter, direction)
    if not curves:
        raise CadError("the cutter does not cross the surface")
    split = _call("trim", target.trim, curves, keep="split")
    groups = face_groups(split, curves)
    return [combine(g) if len(g) > 1 else _call("sheet", _s.stitch, *g) for g in groups]


def _solids(x):
    """A side of a split as one piece (separate lumps on the same side stay one object)."""
    return [x] if x is not None and face_count(x) else []


def split_by_plane_pieces(shape, origin, normal):
    """Pieces of a solid or a surface cut by a plane."""
    if isinstance(shape, _s.Part):
        res = split(shape, origin, normal, "both")
        return [p for x in (res if isinstance(res, tuple) else [res]) for p in _solids(x)]
    size = max(float(shape.bbox().diagonal), 1e-9) * 2
    return split_pieces(shape, _plane_sheet(origin, normal, size))


def replace_face(part, face_id: int, sheet):
    """The part with one face replaced by a surface: the part grows out to the surface (the face is
    carried along its normal past the surface) and is cut back along it. The walls around the face
    run straight on along its normal; the surface must span the face."""
    if not isinstance(part, _s.Part):
        raise CadError("Replace Face: the face must be on a solid")
    faces = list(part.faces())
    if not 0 <= face_id < len(faces):
        raise CadError("Replace Face: pick the face again")
    F = faces[face_id]
    p, n = face_frame(part, face_id)
    p, n = _vec(p), _unit(n)
    size = max(float(part.bbox().diagonal), float(sheet.bbox().diagonal), 1e-9)
    b = sheet.bbox()
    corners = [np.array([x, y, z]) for x in (b.min[0], b.max[0]) for y in (b.min[1], b.max[1])
               for z in (b.min[2], b.max[2])]
    reach = max(float(np.dot(c - p, n)) for c in corners)
    eps = size * 1e-4
    grown = part
    # the part reaches the surface where the face's own points lie below it (seen along the normal)
    try:
        below = any(float(np.dot(_vec(h.point) - q, n)) > 0
                    for q in [_vec(e.point_at(t)) for e in F.edges() for t in (0.0, 0.5)] + [p]
                    for h in sheet.raycast(tuple(q), tuple(n))[:1])
    except Exception:
        below = reach > 0
    if below:
        if not bool(F.is_planar):
            raise CadError("Replace Face: to grow out to a surface the face must be flat (for now); a curved "
                           "face can be cut back to a surface inside the part")
        d = reach + size * 0.05
        ext = _call("replace face", _s.extrude, F, d + eps)
        ext = moved(ext, [[1, 0, 0, -n[0] * eps], [0, 1, 0, -n[1] * eps], [0, 0, 1, -n[2] * eps], [0, 0, 0, 1]])
        grown = _call("replace face", grown.fuse, ext)
    # a point inside the part on its far side from the face
    try:
        hits = [h for h in part.raycast(tuple(p - n * eps), tuple(-n))
                if float(np.linalg.norm(_vec(h.point) - (p - n * eps))) > eps * 3]
        far = _vec(hits[0].point) if hits else p - n * eps * 10
    except Exception:
        far = p - n * eps * 10
    ref = far + n * eps * 5
    try:
        res = _call("replace face", grown.split, sheet, keep="both")
    except CadError as ex:
        raise CadError("Replace Face: the surface must span the face and cut through the part (" +
                       str(ex).split(": ", 1)[-1] + ")")
    pieces = [x for x in (res if isinstance(res, tuple) else [res]) if x is not None and face_count(x)]
    for x in pieces:
        try:
            if x.contains(tuple(ref)):
                return x
        except Exception:
            continue
    raise CadError("Replace Face: the surface cuts away the whole part on this side (does it lie past "
                   "the opposite face?)")


def untrim(shape, face_ids):
    """The body with the given faces replaced by the whole surfaces they lie on (trims removed);
    other faces stay. A sheet results."""
    faces = list(shape.faces())
    ids = set(face_ids) if face_ids else set(range(len(faces)))
    pieces = []
    for i, f in enumerate(faces):
        pieces.append(_call("untrim", f.untrimmed) if i in ids else f)
    return combine(pieces)


def unstitch(shape, face_ids=None):
    """(rest or None, [single-face sheets]): the given faces (default: all) taken out as sheets of
    their own."""
    faces = list(shape.faces())
    ids = set(face_ids) if face_ids else set(range(len(faces)))
    out = [_call("sheet", _s.stitch, f) for i, f in enumerate(faces) if i in ids]
    rest = [f for i, f in enumerate(faces) if i not in ids]
    return (combine(rest) if rest else None), out


# ----------------------------------------------------------------------------- tessellation

QUALITY = {
    # name: (tolerance as fraction of bbox diagonal, max normal angle in degrees)
    "DRAFT": (3e-3, 25.0),
    "NORMAL": (1e-3, 15.0),
    "FINE": (2.5e-4, 7.5),
}


@dataclass
class TessResult:
    vertices: np.ndarray       # (n, 3) float
    triangles: np.ndarray      # (m, 3) int
    corner_normals: np.ndarray | None  # (m, 3, 3) float
    face_ids: np.ndarray       # (m,) int: index into shape.faces()


def _mesher(shape=None):
    """The fast mesher when it is to mesh this body (see mesher.use_for), else None."""
    try:
        from . import mesher
    except Exception:          # loaded on its own (the kernel worker)
        return None
    if not mesher.available():
        return None
    if shape is not None and not mesher.use_for(shape):
        return None
    return mesher


def _count(key: str) -> None:
    try:
        from . import mesher
        mesher.stats[key] = mesher.stats.get(key, 0) + 1
    except Exception:
        pass


def body_size(shape) -> float:
    """The diagonal of the body's (loose, quick) bounding box."""
    try:
        bb = shape._loose_box()
        d = float(np.linalg.norm(np.asarray(tuple(bb.max)[:3]) - np.asarray(tuple(bb.min)[:3])))
        if d > 0 and math.isfinite(d):
            return d
    except Exception:
        pass
    return float(shape.bbox().diagonal)


def mesh_tolerance(shape, quality: str = "NORMAL"):
    frac, angle = QUALITY.get(quality, QUALITY["NORMAL"])
    tol = max(body_size(shape) * frac, 1e-7)
    m = _mesher(shape)
    if m is not None:
        tol = m.quantized_tolerance(tol)
    return tol, angle


# SMLib sometimes rejects one tolerance/angle pair for a body (SM_ERR, seen on macOS) while accepting a
# close one, so a failed tessellation is retried with these (tolerance, angle) factors.
_RETRIES = ((0.5, 1.0), (0.5, 2.0), (2.0, 2.0), (0.7, 1.5), (0.3, 1.0), (3.0, 2.0))


def _kernel_mesh(shape, tol: float, angle: float):
    """The kernel's tessellation of a body, retried with perturbed tolerance and angle when it fails."""
    try:
        return _call("tessellate", _tess_keep, shape, tol, angle, True)
    except CadError as first:
        err = first
    for ft, fa in _RETRIES:
        try:
            mesh = _call("tessellate", _tess_keep, shape, tol * ft, angle * fa, True)
        except CadError:
            continue
        try:
            from . import mesher
            mesher.stats["kernel_retry"] = mesher.stats.get("kernel_retry", 0) + 1
        except Exception:
            pass
        return mesh
    raise err


def _fast_last_resort(shape, tol: float, angle: float):
    """When every kernel attempt failed: the add-on's own mesher, even where it is switched off."""
    try:
        from . import mesher
        if mesher.delaunay_2d_cdt is None:
            return None
        V, T, N, O = mesher.tessellate(shape, tol, angle)
        mesher.stats["kernel_retry"] = mesher.stats.get("kernel_retry", 0) + 1
        return TessResult(V, T, N, O)
    except Exception:
        return None


def tessellate(shape, quality: str = "NORMAL") -> TessResult:
    tol, angle = mesh_tolerance(shape, quality)
    m = _mesher(shape)
    if m is not None:
        try:
            V, T, N, O = m.tessellate(shape, tol, angle)
            _count("bodies_fast")
            return TessResult(V, T, N, O)
        except m.Unsupported as ex:
            m.stats["fallback"] += 1
            m.stats["last_error"] = str(ex)
        except Exception as ex:   # never lose the display over the fast path
            m.stats["fallback"] += 1
            m.stats["last_error"] = f"{type(ex).__name__}: {ex}"
    _count("bodies_kernel")
    try:
        mesh = _kernel_mesh(shape, tol, angle)
    except CadError:
        got = _fast_last_resort(shape, tol, angle) if m is None else None
        if got is None:
            raise
        return got
    try:
        try:
            owners = _triangle_faces(shape, mesh)
        except Exception:
            owners = np.full(len(mesh.triangles), -1, dtype=np.int64)
        verts = np.asarray(mesh.vertices, dtype=np.float64)
        tris = np.asarray(mesh.triangles, dtype=np.int64)
        normals = None if mesh.normals is None else np.asarray(mesh.normals, dtype=np.float64)
    finally:
        try:
            mesh.dispose()
        except Exception:
            pass
    return TessResult(verts, tris, normals, np.asarray(owners, dtype=np.int64))


def edge_polylines(shape, quality: str = "NORMAL") -> list[np.ndarray]:
    """One (k, 3) polyline per edge, in shape.edges() order, for drawing and picking."""
    edges = shape.edges()
    m = _mesher(shape)
    if m is not None:
        tol, angle = mesh_tolerance(shape, quality)
        try:
            return [m.edge_points(e, tol, math.radians(angle)) for e in edges]
        except Exception:
            pass
    diag = body_size(shape) or 1.0
    step = diag * {"DRAFT": 0.03, "NORMAL": 0.012, "FINE": 0.005}.get(quality, 0.012)
    out = []
    for e in edges:
        if str(e.geom_type).lower() == "line":
            n = 2
        else:
            try:
                n = int(min(96, max(8, e.length / step)))
            except Exception:
                n = 24
        pts = np.array([tuple(e.point_at(i / (n - 1))) for i in range(n)], dtype=np.float64)
        out.append(pts)
    return out


# ----------------------------------------------------------------------------- files

def import_step(path: str) -> list:
    got = _call("STEP import", _s.import_step, path)
    if isinstance(got, (list, tuple)) or type(got).__name__ == "ShapeList":
        return list(got)
    return [got]


# ----------------------------------------------------------------------------- boundary fill

def boundary_fill(shapes, merge: str = "ALL", timeout: float = 180.0):
    """The solid volumes enclosed by intersecting surfaces (Rhino's CreateSolid / BoundaryFill).

    A box around everything is cut into pieces along every face of the given sheets (and parts),
    each face extended as the kernel extends it to cut through a piece, but only pieces the face
    itself passes through are cut. Two pieces are one region where they meet across anything but
    a real face (where they meet across an extension, or past the end of a face); the regions
    that do not reach the box are the enclosed volumes. merge: "ALL" joins every enclosed volume
    (walls inside it vanish), "REGIONS" keeps volumes parted by a surface apart, "CELLS" gives
    every piece on its own. Returns a list of solids, the largest first."""
    import time as _time
    faces = []
    for sh in shapes:
        for f in sh.faces():
            try:
                faces.append(f.to_shell())
            except Exception:
                continue
    if len(faces) < 2:
        raise CadError("boundary fill: select surfaces (or parts) that close around a volume together")
    boxes = [f.bbox() for f in faces]
    lo = np.min([_vec(b.min) for b in boxes], axis=0)
    hi = np.max([_vec(b.max) for b in boxes], axis=0)
    size = float(np.linalg.norm(hi - lo))
    if size <= 0:
        raise CadError("boundary fill: the surfaces have no extent")
    pad = 0.1 * size
    lo_b, hi_b = lo - pad, hi + pad
    box_ = _s.Box(*map(float, hi_b - lo_b)).translate(tuple(0.5 * (lo_b + hi_b)))
    tol = size * 1e-6
    t_end = _time.time() + timeout

    def late():
        if _time.time() > t_end:
            raise CadError(f"boundary fill: taking too long (more than {timeout:.0f} s); try fewer or "
                           "simpler surfaces")

    # ---- first by the sheets' own faces (fused, tails dropped, cells walked round)
    try:
        own = _sheet_cells(faces, size, late)
    except CadError:
        raise
    except Exception:
        own = None
    if own and own[0]:
        cells, skin = own
        if merge == "ALL" and skin is not None:
            return sorted(list(skin.solids()) if hasattr(skin, "solids") else [skin], key=lambda p: -float(p.volume))
        return _fill_result(cells, merge)
    # ---- else a box around everything cut along the faces (grown to cut through): the cutters,
    # each face grown past the box (the kernel grows planes, cylinders and the
    # like itself when it splits, but a free-form face only a little: it goes on along its tangents)
    cutters = []
    for f in faces:
        cut = f
        try:
            g = f.faces()[0]
            if str(g.geom_type).lower() not in ("plane", "cylinder", "cone", "sphere", "torus"):
                for how in ("G1", "natural"):
                    try:
                        cut = g.extend(float(size * 1.5), continuity=how)
                        break
                    except Exception:
                        continue
        except Exception:
            cut = f
        cutters.append(cut)
    # ---- the pieces
    cells = [box_]
    for k, f in enumerate(faces):
        fl, fh = _vec(boxes[k].min) - tol, _vec(boxes[k].max) + tol
        smp = _sheet_samples(f, tol * 10)
        out = []
        for c in cells:
            late()
            cb = c.bbox()
            if np.any(fh < _vec(cb.min)) or np.any(fl > _vec(cb.max)):
                out.append(c)
                continue
            got = _fill_split(c, cutters[k], tol, smp if len(smp) else None)
            if got is None and cutters[k] is not f:
                got = _fill_split(c, f, tol, smp if len(smp) else None)
            out += got if got is not None else [c]
        cells = out
    # ---- regions: pieces joined across everything but the real faces
    parent = list(range(len(cells) + 1))          # the last one: outside
    OUT = len(cells)

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(i, j):
        a, b = find(i), find(j)
        if a != b:
            parent[max(a, b)] = min(a, b) if min(a, b) != OUT and max(a, b) != OUT else OUT
            if OUT in (a, b):
                parent[a] = OUT
                parent[b] = OUT

    cboxes = [(_vec(c.bbox().min) - tol * 10, _vec(c.bbox().max) + tol * 10) for c in cells]
    eps = size * 1e-5
    for i, c in enumerate(cells):
        late()
        Q = []                                         # just outside this piece, past no real face
        for f in c.faces():
            for p in _face_samples(f):
                try:
                    n = _unit(_vec(f.normal_at(tuple(p))))
                except Exception:
                    continue
                if min(float(sh.distance_to(tuple(p))) for sh in faces) <= tol * 10:
                    continue                                   # a real face: a wall
                Q.append(p + eps * n)
        if not Q:
            continue
        Q = np.array(Q)
        left = np.ones(len(Q), dtype=bool)
        for j, (bl, bh) in enumerate(cboxes):
            if j == i:
                continue
            near = left & np.all(Q >= bl, axis=1) & np.all(Q <= bh, axis=1)
            if not near.any():
                continue
            idx = np.nonzero(near)[0]
            try:
                res = cells[j]._classify([tuple(q) for q in Q[idx]])
                hit = [k for k, r in zip(idx, res) if r[0] != "outside"]
            except Exception:
                hit = [k for k in idx if bool(cells[j].contains(tuple(Q[k])))]
            if hit:
                union(i, j)
                left[hit] = False
        if left.any():
            union(i, OUT)
    groups = {}
    for i in range(len(cells)):
        r = find(i)
        if r != OUT:
            groups.setdefault(r, []).append(cells[i])
    if not groups:
        raise CadError("boundary fill: the surfaces enclose no volume (they must close all round, "
                       "crossing or meeting each other, with no gaps)")
    if merge == "ALL":
        groups = {0: [c for g in groups.values() for c in g]}
    out = []
    for members in groups.values():
        out += _fill_result(members, "CELLS" if merge == "CELLS" else "ALL")
    out.sort(key=lambda p: -float(p.volume))
    return out


def _fill_result(cells, merge):
    """Cells as the result: joined into one (ALL), else each on its own (cells parted by a real
    surface are the regions); the largest first."""
    out = list(cells)
    if merge == "ALL" and len(out) > 1:
        total = sum(float(c.volume) for c in out)
        for _attempt in range(2):         # (checked: the kernel's union of cells sharing faces can go wrong)
            try:
                joined = _call("boundary fill", out[0].fuse, *out[1:])
                if abs(float(joined.volume) - total) <= total * 1e-4:
                    out = list(joined.solids()) if hasattr(joined, "solids") else [joined]
                    break
            except CadError:
                pass
    out.sort(key=lambda p: -float(p.volume))
    return out


def _sheet_cells(sheets, size, late=lambda: None):
    """The closed cells that sheets enclose, by their own faces (no extension): the sheets are
    fused (each face split where another crosses it), pieces with a free edge are dropped (over
    and over: the tails that run past the volume), and the rest are walked round each edge, a
    side of a face to the next face turning that way, into the shells of the cells. Each bounded
    shell is sewn into a solid. None when the sheets cannot be fused."""
    try:
        F = sheets[0].fuse(*sheets[1:]) if len(sheets) > 1 else sheets[0]
    except Exception:
        return None
    faces = list(F.faces())
    if not faces:
        return [], None
    index = {f: i for i, f in enumerate(faces)}
    edges = []
    for e in F.edges():
        try:
            fi = sorted({index[g] for g in e.faces() if g in index})
        except Exception:
            return None
        edges.append((e, fi))
    alive = set(range(len(faces)))
    while True:                                      # drop the tails
        late()
        count = {}
        for e, fi in edges:
            k = [i for i in fi if i in alive]
            for i in k:
                count[i] = min(count.get(i, 99), len(k))
        dead = {i for i in alive if count.get(i, 0) < 2}
        if not dead:
            break
        alive -= dead
    if not alive:
        return [], None
    eps = size * 1e-4
    parent = {}

    def find(x):
        parent.setdefault(x, x)
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for e, fi in edges:
        late()
        k = [i for i in fi if i in alive]
        if len(k) < 2:
            continue
        P = _fast_points(e, [0.45, 0.5, 0.55])
        m = P[1]
        tg = _unit(P[2] - P[0])
        a = _unit(np.cross(tg, [1.0, 0.0, 0.0]) if abs(tg[0]) < 0.9 else np.cross(tg, [0.0, 1.0, 0.0]))
        b = np.cross(tg, a)
        ring = []
        for i in k:
            f = faces[i]
            n = _unit(_vec(f.normal_at(tuple(m))))
            d = _unit(np.cross(tg, n))
            if float(f.distance_to(tuple(m + eps * d))) > float(f.distance_to(tuple(m - eps * d))):
                d = -d                                 # into the face
            th = math.atan2(float(np.dot(d, b)), float(np.dot(d, a)))
            sg = 1 if float(np.dot(n, np.cross(tg, d))) > 0 else -1   # the side facing the turn
            ring.append((th, i, sg))
        ring.sort()
        L = len(ring)
        for r, (th, i, sg) in enumerate(ring):
            nxt = ring[(r + 1) % L]                    # turning on from face i's side sg
            union((i, sg), (nxt[1], -nxt[2]))
    shells = {}
    for i in alive:
        for sd in (1, -1):
            shells.setdefault(find((i, sd)), []).append((i, sd))
    cells = []
    bounded = set()
    for root, members in shells.items():
        late()
        ids = sorted({i for i, _sd in members})
        if len(ids) != len(members):
            continue                                   # both sides of a face: not a closed cell
        # bounded or the outside: the volume the sides enclose (positive for a bounded cell)
        vol = 0.0
        for i, sd in members:
            f = faces[i]
            try:
                msh = f.mesh()
                V = np.asarray(msh.vertices, dtype=float)
                T = np.asarray(msh.triangles, dtype=int)
            except Exception:
                continue
            if not len(T):
                continue
            c0 = V[T].mean(axis=1)
            nrm = np.cross(V[T[:, 1]] - V[T[:, 0]], V[T[:, 2]] - V[T[:, 0]])
            n_face = _vec(f.normal_at(tuple(c0[0])))
            flip = 1.0 if float(np.dot(nrm[0], n_face)) >= 0 else -1.0
            # the cell lies on side sd of the face: its outward normal is -sd * n
            vol += float(np.einsum("ij,ij->", c0, nrm)) * flip * (-sd) / 6.0
        if vol <= 0:
            continue
        sol = None
        # (the faces come from one fused body, so they meet exactly; the default sewing can still
        # leave one of two edges between the same faces unsewn: a little more tolerance closes it)
        for tol in (None, size * 5e-4):
            try:
                sol = _s.stitch([faces[i] for i in ids]) if tol is None else _s.stitch([faces[i] for i in ids], tolerance=tol)
            except Exception:
                sol = None
            if isinstance(sol, _s.Part):
                break
        if isinstance(sol, _s.Part) and float(sol.volume) > 0:
            cells.append(sol)
            bounded.add(root)
    # the outer skin of all the cells together: the faces with a cell on one side only (the
    # walls between two cells drop out), sewn into one body: no Boolean of cells that share faces
    skin = None
    if len(cells) > 1:
        outer = [faces[i] for i in alive if (find((i, 1)) in bounded) != (find((i, -1)) in bounded)]
        try:
            got = _s.stitch(outer)
            if isinstance(got, _s.Part):
                total = sum(float(c.volume) for c in cells)
                if abs(float(got.volume) - total) <= total * 1e-4:
                    skin = got
        except Exception:
            skin = None
    elif cells:
        skin = cells[0]
    return cells, skin


def _face_samples(f, most: int = 12):
    """A few points spread over a face, on it: a point inside it and points from there towards the
    middle of each of its edges."""
    pts = []
    try:
        ip = f.interior_point()
        ip = _vec(getattr(ip, "point", ip))
    except Exception:
        return pts
    pts.append(ip)
    for e in list(f.edges())[:most]:
        try:
            m = _fast_points(e, [0.5])[0]
            pts.append(_closest(f, ip + 0.6 * (m - ip)))
        except Exception:
            continue
    return pts


def _sheet_samples(sheet, tol, n: int = 14):
    """Points spread over a sheet's face (within its trim)."""
    pts = []
    for f in sheet.faces():
        for u in np.linspace(0.02, 0.98, n):
            for v in np.linspace(0.02, 0.98, n):
                try:
                    p = _vec(f.position_at(float(u), float(v)))
                    if float(f.distance_to(tuple(p))) <= tol:
                        pts.append(p)
                except Exception:
                    continue
    return np.array(pts) if pts else np.zeros((0, 3))


def _strictly_inside(part, pts) -> bool:
    """Any of the points in the part's material (not on its surface)."""
    if len(pts) == 0:
        return False
    try:
        return any(r[0] == "inside" for r in part._classify([tuple(p) for p in pts]))
    except Exception:
        return any(part.classify(tuple(p))[0] == "inside" for p in pts)


def _fill_split(cell, sheet, tol, samples=None):
    """The pieces of a cell cut along a one-face sheet (extended to cut through as the kernel
    extends it), or None when the sheet itself does not pass through the cell or the cut fails."""
    import warnings
    if samples is not None:
        cb = cell.bbox()
        lo_, hi_ = _vec(cb.min), _vec(cb.max)
        near = samples[np.all(samples >= lo_, axis=1) & np.all(samples <= hi_, axis=1)]
        if not _strictly_inside(cell, near):
            return None
    else:
        try:
            inside = sheet.intersect(cell)
            if inside is None or not inside.faces() or float(inside.area) <= tol * tol * 1e3:
                return None
        except Exception:
            return None
    vc = None
    for _attempt in range(2):            # (the kernel's cuts do not always come out the same: once more)
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                got = cell.split(sheet, keep="both")
                if not isinstance(got, tuple) or len(got) != 2:
                    continue
                vc = float(cell.volume) if vc is None else vc
                pieces = []
                for p in got:
                    for q in (list(p.solids()) if hasattr(p, "solids") else [p]) or [p]:
                        if float(q.volume) > vc * 1e-9:
                            pieces.append(q)
            if len(pieces) >= 2 and abs(sum(float(q.volume) for q in pieces) - vc) <= vc * 1e-4:
                return pieces
        except Exception:
            continue
    return None


# ----------------------------------------------------------------------------- patches meeting surfaces G0 / G1 / G2

def _basis_ders(knots, p: int, n: int, us, nd: int = 2) -> np.ndarray:
    """(nd + 1, len(us), n): the B-spline basis functions of degree p and their first nd
    derivatives at each parameter (Piegl & Tiller A2.3)."""
    k = np.asarray(knots, dtype=float)
    out = np.zeros((nd + 1, len(us), n))
    lo, hi = k[p], k[n]
    for r, u in enumerate(us):
        u = min(max(float(u), lo), hi)
        span = p
        while span < n - 1 and k[span + 1] <= u:
            span += 1
        ndu = np.zeros((p + 1, p + 1))
        ndu[0, 0] = 1.0
        left, right = np.zeros(p + 1), np.zeros(p + 1)
        for j in range(1, p + 1):
            left[j] = u - k[span + 1 - j]
            right[j] = k[span + j] - u
            saved = 0.0
            for q in range(j):
                ndu[j, q] = right[q + 1] + left[j - q]
                tmp = ndu[q, j - 1] / ndu[j, q] if ndu[j, q] != 0 else 0.0
                ndu[q, j] = saved + right[q + 1] * tmp
                saved = left[j - q] * tmp
            ndu[j, j] = saved
        ders = np.zeros((nd + 1, p + 1))
        ders[0] = ndu[:, p]
        a = np.zeros((2, p + 1))
        for q in range(p + 1):
            s1, s2 = 0, 1
            a[0, 0] = 1.0
            for kk in range(1, nd + 1):
                d = 0.0
                rk, pk = q - kk, p - kk
                if q >= kk:
                    a[s2, 0] = a[s1, 0] / ndu[pk + 1, rk] if ndu[pk + 1, rk] != 0 else 0.0
                    d = a[s2, 0] * ndu[rk, pk]
                j1 = 1 if rk >= -1 else -rk
                j2 = kk - 1 if q - 1 <= pk else p - q
                for j in range(j1, j2 + 1):
                    den = ndu[pk + 1, rk + j]
                    a[s2, j] = (a[s1, j] - a[s1, j - 1]) / den if den != 0 else 0.0
                    d += a[s2, j] * ndu[rk + j, pk]
                if q <= pk:
                    den = ndu[pk + 1, q]
                    a[s2, kk] = -a[s1, kk - 1] / den if den != 0 else 0.0
                    d += a[s2, kk] * ndu[q, pk]
                ders[kk, q] = d
                s1, s2 = s2, s1
        fac = p
        for kk in range(1, nd + 1):
            ders[kk] *= fac
            fac *= p - kk
        out[:, r, span - p:span + 1] = ders
    return out


def _chain_points(items, m: int):
    """Points (m, 3) at even lengths along a chain of edges (each (edge, reversed)), and for each the
    edge it lies on."""
    lens = [max(float(e.length), 1e-300) for e, _r in items]
    total = sum(lens)
    out, owner = [], []
    for k in range(m):
        s_ = total * k / (m - 1)
        acc = 0.0
        for j, ((e, rev), L) in enumerate(zip(items, lens)):
            if s_ <= acc + L + 1e-15 or j == len(items) - 1:
                t = min(max((s_ - acc) / L, 0.0), 1.0)
                out.append(_vec(e.point_at(1.0 - t if rev else t)))
                owner.append(j)
                break
            acc += L
    return np.array(out), owner


def _loop_sides(items, size):
    """A closed loop of (edge, face | None) as its sides between corners: [[(edge, reversed, face)]]
    in order round the loop."""
    tol = size * 1e-6
    left = list(items)
    if not left:
        return None
    e0, f0 = left.pop(0)
    loop = [(e0, False, f0)]
    while left:
        end = _vec(loop[-1][0].start if loop[-1][1] else loop[-1][0].end)
        k = next((i for i, (e, _f) in enumerate(left) if float(np.linalg.norm(_vec(e.start) - end)) < tol * 100
                  or float(np.linalg.norm(_vec(e.end) - end)) < tol * 100), None)
        if k is None:
            return None
        e, f = left.pop(k)
        rev = float(np.linalg.norm(_vec(e.end) - end)) < float(np.linalg.norm(_vec(e.start) - end))
        loop.append((e, rev, f))

    def tangent(item, at_end):
        e, rev, _f = item
        t = (1.0 if not rev else 0.0) if at_end else (0.0 if not rev else 1.0)
        h = 1e-3 if t < 0.5 else -1e-3
        a, b = _vec(e.point_at(t)), _vec(e.point_at(t + h))
        d = _unit(b - a) * (1 if h > 0 else -1)
        return d if not rev else -d

    corners = []
    n = len(loop)
    for i in range(n):
        a, b = tangent(loop[i], True), tangent(loop[(i + 1) % n], False)
        if float(np.dot(a, b)) < math.cos(math.radians(20.0)):
            corners.append((i + 1) % n)
    if len(corners) < 3:
        return None
    sides = []
    for j, c in enumerate(corners):
        nxt = corners[(j + 1) % len(corners)]
        side, i = [], c
        while True:
            side.append(loop[i])
            i = (i + 1) % n
            if i == nxt:
                break
        sides.append(side)
    return sides


_PATCH_W = {}


def _coons_of(B, R_, T_, L_, ts):
    """The bilinear Coons patch of four border polylines sampled at ts (B, T along u; L, R along v)."""
    c00, c10, c11, c01 = B[0], B[-1], T_[-1], T_[0]

    def coons(u, v):
        b = np.array([np.interp(u, ts, B[:, j]) for j in range(3)])
        t_ = np.array([np.interp(u, ts, T_[:, j]) for j in range(3)])
        l_ = np.array([np.interp(v, ts, L_[:, j]) for j in range(3)])
        r_ = np.array([np.interp(v, ts, R_[:, j]) for j in range(3)])
        return ((1 - v) * b + v * t_ + (1 - u) * l_ + u * r_
                - ((1 - u) * (1 - v) * c00 + u * (1 - v) * c10 + u * v * c11 + (1 - u) * v * c01))
    return coons


def _net_folds(P, kv, p: int = 5, n: int = 41) -> float:
    """The least cosine between the normals of neighbouring points of a grid over a B-spline net
    (below 0: the surface folds over somewhere)."""
    us = np.linspace(0.0, 1.0, n)
    D = _basis_ders(kv, p, P.shape[0], us, 1)
    Su = np.einsum("ai,bj,ijk->abk", D[1], D[0], P)
    Sv = np.einsum("ai,bj,ijk->abk", D[0], D[1], P)
    Nn = np.cross(Su, Sv)
    U = Nn / np.maximum(np.linalg.norm(Nn, axis=2)[..., None], 1e-300)
    return float(min((U[1:] * U[:-1]).sum(-1).min(), (U[:, 1:] * U[:, :-1]).sum(-1).min()))


def _onto_face(face, q, d, size, cache) -> bool:
    """Whether direction d (in the face's tangent plane at q, a point of its edge) leads onto the
    face rather than off it past the edge. The face's mesh decides: the triangles nearest q lie on
    the face's side (a face's distance_to does not always see its trim)."""
    key = id(face)
    if key not in cache:
        try:
            msh = face.mesh()
            V = np.asarray(msh.vertices, dtype=float)
            T = np.asarray(msh.triangles, dtype=int)
            cache[key] = (V[T].mean(axis=1), face)
        except Exception:
            cache[key] = (np.zeros((0, 3)), face)
    C = cache[key][0]
    if len(C):
        dist = np.linalg.norm(C - q, axis=1)
        near = np.argsort(dist)[:6]
        s = float(np.mean((C[near] - q) @ d))
        if abs(s) > 1e-12 * size:
            return s > 0
    eps = size * 1e-4
    return float(face.distance_to(tuple(q + eps * d))) < float(face.distance_to(tuple(q - eps * d)))


def matched_patch(items, level: str = "G1", spans=None, corner_band=None, base=None, extra=()):
    """A four-sided patch meeting the surfaces along its curves G0 / G1 / G2 (see _matched_patch):
    a few net sizes and corner bands tried, the best kept (a clean net first, then the smallest
    angle to the surfaces, then the closest curvature)."""
    if spans is not None or corner_band is not None:
        return _matched_patch(items, level, spans or 6, corner_band if corner_band is not None else 0.08, base, extra)
    best = None
    for sp, cb in ((6, 0.1), (8, 0.2), (6, 0.04), (8, 0.04), (10, 0.1)):
        try:
            got = _matched_patch(items, level, sp, cb, base, extra)
        except Exception:
            continue
        if got is None:
            return None
        sheet, info = got
        try:
            clean = not sheet.check() and _net_folds(*info["_net"]) > 0.5
        except Exception:
            clean = False
        score = (0 if clean else 1, round(info["angle"], 2), info["curvature"])
        if best is None or score < best[0]:
            best = (score, got)
        if clean and info["angle"] < 0.1 and info["curvature"] < 0.02:
            break
    if best is None:
        raise CadError("patch: the surface could not be fitted to the curves")
    return best[1]


def _matched_patch(items, level: str = "G1", spans: int = 6, corner_band: float = 0.08, base=None, extra=()):
    """A four-sided patch through a closed loop of curves meeting the surfaces whose open edges the
    loop runs along G0 (through the edges), G1 (tangent) or G2 (also the same curvature across).

    items: [(edge or wire, face it borders or None)]. One untrimmed NURBS face of degree 5 x 5: its
    border rows lie on the curves; along a surface's edge its next row keeps it tangent to the
    surface (G1), the row after gives it the surface's curvature across the edge (G2). Solved by
    least squares with the rest of the net kept smooth (bending energy) and near a Coons patch of
    the curves; where two sides meet the conditions of both are met as nearly as they can be.
    Returns (sheet, {"angle": largest angle to a surface in degrees, "curvature": largest relative
    curvature mismatch}). None when the loop does not make four sides.

    base: instead of the loop's Coons patch, a surface to start from and keep near ((u, v) in 0..1 ->
    point; its borders lie on the curves of items, which then need not be in order): a network
    surface. extra: [(u, v, point)] further points the patch must pass through (its inner curves)."""
    level = str(level).upper()
    edges = []
    for w, f in items:
        for e in (w.edges() if hasattr(w, "edges") else [w]):
            if isinstance(f, (tuple, list)):            # a run along several surfaces: the one it borders
                m = _fast_points(e, [0.5])[0]
                f_e = min(f, key=lambda g: float(g.distance_to(tuple(m))))
            else:
                f_e = f
            edges.append((e, f_e))
    size = max(max(float(e.bbox().diagonal) for e, _f in edges), 1e-12)
    if base is None:
        sides = _loop_sides(edges, size)
        if sides is None or len(sides) != 4:
            return None
    p = 5
    nu = nv = spans + p
    kv = [0.0] * (p + 1) + [k / spans for k in range(1, spans)] + [1.0] * (p + 1)
    M = 4 * spans + 1
    ts = np.linspace(0.0, 1.0, M)
    # boundary points: bottom (v=0) side 0, right (u=1) side 1, top (v=1) side 2 reversed, left side 3 reversed
    if base is not None:
        B = np.array([_vec(base(t, 0.0)) for t in ts])
        R_ = np.array([_vec(base(1.0, t)) for t in ts])
        T_ = np.array([_vec(base(t, 1.0)) for t in ts])
        L_ = np.array([_vec(base(0.0, t)) for t in ts])
        tol = size * 1e-4
        with_face = [(e, f) for e, f in edges if f is not None]

        def face_at(si, k):
            q = [B, R_, T_, L_][si][k]
            best = None
            for e, f in with_face:
                dd = float(e.distance_to(tuple(q)))
                if dd < tol and (best is None or dd < best[0]):
                    best = (dd, f)
            return best[1] if best else None

        def coons(u, v):
            return _vec(base(u, v))
    else:
        pts, owners = [], []
        for side in sides:
            P_, own = _chain_points([(e, r) for e, r, _f in side], M)
            pts.append(P_)
            owners.append(own)
        B, R_, T_, L_ = pts[0], pts[1], pts[2][::-1], pts[3][::-1]

        def face_at(si, k):
            own = owners[si] if si < 2 else owners[si][::-1]
            side = sides[si]
            return (side[own[k]] if own[k] < len(side) else side[-1])[2]

        coons = _coons_of(B, R_, T_, L_, ts)

    N = nu * nv
    rows, rhs, wts = [], [], []

    def add(coef, val, w):
        # coef: (N,) weights of the CVs applied to all three coordinates (val (3,)), or
        # ("dot", coefs (N,), n (3,)) for a scalar condition on the dot with n
        rows.append(coef)
        rhs.append(val)
        wts.append(w)

    Du = _basis_ders(kv, p, nu, ts, 2)
    Dv = Du                                         # (same knots both ways)
    side_spec = []                                  # (side index, fixed param, along-axis, sign into the patch)
    side_spec.append((0, "v", 0.0, 1.0))
    side_spec.append((1, "u", 1.0, -1.0))
    side_spec.append((2, "v", 1.0, -1.0))
    side_spec.append((3, "u", 0.0, 1.0))
    i_end = {0.0: 0, 1.0: M - 1}
    W_POS, W_G, W_MAG, W_SMOOTH, W_COONS = 1e3, 1e3, 3.0, 1.0, 1e-2
    targets = []
    cents = {}
    for si, axis, fixed, sgn in side_spec:
        boundary = [B, R_, T_, L_][si]
        for k, t in enumerate(ts):
            # basis rows at the boundary point: value, first and second derivative across
            if axis == "v":
                bu = Du[0, k]
                bv0, bv1, bv2 = Dv[0, i_end[fixed]], Dv[1, i_end[fixed]], Dv[2, i_end[fixed]]
                val = np.outer(bu, bv0).ravel()
                d1 = np.outer(bu, bv1).ravel() * sgn
                d2 = np.outer(bu, bv2).ravel()
                along = np.outer(Du[1, k], bv0).ravel()
            else:
                bv = Dv[0, k]
                bu0, bu1, bu2 = Du[0, i_end[fixed]], Du[1, i_end[fixed]], Du[2, i_end[fixed]]
                val = np.outer(bu0, bv).ravel()
                d1 = np.outer(bu1, bv).ravel() * sgn
                d2 = np.outer(bu2, bv).ravel()
                along = np.outer(bu0, Dv[1, k]).ravel()
            q = boundary[k]
            targets.append((val, q))
            face = face_at(si, k)
            if face is None or level == "G0" or k in (0, M - 1):
                continue
            taper = min(t, 1.0 - t) / corner_band          # 0 at a corner, 1 away from it
            if taper < 1e-9:
                continue
            try:
                n = _unit(_vec(face.normal_at(tuple(q))))
                # the boundary's tangent here, the surface's direction across it into the hole
                q2 = boundary[min(k + 1, M - 1)] - boundary[max(k - 1, 0)]
                tng = _unit(q2)
                d = _unit(np.cross(n, tng))
                if _onto_face(face, q, d, size, cents):
                    d = -d
                kap = 0.0
                if level in ("G1", "G2"):
                    c = face.curvature_at(tuple(q))
                    d1v, d2v = _unit(_vec(c.dir1)), _unit(_vec(c.dir2))
                    kap = float(c.k1) * float(np.dot(d, d1v)) ** 2 + float(c.k2) * float(np.dot(d, d2v)) ** 2
                    if float(np.dot(_unit(_vec(c.normal)), n)) < 0:
                        kap = -kap
            except Exception:
                continue
            side_spec_k = (val, d1, d2, n, d, kap, min(1.0, taper), along)
            targets[-1] = (val, q, side_spec_k)
    # the speed across, to start with: the Coons patch's of the curves
    mag0 = []
    h = 1e-3
    for si, axis, fixed, sgn in side_spec:
        for t in ts:
            if axis == "v":
                a_, b_ = coons(t, fixed), coons(t, fixed + sgn * h)
            else:
                a_, b_ = coons(fixed, t), coons(fixed + sgn * h, t)
            mag0.append(max(float(np.linalg.norm(b_ - a_)) / h, size * 1e-3))
    grid = np.linspace(0, 1, nu + 4)
    extra_rows = []
    for xu_, xv_, xq in extra:
        # (eased off near the border: an inner curve that does not leave a surface's edge in its
        # tangent plane cannot be met there as well as the surface; the surface wins)
        edge_d = min(float(xu_), 1.0 - float(xu_), float(xv_), 1.0 - float(xv_))
        xw = _PATCH_W.get("extra", 3.0) * min(1.0, edge_d / 0.2) ** 2 if level != "G0" else 3.0
        extra_rows.append((_basis_ders(kv, p, nu, [float(xu_)], 0)[0][0], _basis_ders(kv, p, nu, [float(xv_)], 0)[0][0],
                           _vec(xq), xw))
    prev = None
    # G1: the curvature across eased towards the surfaces' too (softly: without it the patch bends
    # hard just inside its edges), G2: held to it
    W_K = W_G if level == "G2" else W_G * _PATCH_W.get("g1k", 0.001)
    for stage in ((1, 2) if level in ("G1", "G2") else (1,)):
        rows, rhs, wts = [], [], []
        for tgt in targets:
            val, q = tgt[0], tgt[1]
            rows.append(("vec", val))
            rhs.append(q)
            wts.append(W_POS)
        for xu, xv, xq, xw in extra_rows:
            rows.append(("vec", np.outer(xu, xv).ravel()))
            rhs.append(xq)
            wts.append(W_POS * xw)
        for idx, tgt in enumerate(targets):
            if len(tgt) < 3:
                continue
            val, q, (vrow, d1, d2, n, d, kap, wt, _al) = tgt
            if stage == 1:
                # G1: no part of the derivative across along the surface's normal; its length near the
                # Coons patch's (soft: where two sides meet, the curves have the last word)
                rows.append(("dot", d1, n))
                rhs.append(0.0)
                wts.append(W_G * wt)
                rows.append(("vec", d1))
                rhs.append(mag0[idx] * d)
                wts.append(W_MAG * wt)
            else:
                # G2: the derivative across kept as the G1 solve made it, so the curvature across is
                # set exactly by the second derivative's part along the normal
                s1 = d1 @ prev
                rows.append(("vec", d1))
                rhs.append(s1)
                wts.append(W_G * wt)
                rows.append(("dot", d2, n))
                rhs.append(-kap * float(np.dot(s1, s1)))
                wts.append(W_K * wt)
        # smooth: second differences of the net, and close to the Coons patch
        def cvi(i, j):
            return i * nv + j
        for i in range(nu):
            for j in range(nv):
                for (a_, b_, c_) in (((i - 1, j), (i, j), (i + 1, j)), ((i, j - 1), (i, j), (i, j + 1))):
                    if min(a_[0], c_[0], a_[1], c_[1]) < 0 or max(a_[0], c_[0]) >= nu or max(a_[1], c_[1]) >= nv:
                        continue
                    r = np.zeros(N)
                    r[cvi(*a_)] += 1
                    r[cvi(*b_)] -= 2
                    r[cvi(*c_)] += 1
                    rows.append(("vec", r))
                    rhs.append(np.zeros(3))
                    wts.append(W_SMOOTH)
        G = _basis_ders(kv, p, nu, grid, 0)[0]
        for a_i, u in enumerate(grid):
            for b_i, v in enumerate(grid):
                rows.append(("vec", np.outer(G[a_i], G[b_i]).ravel()))
                rhs.append(coons(u, v) if prev is None else coons(u, v))
                wts.append(W_COONS)
        # assemble: unknowns X (N, 3) flattened as 3N
        A, y = [], []
        for (kind, *data), r, w in zip(rows, rhs, wts):
            if kind == "vec":
                coef = data[0]
                for j in range(3):
                    row = np.zeros(3 * N)
                    row[j::3] = coef * w
                    A.append(row)
                    y.append(float(r[j]) * w)
            else:
                coef, n = data
                row = np.zeros(3 * N)
                for j in range(3):
                    row[j::3] = coef * n[j] * w
                A.append(row)
                y.append(float(r) * w)
        X = np.linalg.lstsq(np.array(A), np.array(y), rcond=None)[0].reshape(N, 3)
        prev = X
    P = X.reshape(nu, nv, 3)
    sheet = _call("patch", _s.Shell.from_nurbs, ((p, p), (kv, kv), [[tuple(map(float, c)) for c in row] for row in P], None))
    # how well it meets the surfaces: its normal from its derivatives along and across each side
    worst_a, worst_k = 0.0, 0.0
    for tgt in targets:
        if len(tgt) < 3:
            continue
        val, q, (vrow, d1, d2, n, d, kap, wt, al) = tgt
        if wt < 0.5:
            continue                                    # (near a corner: the curves decide there)
        sa, sc = al @ X, d1 @ X
        nn = np.cross(sa, sc)
        ln = float(np.linalg.norm(nn))
        if ln <= 0:
            worst_a = 90.0
            continue
        worst_a = max(worst_a, math.degrees(math.acos(min(1.0, abs(float(np.dot(nn / ln, n)))))))
        if level == "G2":
            got = float((d2 @ X) @ n) / max(float(np.dot(sc, sc)), 1e-300)
            ref = max(abs(kap), 1.0 / size)
            worst_k = max(worst_k, abs(got + kap) / ref)
    return sheet, {"angle": worst_a, "curvature": worst_k, "_net": (P, kv)}


# ============================================================================= mesh to part

def _mesh_clean(V, polys, size):
    """Vertices merged by distance, polygons on them without repeated corners; a polygon that is not
    flat is split into triangles. (V (n, 3), [index tuples])."""
    V = np.asarray(V, dtype=float).reshape(-1, 3)
    q = max(size * 1e-7, 1e-12)
    keys, remap, U = {}, np.zeros(len(V), dtype=np.int64), []
    for i, p in enumerate(V):
        k = tuple(np.round(p / q).astype(np.int64))
        j = keys.get(k)
        if j is None:
            j = keys[k] = len(U)
            U.append(p)
        remap[i] = j
    U = np.array(U) if U else np.zeros((0, 3))
    out = []
    for f in polys:
        g = [int(remap[i]) for i in f]
        h = [g[k] for k in range(len(g)) if g[k] != g[k - 1]]
        if len(h) < 3:
            continue
        P = U[h]
        n = _newell(P)
        L = float(np.linalg.norm(n))
        if L < 1e-300:
            continue
        n = n / L
        if len(h) > 3 and float(np.abs((P - P.mean(axis=0)) @ n).max()) > size * 1e-6:
            out += [(h[0], h[k], h[k + 1]) for k in range(1, len(h) - 1)]
        else:
            out.append(tuple(h))
    return U, out


def _newell(P):
    P = np.asarray(P, dtype=float)
    Q = np.roll(P, -1, axis=0)
    return np.array([float(((P[:, 1] - Q[:, 1]) * (P[:, 2] + Q[:, 2])).sum()),
                     float(((P[:, 2] - Q[:, 2]) * (P[:, 0] + Q[:, 0])).sum()),
                     float(((P[:, 0] - Q[:, 0]) * (P[:, 1] + Q[:, 1])).sum())])


def _mesh_regions(V, polys, size):
    """Flat faces of a mesh: polygons joined across edges where they lie in one plane.
    [{"polys": [...], "n": unit normal, "p": a point}], the region of each polygon, the polygons of
    each edge."""
    tol = size * 1e-6
    N, C = [], []
    for f in polys:
        n = _newell(V[list(f)])
        N.append(n / max(float(np.linalg.norm(n)), 1e-300))
        C.append(V[list(f)].mean(axis=0))
    edge_polys = {}
    for i, f in enumerate(polys):
        for k in range(len(f)):
            a, b = f[k], f[(k + 1) % len(f)]
            edge_polys.setdefault((min(a, b), max(a, b)), []).append(i)
    parent = list(range(len(polys)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for ps in edge_polys.values():
        for x in range(len(ps)):
            for y in range(x + 1, len(ps)):
                i, j = ps[x], ps[y]
                if abs(float(N[i] @ N[j])) > 1.0 - 1e-9 and \
                        float(np.abs((V[list(polys[j])] - C[i]) @ N[i]).max()) < tol:
                    ri, rj = find(i), find(j)
                    if ri != rj:
                        parent[rj] = ri
    groups = {}
    for i in range(len(polys)):
        groups.setdefault(find(i), []).append(i)
    regions, of = [], [0] * len(polys)
    for ps in groups.values():
        n = sum((_newell(V[list(polys[i])]) for i in ps), np.zeros(3))
        L = float(np.linalg.norm(n))
        n = n / L if L > 1e-300 else N[ps[0]]
        for i in ps:
            of[i] = len(regions)
        regions.append({"polys": ps, "n": n, "p": C[ps[0]]})
    return regions, of, edge_polys


def _region_loops(V, polys, region):
    """The region's boundary loops as vertex index lists, each winding as its polygons do."""
    count = {}
    for i in region["polys"]:
        f = polys[i]
        for k in range(len(f)):
            a, b = f[k], f[(k + 1) % len(f)]
            key = (min(a, b), max(a, b))
            count[key] = count.get(key, 0) + 1
    nxt = {}
    for i in region["polys"]:
        f = polys[i]
        for k in range(len(f)):
            a, b = f[k], f[(k + 1) % len(f)]
            if count[(min(a, b), max(a, b))] == 1:
                nxt.setdefault(a, []).append(b)
    loops = []
    while any(nxt.values()):
        start = next(a for a, bs in nxt.items() if bs)
        loop, a = [start], start
        while True:
            b = nxt[a].pop()
            if b == start:
                break
            loop.append(b)
            a = b
            if not nxt.get(a) or len(loop) > len(V) + 2:
                break
        if len(loop) >= 3:
            loops.append(loop)
    return loops


def _collinear(V, a, b, c, size) -> bool:
    u, w = V[b] - V[a], V[c] - V[b]
    lu, lw = float(np.linalg.norm(u)), float(np.linalg.norm(w))
    if lu < 1e-300 or lw < 1e-300:
        return True
    return float(np.linalg.norm(np.cross(u / lu, w / lw))) < 1e-7 and float(u @ w) > 0


def _simplify_loop(V, loop, keep, size):
    """The loop without its vertices that sit straight between their neighbours (a corner of
    another face, in `keep`, stays: the faces meet on the same edges)."""
    out = list(loop)
    changed = True
    while changed and len(out) > 3:
        changed = False
        for k in range(len(out)):
            a, b, c = out[k - 1], out[k], out[(k + 1) % len(out)]
            if b not in keep and _collinear(V, a, b, c, size):
                del out[k]
                changed = True
                break
    return out


def _mesh_corners(V, polys, regions, size):
    """Vertices that must stay corners: those where the faces' outlines turn, or where more than
    two outline edges meet."""
    nb = {}
    for r in regions:
        for loop in _region_loops(V, polys, r):
            for k in range(len(loop)):
                a, b = loop[k], loop[(k + 1) % len(loop)]
                nb.setdefault(a, set()).add(b)
                nb.setdefault(b, set()).add(a)
    keep = set()
    for v, s in nb.items():
        if len(s) != 2:
            keep.add(v)
            continue
        a, c = tuple(s)
        if not _collinear(V, a, v, c, size):
            keep.add(v)
    return keep


def _mesh_bevels(V, polys, regions, of, edge_polys, size):
    """Bevel strips of a mesh: chains of two or more long flat faces between two flat faces, turning
    along a circle (a beveled edge). [{"strips": region ids, "a": region, "b": region, "d": unit
    direction, "q": a point on the sharp edge, "r": radius, "verts": strip vertices}]."""
    tol = size * 1e-6
    loops = [_region_loops(V, polys, r) for r in regions]
    keep = _mesh_corners(V, polys, regions, size)

    def neighbours(ri, a, b):
        """Regions across the side a-b of region ri (by the mesh edges lying on it)."""
        pa, pb = V[a], V[b]
        u = pb - pa
        L2 = float(u @ u)
        got = set()
        for i in regions[ri]["polys"]:
            f = polys[i]
            for k in range(len(f)):
                x, y = f[k], f[(k + 1) % len(f)]
                ok_ = True
                for v in (x, y):
                    t = float((V[v] - pa) @ u) / max(L2, 1e-300)
                    if t < -1e-9 or t > 1 + 1e-9 or float(np.linalg.norm(V[v] - pa - t * u)) > tol:
                        ok_ = False
                if ok_:
                    for j in edge_polys.get((min(x, y), max(x, y)), ()):
                        if of[j] != ri:
                            got.add(of[j])
        return got

    strips = {}
    for ri, r in enumerate(regions):
        if len(loops[ri]) != 1:
            continue
        c = _simplify_loop(V, loops[ri][0], set(), size)
        if len(c) != 4:
            continue
        sides = [(c[k], c[(k + 1) % 4]) for k in range(4)]
        dirs = [_unit(V[b] - V[a]) for a, b in sides]
        for k in (0, 1):
            if float(np.linalg.norm(np.cross(dirs[k], dirs[k + 2]))) > 1e-6:
                continue
            na, nb_ = neighbours(ri, *sides[k]), neighbours(ri, *sides[k + 2])
            if len(na) != 1 or len(nb_) != 1:
                continue
            ra, rb = next(iter(na)), next(iter(nb_))
            smooth = all(abs(float(regions[x]["n"] @ r["n"])) > math.cos(math.radians(50)) for x in (ra, rb))
            if smooth:
                a0, b0 = sides[k][0], sides[k + 2][0]
                w_ = V[b0] - V[a0]
                width = float(np.linalg.norm(w_ - float(w_ @ dirs[k]) * dirs[k]))
                strips[ri] = {"d": dirs[k], "across": (ra, rb), "w": width}
                break
    out, used = [], set()
    for s0 in strips:
        if s0 in used:
            continue
        # walk both ways along the chain
        chain = [s0]
        ends = []
        for side in (0, 1):
            prev, cur = s0, strips[s0]["across"][side]
            seq = []
            while cur in strips and cur not in chain and cur not in seq and \
                    float(np.linalg.norm(np.cross(strips[cur]["d"], strips[s0]["d"]))) < 1e-6:
                seq.append(cur)
                a_, b_ = strips[cur]["across"]
                nxt_ = b_ if a_ == prev else a_
                prev, cur = cur, nxt_
            ends.append(cur)
            chain = (seq[::-1] + chain) if side == 0 else (chain + seq)
        used.update(chain)
        # runs of strips of near one width (a bevel's segments): a flat face between two bevels is a
        # long four-sided face too, but of another width
        seq = [ends[0]] + chain + [ends[1]]
        runs, k0 = [], 1
        for k in range(2, len(seq)):
            if k == len(seq) - 1:
                runs.append((k0, k))
                break
            w0, w1 = strips[seq[k - 1]]["w"], strips[seq[k]]["w"]
            if max(w0, w1) > 1.5 * min(w0, w1) + tol:      # (a bevel's segments are near one width)
                runs.append((k0, k))
                k0 = k
        for k0, k1 in runs:
            run = seq[k0:k1]
            A, B = seq[k0 - 1], seq[k1]
            if len(run) < 2 or A == B or A in run or B in run:
                continue
            got = _bevel_fit(V, polys, regions, run, A, B, strips[run[0]]["d"], tol)
            if got is not None:
                out.append(got)
    return out


def _bevel_fit(V, polys, regions, chain, A, B, d, tol):
    """The round a run of strips between flat faces A and B stands for: tangent to both where the
    strips meet them; or None (not a bevel: the strips do not turn one way from A to B, start at
    different distances from the edge, or stray far from that round)."""
    nA, nB = regions[A]["n"], regions[B]["n"]
    d = _unit(d)
    if abs(float(nA @ d)) > 1e-6 or abs(float(nB @ d)) > 1e-6:
        return None
    cr = np.cross(nA, nB)
    if float(np.linalg.norm(cr)) < 1e-6:
        return None
    # the sharp edge: where the planes of A and B meet
    M = np.array([nA, nB, d])
    q = np.linalg.solve(M, np.array([float(nA @ regions[A]["p"]), float(nB @ regions[B]["p"]),
                                     float(d @ regions[A]["p"])]))
    verts = sorted({v for ri in chain for i in regions[ri]["polys"] for v in polys[i]})
    P = V[verts]

    def axis_dist(X, c):
        w = X - c
        return np.linalg.norm(w - np.outer(w @ d, d), axis=1)

    on_a = [v for v in verts if abs(float((V[v] - regions[A]["p"]) @ nA)) < tol]
    on_b = [v for v in verts if abs(float((V[v] - regions[B]["p"]) @ nB)) < tol]
    if not on_a or not on_b:
        return None
    sa = float(axis_dist(V[on_a], q).mean())
    sb = float(axis_dist(V[on_b], q).mean())
    if abs(sa - sb) > 0.02 * max(sa, sb) + tol:
        return None
    cos_t = float(nA @ nB)                       # the faces turn through acos(cos_t)
    phi = math.pi - math.acos(max(-1.0, min(1.0, cos_t)))     # the angle between the faces
    r = sa * math.tan(phi / 2.0)
    best = None
    pa, pb = V[on_a[0]], V[on_b[0]]
    for sa_ in (-1.0, 1.0):          # the center: r off both faces where the round meets them
        for sb_ in (-1.0, 1.0):
            ca, cb = pa + sa_ * nA * r, pb + sb_ * nB * r
            w = ca - cb
            err = float(np.linalg.norm(w - float(w @ d) * d))
            if best is None or err < best[0]:
                best = (err, ca)
    # a bevel: turning one way all along from A to B (Blender's profile is a circle only at a
    # square edge; at others a superellipse, up to some 12 % off the circle at 60 degrees: the round
    # keeps where the bevel meets the faces, G1 to both)
    ns = [nA] + [regions[x]["n"] for x in chain] + [nB]
    turns = [float(np.cross(ns[k], ns[k + 1]) @ d) for k in range(len(ns) - 1)]
    if not (all(t > 1e-9 for t in turns) or all(t < -1e-9 for t in turns)):
        return None
    dev = np.abs(axis_dist(P, best[1]) - r)
    if r <= tol or float(dev.max()) > 0.15 * r + tol:
        return None
    return {"strips": chain, "a": A, "b": B, "d": d, "q": q, "r": r, "verts": verts}


def _collapse_bevels(V, polys, regions, of, bevels, size):
    """The mesh with each bevel strip taken out: its vertices moved onto the sharp edge (on an end
    face: where the edge meets it), the strip's polygons dropped. (V, polys, [(edge point a, b,
    radius)])."""
    V = V.copy()
    drop = set()
    edges = []
    vregions = {}
    for i, f in enumerate(polys):
        for v in f:
            vregions.setdefault(v, set()).add(of[i])
    for bv in bevels:
        d, q = bv["d"], bv["q"]
        mine = set(bv["strips"]) | {bv["a"], bv["b"]}
        ts = []
        for v in bv["verts"]:
            p = V[v]
            caps = [x for x in vregions.get(v, ()) if x not in mine]
            new = None
            for cpi in caps:
                n = regions[cpi]["n"]
                den = float(n @ d)
                if abs(den) > 0.1:
                    t = float((regions[cpi]["p"] - q) @ n) / den
                    new = q + t * d
                    break
            if new is None:
                new = q + float((p - q) @ d) * d
            V[v] = new
            ts.append(float((new - q) @ d))
        for ri in bv["strips"]:
            drop.update(regions[ri]["polys"])
        edges.append((q + min(ts) * d, q + max(ts) * d, bv["r"]))
    keep = [f for i, f in enumerate(polys) if i not in drop]
    V2, P2 = _mesh_clean(V, keep, size)
    return V2, P2, edges


def _mesh_faces(V, polys, size):
    """Kernel faces of the mesh's flat faces (one per plane region, holes kept)."""
    regions, _of, _ep = _mesh_regions(V, polys, size)
    keep = _mesh_corners(V, polys, regions, size)
    faces = []
    for r in regions:
        loops = [_simplify_loop(V, lp, keep, size) for lp in _region_loops(V, polys, r)]
        loops = [lp for lp in loops if len(lp) >= 3]
        if not loops:
            continue
        areas = [abs(float(_newell(V[lp]) @ r["n"])) for lp in loops]
        order = sorted(range(len(loops)), key=lambda k: -areas[k])
        wires = []
        for k in order:
            lp = loops[k]
            wires.append(wire([line(tuple(V[lp[j]]), tuple(V[lp[(j + 1) % len(lp)]])) for j in range(len(lp))]))
        faces.append(face_from_wires(wires[0], wires[1:]))
    return faces, len(regions)


def mesh_to_brep(V, polys, bevels: bool = True):
    """A part from a mesh of flat polygons: coplanar polygons become one flat face each (holes kept,
    straight runs of edges one edge), sewn together: a solid where the mesh is closed, else one
    joined surface. With bevels, an edge beveled in two or more segments along a circle (a
    rounded edge as a mesh) becomes a true round of that radius (G1); a one-segment chamfer stays
    flat. (shape, info: {"faces", "solid", "open_edges", "bevels", "note"})."""
    V = np.asarray(V, dtype=float).reshape(-1, 3)
    if not len(V) or not len(polys):
        raise CadError("mesh to part: the mesh has no faces")
    size = max(float(np.ptp(V, axis=0).max()), 1e-9)
    V, polys = _mesh_clean(V, polys, size)
    if not polys:
        raise CadError("mesh to part: the mesh has no faces with area")

    def build(V_, P_):
        faces, n = _mesh_faces(V_, P_, size)
        if len(faces) == 1:
            return faces[0], 0, n
        body, free, _gap = stitch(faces, size * 1e-6)
        return body, free, n

    note = ""
    found = []
    if bevels:
        regions, of, ep = _mesh_regions(V, polys, size)
        found = _mesh_bevels(V, polys, regions, of, ep, size)
    plain = None
    if found:
        try:
            V2, P2, edges = _collapse_bevels(V, polys, regions, of, found, size)
            body, free, n = build(V2, P2)
            ref_solid = None
            try:
                plain = build(V, polys)
                ref_solid = is_solid(plain[0])
            except Exception:
                pass
            if ref_solid is not None and is_solid(body) != ref_solid:
                raise CadError("the mesh without its bevels did not close as it does with them")
            for a, b, r in edges:
                L = b - a
                ids = []
                for k, e in enumerate(body.edges()):
                    if str(e.geom_type).lower() != "line":
                        continue
                    m = _vec(e.point_at(0.5))
                    t = float((m - a) @ L) / max(float(L @ L), 1e-300)
                    if -1e-6 < t < 1 + 1e-6 and float(np.linalg.norm(m - a - t * L)) < size * 1e-6:
                        ids.append(k)
                if not ids:
                    raise CadError("a beveled edge was not found after taking the bevel out")
                body = fillet(body, ids, r, explain=False)
            info = {"faces": len(body.faces()), "solid": is_solid(body), "open_edges": free,
                    "bevels": len(edges), "note": ""}
            return body, info
        except Exception as ex:
            note = f"bevels kept as flat faces ({str(ex).splitlines()[0][:120]})"
    body, free, _n = plain if plain is not None else build(V, polys)
    return body, {"faces": len(body.faces()), "solid": is_solid(body), "open_edges": free, "bevels": 0,
                  "note": note}
