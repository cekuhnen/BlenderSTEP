# SPDX-License-Identifier: GPL-3.0-or-later
"""Object-level logic of the pure STEP importer: CAD objects and their display mesh.

No operator or UI context in here, so all of it runs headless (tests use bpy as a module).
"""

from __future__ import annotations

import json
import time
from contextlib import contextmanager

import bpy
import numpy as np

from .kernel import api, session
from .kernel.api import CadError

ATTR_FACE = "cad_face"
TESS_TAG = "nurbs_tess"   # on the mesh data: which tessellation it holds (shape, quality, mesher)

# seconds spent per import stage (reset by the import operator, read for its report)
timings: dict = {}


@contextmanager
def timed(key):
    t0 = time.perf_counter()
    try:
        yield
    finally:
        timings[key] = timings.get(key, 0.0) + time.perf_counter() - t0


# object name -> (blob hash, blob) of a preview shown in place of the object's own shape
preview: dict = {}

_bvh_cache: dict = {}


def is_cad(obj) -> bool:
    return obj is not None and obj.type == "MESH" and obj.nurbs.is_cad and bool(obj.nurbs.blob)


def shape_of(obj):
    p = obj.nurbs
    if not p.blob:
        raise CadError(f"{obj.name} has no exact geometry")
    return session.shape_for(p.blob_hash, p.blob)


def _tess_tag(blob_hash: str, quality: str) -> str:
    from .kernel import mesher
    return f"{blob_hash}|{quality}|{mesher.mode if mesher.available() else 'KERNEL'}"


def _tess_from_mesh(obj):
    """The tessellation saved in the object's own mesh (after opening a file), when the mesh
    still holds exactly the shape and quality it was written for; else None."""
    me = obj.data
    p = obj.nurbs
    if me is None or me.get(TESS_TAG) != _tess_tag(p.blob_hash, p.quality) or obj.name in preview:
        return None
    attr = me.attributes.get(ATTR_FACE)
    if attr is None or attr.domain != "FACE" or not len(me.polygons):
        return None
    nt = len(me.polygons)
    if len(me.loops) != nt * 3:
        return None
    co = np.zeros(len(me.vertices) * 3, dtype=np.float32)
    me.vertices.foreach_get("co", co)
    vi = np.zeros(nt * 3, dtype=np.int32)
    me.loops.foreach_get("vertex_index", vi)
    owners = np.zeros(nt, dtype=np.int32)
    attr.data.foreach_get("value", owners)
    normals = None
    try:
        cn = np.zeros(nt * 9, dtype=np.float32)
        me.corner_normals.foreach_get("vector", cn)
        normals = cn.reshape(nt, 3, 3).astype(np.float64)
    except Exception:
        normals = None
    return api.TessResult(co.reshape(-1, 3).astype(np.float64), vi.reshape(-1, 3).astype(np.int64), normals,
                          owners.astype(np.int64))


def tess_of(obj, quality=None):
    p = obj.nurbs
    q = p.quality if quality is None else quality
    if not session.has_tess(p.blob_hash, q):
        if q == p.quality:
            t = _tess_from_mesh(obj)
            if t is not None:
                session.put_tess(p.blob_hash, q, t)
                return t
    with timed("tessellate"):
        return session.tess_for(p.blob_hash, p.blob, q)


def set_shape(obj, shape) -> None:
    """Replace the object's exact geometry, clear the kernel selection, refresh the mesh."""
    with timed("blob"):
        blob = api.to_blob(shape)
        h = api.blob_hash(blob)
    session.remember(h, shape)
    p = obj.nurbs
    p.is_cad = True
    p.blob = blob
    p.blob_hash = h
    p.sel_faces = ""
    p.sel_edges = ""
    p.info = api.describe(shape)
    capture_colors(obj, shape)   # (the blob does not keep colors: read them from the live shape)
    sync_mesh(obj)


def set_blob(obj, blob: str, info: str = "") -> None:
    """Like set_shape, for a result that arrives already encoded (from the kernel worker)."""
    h = api.blob_hash(blob)
    p = obj.nurbs
    p.is_cad = True
    p.blob = blob
    p.blob_hash = h
    p.sel_faces = ""
    p.sel_edges = ""
    p.info = info or api.describe(session.shape_for(h, blob))
    sync_mesh(obj)


def _set_quality_quiet(obj, quality: str) -> None:
    """Set the display quality without the update callback spreading it to other selected parts."""
    from . import props
    props._spreading[0] = True
    try:
        obj.nurbs.quality = quality
    finally:
        props._spreading[0] = False


def new_cad_object(name: str, shape, collection=None, matrix=None, quality=None):
    me = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, me)
    (collection or bpy.context.scene.collection).objects.link(obj)
    if matrix is not None:
        obj.matrix_world = matrix
    if quality:
        _set_quality_quiet(obj, quality)   # before the first mesh, so it is meshed once
    try:
        set_shape(obj, shape)
    except Exception:
        bpy.data.objects.remove(obj, do_unlink=True)    # no empty object left behind
        bpy.data.meshes.remove(me)
        raise
    return obj


# ----------------------------------------------------------------------------- mesh sync

def sync_mesh(obj) -> None:
    """Write the exact shape's tessellation into the object's mesh data."""
    preview.pop(obj.name, None)
    t = tess_of(obj)
    with timed("mesh write"):
        _write_mesh(obj, t)


def _write_mesh(obj, t) -> None:
    me = obj.data
    if me.users > 1:  # never rewrite geometry shared with another object
        me = me.copy()
        obj.data = me

    tris = t.triangles
    keep = (tris[:, 0] != tris[:, 1]) & (tris[:, 1] != tris[:, 2]) & (tris[:, 0] != tris[:, 2])
    tris = tris[keep]
    owners = t.face_ids[keep] if len(t.face_ids) == len(keep) else np.full(len(tris), -1, dtype=np.int64)
    normals = None if t.corner_normals is None else t.corner_normals[keep]

    me.clear_geometry()
    nv, nt = len(t.vertices), len(tris)
    me.vertices.add(nv)
    me.vertices.foreach_set("co", t.vertices.astype(np.float32).ravel())
    me.loops.add(nt * 3)
    me.loops.foreach_set("vertex_index", tris.astype(np.int32).ravel())
    me.polygons.add(nt)
    me.polygons.foreach_set("loop_start", (np.arange(nt, dtype=np.int32) * 3))
    me.update(calc_edges=True)

    attr = me.attributes.get(ATTR_FACE)
    if attr is None or attr.domain != "FACE" or attr.data_type != "INT":
        if attr is not None:
            me.attributes.remove(attr)
        attr = me.attributes.new(ATTR_FACE, "INT", "FACE")
    attr.data.foreach_set("value", owners.astype(np.int32))

    me.shade_smooth()
    if normals is not None and nt:
        n = normals.reshape(-1, 3)
        lens = np.linalg.norm(n, axis=1, keepdims=True)
        n = np.where(lens > 1e-12, n / np.maximum(lens, 1e-12), 0.0)
        me.normals_split_custom_set(n.tolist())
    me.update()
    try:
        ph, _pb = preview.get(obj.name, (obj.nurbs.blob_hash, None))
        me[TESS_TAG] = _tess_tag(ph, obj.nurbs.quality) if obj.name not in preview else ""
    except Exception:
        pass
    _bvh_cache.pop(_bvh_key(obj), None)
    apply_appearance_materials(obj, owners)




# ----------------------------------------------------------------------------- STEP colors / materials

COLORS_KEY = "step_colors"      # on the object: the STEP colors of its faces (JSON), see capture_colors
DEFAULT_RGB = (0.8, 0.8, 0.8)


def srgb_to_linear(c: float) -> float:
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def capture_colors(obj, shape) -> None:
    """Remember the colors the STEP file gave the body and its faces. The exact-geometry blob does not
    keep them, so they are read from the live shape and stored on the object: a palette of the distinct
    colors, the default one (the body's, else gray) and, where faces differ, one palette index per face
    (in shape.faces() order, the same ids as the mesh's cad_face attribute)."""
    try:
        body = getattr(shape, "color", None)
        faces = [f.color for f in shape.faces()]
    except Exception:
        return
    if body is None and all(c is None for c in faces):
        if COLORS_KEY in obj:
            del obj[COLORS_KEY]
        return
    palette, index = [], {}

    def pal(c):
        key = tuple(round(float(x), 6) for x in list(c)[:3])
        if key not in index:
            index[key] = len(palette)
            palette.append(list(key))
        return index[key]

    default = pal(body if body is not None else DEFAULT_RGB)
    ids = [pal(c) if c is not None else default for c in faces]
    data = {"palette": palette, "default": default}
    if any(i != default for i in ids):
        data["faces"] = ids
    obj[COLORS_KEY] = json.dumps(data)


def _material_for(rgb):
    """The shared material of one (sRGB) color: made once, reused by every part."""
    name = "STEP_%.3f_%.3f_%.3f" % tuple(rgb)
    mat = bpy.data.materials.get(name)
    if mat is not None:
        return mat
    lin = tuple(srgb_to_linear(float(c)) for c in rgb)
    mat = bpy.data.materials.new(name)
    try:
        mat.use_nodes = True
    except Exception:
        pass
    bsdf = mat.node_tree.nodes.get("Principled BSDF") if mat.node_tree else None
    if bsdf is not None:
        bsdf.inputs["Base Color"].default_value = lin + (1.0,)
        bsdf.inputs["Metallic"].default_value = 0.0
        bsdf.inputs["Roughness"].default_value = 0.5
    mat.diffuse_color = lin + (1.0,)      # the Solid viewport shows it too
    return mat


def apply_appearance_materials(obj, owners=None) -> None:
    """Give the mesh one slot per distinct STEP color and point each triangle at its face's color.
    `owners`: the face id of every triangle (the cad_face attribute, read when not given)."""
    with timed("materials"):
        me = obj.data
        nt = len(me.polygons)
        if nt == 0:
            return
        if owners is None:
            attr = me.attributes.get(ATTR_FACE)
            owners = np.full(nt, -1, dtype=np.int32)
            if attr is not None and attr.domain == "FACE":
                attr.data.foreach_get("value", owners)
        owners = np.asarray(owners, dtype=np.int64)

        try:
            data = json.loads(obj[COLORS_KEY]) if COLORS_KEY in obj else None
        except Exception:
            data = None
        palette = data["palette"] if data else [list(DEFAULT_RGB)]
        default = int(data["default"]) if data else 0
        face_idx = np.asarray(data["faces"], dtype=np.int64) if data and "faces" in data else None

        if face_idx is None:
            per_tri = np.full(nt, default, dtype=np.int64)
        else:
            ok = (owners >= 0) & (owners < len(face_idx))
            per_tri = np.where(ok, face_idx[np.where(ok, owners, 0)], default)

        used = np.unique(per_tri)
        slot_of = np.zeros(len(palette), dtype=np.int32)
        slot_of[used] = np.arange(len(used), dtype=np.int32)
        mats = [_material_for(palette[int(i)]) for i in used]
        if [m.name for m in me.materials if m] != [m.name for m in mats]:
            me.materials.clear()
            for m in mats:
                me.materials.append(m)
        me.polygons.foreach_set("material_index", slot_of[per_tri])
        me.update()


def _bvh_key(obj):
    p = obj.nurbs
    return (p.blob_hash, p.quality)

