import bpy


def _quality_update(self, context):
    """A quality choice goes to all selected parts too."""
    from . import core
    obj = self.id_data
    if self.is_cad and isinstance(obj, bpy.types.Object):
        try:
            core.sync_mesh(obj)
        except Exception as ex:  # keep the UI alive
            print("NURBS STEP Importer: re-tessellation failed:", ex)
    if not _spreading[0]:
        _spreading[0] = True
        try:
            targets = list(getattr(context, "selected_objects", None) or ())
            owner = getattr(self, "id_data", None)
            if owner is not None and core.is_cad(owner) and all(o is not owner for o in targets):
                targets.append(owner)
            for o in targets:
                if core.is_cad(o) and o.nurbs.quality != self.quality:
                    o.nurbs.quality = self.quality
        except Exception:
            pass
        finally:
            _spreading[0] = False


def _fast_mesh_update(self, context):
    """Switch between the add-on's own mesher and the kernel's tessellation; every part is meshed
    again."""
    from . import core
    from .kernel import mesher, session
    mesher.enabled = bool(self.fast_mesh)
    session.clear()
    core._bvh_cache.clear()
    for obj in (context.scene.objects if context and context.scene else ()):
        if core.is_cad(obj):
            try:
                core.sync_mesh(obj)
            except Exception as ex:  # keep the UI alive
                print("NURBS STEP Importer: re-tessellation failed:", ex)


def _redraw_views(self, context):
    """Show a display setting at once in every 3D view."""
    wm = getattr(context, "window_manager", None) or bpy.context.window_manager
    for win in getattr(wm, "windows", []):
        for area in win.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


_spreading = [False]


def _diagnostic_changed(self, context):
    """A choice made on a part goes to all selected parts too."""
    if not _spreading[0]:
        _spreading[0] = True
        try:
            from . import core
            targets = list(getattr(context, "selected_objects", None) or ())
            owner = getattr(self, "id_data", None)
            if owner is not None and core.is_cad(owner) and all(o is not owner for o in targets):
                targets.append(owner)
            for o in targets:
                if core.is_cad(o) and o.nurbs.diagnostic != self.diagnostic:
                    o.nurbs.diagnostic = self.diagnostic
        except Exception:
            pass
        finally:
            _spreading[0] = False
    _redraw_views(self, context)


class NURBS_PG_object(bpy.types.PropertyGroup):
    is_cad: bpy.props.BoolProperty(name="CAD Object", default=False)
    # The exact solid or surface: SMLib .smb, zlib-compressed, base64. This is the truth;
    # the mesh is display. Stored on the object so Blender's undo snapshots it.
    blob: bpy.props.StringProperty(name="Exact Geometry", default="", options={"HIDDEN"})
    blob_hash: bpy.props.StringProperty(name="Hash", default="", options={"HIDDEN"})
    info: bpy.props.StringProperty(name="Info", default="")
    quality: bpy.props.EnumProperty(
        name="Display Quality",
        items=[
            ("DRAFT", "Draft", "Coarse tessellation, fastest"),
            ("NORMAL", "Normal", "Balanced tessellation"),
            ("FINE", "Fine", "Dense tessellation for close-ups and renders"),
        ],
        default="NORMAL",
        update=_quality_update,
    )
    diagnostic: bpy.props.EnumProperty(
        name="Diagnostic",
        items=[
            ("NONE", "Off", "No diagnostic shading"),
            ("ZEBRA", "Zebra", "Reflected stripes: they run on smoothly across G2 joins, bend at G1, break at G0"),
            ("HIGHLIGHT", "Highlight Lines", "Long straight studio lights reflected as thin lines (as car "
                                            "designers judge a surface): smooth lines across G2 joins, a kink "
                                            "at G1, a break at G0"),
            ("IMAGE", "Environment Image", "A chrome reflection of an image you load (an HDRI or any "
                                          "panorama, equirectangular)"),
            ("CURVATURE", "Curvature Map", "Curvature-based diagnostic: shows where the surface bends strongly. Blue = low curvature / flat, red = high curvature / tight features; best seen with Display Quality = Fine"),
        ],
        default="NONE",
        update=_diagnostic_changed,
        description="Diagnostic shading of the part (zebra, highlight lines, environment image)",
    )
    # Selected kernel faces / edges of the current shape, as comma-separated ids.
    sel_faces: bpy.props.StringProperty(default="", options={"HIDDEN"})
    sel_edges: bpy.props.StringProperty(default="", options={"HIDDEN"})


class NURBS_PG_scene(bpy.types.PropertyGroup):
    fast_mesh: bpy.props.BoolProperty(
        name="Fast Mesher", default=True, update=_fast_mesh_update,
        description="Mesh parts with the add-on's own mesher (several times faster on parts with many holes "
                    "or faces, and only the faces an edit changed are meshed again); off: the kernel's "
                    "tessellation for every part")

    # Diagnostic shading settings (zebra / highlight lines / environment / curvature / draft).
    zebra_dir: bpy.props.EnumProperty(
        name="Stripes Run",
        items=[
            ("HORIZONTAL", "Horizontal", "Level stripes: a reflection of bands stacked up the world's vertical "
                                        "(they stay put on the part as the view turns about it)"),
            ("VERTICAL", "Vertical", "Upright stripes: a reflection of bands side by side across the view "
                                     "(they turn with the view)"),
        ],
        default="HORIZONTAL", update=_redraw_views)
    zebra_stripes: bpy.props.IntProperty(name="Stripes", default=12, min=2, max=80, update=_redraw_views)
    highlight_count: bpy.props.IntProperty(name="Lights", default=7, min=1, max=40, update=_redraw_views,
                                           description="Highlight Lines: how many light tubes")
    highlight_width: bpy.props.FloatProperty(name="Width", default=0.15, min=0.02, max=0.9, update=_redraw_views,
                                             description="Highlight Lines: each light's width, a part of the "
                                                         "space between lights")
    highlight_angle: bpy.props.FloatProperty(name="Turn", default=0.0, subtype="ANGLE", update=_redraw_views,
                                             description="Highlight Lines: the lights turned about the vertical "
                                                          "(0: they run along X)")
    env_image: bpy.props.PointerProperty(name="Image", type=bpy.types.Image, update=_redraw_views,
                                        description="Environment Image: a panorama (equirectangular, as HDRIs "
                                                    "are) the parts reflect")
    env_rotation: bpy.props.FloatProperty(name="Rotation", default=0.0, subtype="ANGLE", update=_redraw_views,
                                          description="Environment Image: turned about the vertical")
    env_exposure: bpy.props.FloatProperty(name="Exposure", default=1.0, min=0.01, max=50.0, update=_redraw_views,
                                          description="Environment Image: brighter or darker (HDR images may "
                                                      "want less than 1)")
    curvature_scale: bpy.props.FloatProperty(name="Range", default=1.0, min=0.0, soft_max=10.0, update=_redraw_views)


classes = (NURBS_PG_object, NURBS_PG_scene)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Object.nurbs = bpy.props.PointerProperty(type=NURBS_PG_object)
    bpy.types.Scene.nurbs = bpy.props.PointerProperty(type=NURBS_PG_scene)


def unregister():
    del bpy.types.Scene.nurbs
    del bpy.types.Object.nurbs
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
