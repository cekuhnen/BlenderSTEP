import os
import time

import bpy
from bpy_extras.io_utils import ImportHelper

from . import core, props
from .kernel import api
from .kernel.api import CadError

# The kernel works in millimeters (STEP files are converted to mm on reading); Blender's lengths
# are in Blender units.
BU_UNITS = [("SCENE", "Scene", "From the scene's units: 1 Blender unit = Unit Scale meters (normally 1 m, also in "
                       "an Imperial scene, which only displays inches)"),
            ("m", "Meters", "1 Blender unit = 1 m"),
            ("mm", "Millimeters", "1 Blender unit = 1 mm"),
            ("cm", "Centimeters", "1 Blender unit = 1 cm"),
            ("inch", "Inches", "1 Blender unit = 1 inch")]
_MM = {"m": 1000.0, "mm": 1.0, "cm": 10.0, "inch": 25.4}


def mm_per_blender_unit(context, choice: str = "SCENE") -> float:
    if choice in _MM:
        return _MM[choice]
    try:
        s = float(f"{float(context.scene.unit_settings.scale_length):.7g}")   # (stored in single precision)
    except Exception:
        s = 1.0
    return 1000.0 * (s if s > 0 else 1.0)


class NURBS_OT_import_step(bpy.types.Operator, ImportHelper):
    """Import STEP bodies as exact CAD objects, at their real size"""
    bl_idname = "nurbs.import_step"
    bl_label = "Import STEP"
    filename_ext = ".step"
    filter_glob: bpy.props.StringProperty(default="*.step;*.stp", options={"HIDDEN"})
    unit: bpy.props.EnumProperty(name="Blender Unit Is", items=BU_UNITS, default="SCENE")
    scale: bpy.props.FloatProperty(name="Extra Scale", default=1.0, min=1e-6,
                                   description="Applied on top of the unit conversion (1: real size)")
    import_quality: bpy.props.EnumProperty(name="Mesh Quality",
                                           items=[
                                               ("DRAFT", "Draft", "Coarse tessellation, fastest import"),
                                               ("NORMAL", "Normal", "Balanced tessellation"),
                                               ("FINE", "Fine", "Dense tessellation for close-ups"),
                                           ],
                                           default="NORMAL",
                                           description="Tessellation quality used on first import")

    mesher_mode: bpy.props.EnumProperty(
        name="Mesher", items=props.MESHER_ITEMS, default="AUTO",
        description="Which mesher makes the display mesh (the scene's Mesher setting: changing it here meshes "
                    "the CAD parts already in the scene again)")

    def invoke(self, context, event):
        try:
            self.mesher_mode = context.scene.nurbs.mesher_mode    # start from the scene's setting
        except Exception:
            pass
        return super().invoke(context, event)

    def execute(self, context):
        from .kernel import mesher
        try:
            # (only when the dialog set it: a script calling the operator leaves the scene's choice alone)
            if (self.properties.is_property_set("mesher_mode")
                    and context.scene.nurbs.mesher_mode != self.mesher_mode):
                context.scene.nurbs.mesher_mode = self.mesher_mode
        except Exception as ex:
            print("Blender STEP: could not apply the Mesher option:", ex)
        k = self.scale / mm_per_blender_unit(context, self.unit)    # mm -> Blender units
        core.timings.clear()
        mesher.stats.update(faces=0, reused=0, fallback=0, kernel_retry=0, bodies_fast=0, bodies_kernel=0, last_error="")
        t_all = time.perf_counter()
        try:
            t0 = time.perf_counter()
            bodies = api.import_step(self.filepath)
            t_read = time.perf_counter() - t0
            base = os.path.splitext(os.path.basename(self.filepath))[0]
            made = []
            failed = []
            for i, b in enumerate(bodies):
                name = getattr(b, "name", None) or f"{base}_{i + 1}"
                try:
                    if abs(k - 1.0) > 1e-12:
                        b = api._call("scale", b.scale, k)      # (keeps the body's and faces' colors)
                    # quality goes in with the shape, so the part is meshed once, at that quality
                    made.append(core.new_cad_object(name, b, context.collection, quality=self.import_quality))
                except Exception as ex:      # one bad body must not stop the others
                    failed.append(f"{name}: {ex}")
            if failed:
                print("Blender STEP: left out", *failed, sep="\n  ")
                self.report({"WARNING"}, f"Left out {len(failed)} of {len(bodies)} bodies "
                                         f"({failed[0]}{' ...' if len(failed) > 1 else ''}); see the console")
            if not made:
                return {"CANCELLED"}
        except CadError as ex:
            self.report({"ERROR"}, str(ex))
            return {"CANCELLED"}
        for o in context.selected_objects:
            o.select_set(False)
        for o in made:
            o.select_set(True)
        if made:
            context.view_layer.objects.active = made[-1]
        t = core.timings
        total = time.perf_counter() - t_all
        detail = (f"STEP read {t_read:.2f}s, blob {t.get('blob', 0):.2f}s, tessellate {t.get('tessellate', 0):.2f}s, "
                  f"mesh write {t.get('mesh write', 0):.2f}s, materials {t.get('materials', 0):.2f}s; "
                  f"mesher {mesher.mode}: {mesher.stats.get('bodies_fast', 0)} fast, {mesher.stats.get('bodies_kernel', 0)} kernel, "
                  f"{mesher.stats['fallback']} fallback(s), {mesher.stats.get('kernel_retry', 0)} kernel retr{'y' if mesher.stats.get('kernel_retry', 0) == 1 else 'ies'}")
        print(f"Blender STEP: imported {len(made)} bodies in {total:.2f}s ({detail})"
              + (f" last fallback: {mesher.stats['last_error']}" if mesher.stats["last_error"] else ""))
        self.report({"INFO"}, f"Imported {len(made)} bod{'y' if len(made) == 1 else 'ies'} in {total:.1f}s")
        return {"FINISHED"}


class NURBS_OT_bake_mesh(bpy.types.Operator):
    """Keep the current mesh and drop the exact geometry (turns a CAD object into a regular mesh)"""
    bl_idname = "nurbs.bake_mesh"
    bl_label = "Bake to Mesh"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(core.is_cad(o) for o in context.selected_objects)

    def execute(self, context):
        for o in context.selected_objects:
            if core.is_cad(o):
                p = o.nurbs
                p.is_cad = False
                p.blob = ""
                p.blob_hash = ""
                p.info = ""
                core.clear_selection(o)
        return {"FINISHED"}


def menu_import(self, context):
    self.layout.operator(NURBS_OT_import_step.bl_idname, text="STEP (.step / .stp)")


classes = (NURBS_OT_import_step, NURBS_OT_bake_mesh)


def register_menus():
    bpy.types.TOPBAR_MT_file_import.append(menu_import)


def unregister_menus():
    bpy.types.TOPBAR_MT_file_import.remove(menu_import)
