# SPDX-License-Identifier: GPL-3.0-or-later
"""Surface diagnostic shading shown in the viewport: zebra stripes and an environment reflection (a GPU shader
on the parts' tessellation, view dependent), curvature colouring (Gaussian / mean / smallest
radius, from the kernel's exact curvature at every mesh vertex) and draft-angle colouring against a
pull direction; plus coloured edge marks from Check Continuity and the line of the last distance
measured. Everything is drawn by overlay.py; this module computes and caches the data."""

from __future__ import annotations

import math

import numpy as np

from . import core

_cache: dict = {}
marks: list = []            # [(world polyline (k, 3), rgba, width)] from Check Continuity / Measure
last_measure = {"text": ""}

LEVEL_COLORS = {"G0": (0.95, 0.2, 0.15, 1.0), "G1": (1.0, 0.8, 0.1, 1.0), "G2": (0.2, 0.85, 0.3, 1.0),
                "G3": (0.2, 0.7, 1.0, 1.0)}


def _tess(obj, quality=None):
    t = core.tess_of(obj, quality)
    tris = t.triangles
    keep = (tris[:, 0] != tris[:, 1]) & (tris[:, 1] != tris[:, 2]) & (tris[:, 0] != tris[:, 2])
    tris = tris[keep]
    owners = t.face_ids[keep] if len(t.face_ids) == len(keep) else np.full(len(tris), -1)
    if t.corner_normals is not None:
        nor = np.asarray(t.corner_normals)[keep].reshape(-1, 3)
    else:
        a, b, c = (t.vertices[tris[:, k]] for k in range(3))
        fn = np.cross(b - a, c - a)
        fn /= np.maximum(np.linalg.norm(fn, axis=1, keepdims=True), 1e-300)
        nor = np.repeat(fn, 3, axis=0)
    pos = t.vertices[tris].reshape(-1, 3)
    lens = np.linalg.norm(nor, axis=1, keepdims=True)
    nor = np.where(lens > 1e-12, nor / np.maximum(lens, 1e-12), 0.0)
    # Also return vertex positions for color interpolation
    verts = t.vertices
    return pos.astype(np.float32), nor.astype(np.float32), tris, owners, verts


def geometry(obj, quality=None):
    """(positions, normals) per triangle corner, object space, cached."""
    p = obj.nurbs
    q = p.quality if quality is None else quality
    key = ("G", p.blob_hash, q)
    if key not in _cache:
        if len(_cache) > 64:
            _cache.clear()
        pos, nor, _t, _o, _v = _tess(obj, q)
        _cache[key] = (pos, nor)
    return _cache[key]


def geometry_data(obj, quality=None):
    """Return (pos, nor, tris, owners, verts) for the given quality, cached."""
    p = obj.nurbs
    q = p.quality if quality is None else quality
    key = ("GD", p.blob_hash, q)
    if key not in _cache:
        if len(_cache) > 64:
            _cache.clear()
        pos, nor, tris, owners, verts = _tess(obj, q)
        _cache[key] = (pos, nor, tris, owners, verts)
    return _cache[key]


def geometry_for_quality(obj, quality: str):
    """Like geometry(), but with an explicit quality override for overlay use."""
    return geometry(obj, quality)


def _diverging(x):
    """-1..1 -> blue .. green .. red."""
    x = np.clip(x, -1.0, 1.0)
    r = np.clip(x * 2.0, 0.0, 1.0) * 0.9 + 0.1 * (x <= 0)
    b = np.clip(-x * 2.0, 0.0, 1.0) * 0.9 + 0.1 * (x >= 0)
    g = 1.0 - np.abs(x) * 0.75
    return np.stack([r, g * 0.85, b, np.ones_like(x)], axis=1)


def curvature_values(obj, kind: str, quality=None):
    """Per-corner curvature values (object space): GAUSSIAN, MEAN, or MAX (largest |k|)."""
    p = obj.nurbs
    q = p.quality if quality is None else quality
    key = ("K", p.blob_hash, q, kind)
    if key in _cache:
        return _cache[key]
    _pos, _nor, tris, owners, verts = _tess(obj, q)
    faces = list(core.shape_of(obj).faces())
    memo = {}
    vals = np.zeros(len(tris) * 3)
    for t_i, (tri, f) in enumerate(zip(tris, owners)):
        for c, vi in enumerate(tri):
            k = (int(vi), int(f))
            if k not in memo:
                v = 0.0
                if 0 <= f < len(faces):
                    try:
                        cv = faces[f].curvature_at(tuple(verts[vi]))
                        if kind == "GAUSSIAN":
                            v = float(cv.k1) * float(cv.k2)
                        elif kind == "MEAN":
                            v = 0.5 * (float(cv.k1) + float(cv.k2))
                        else:
                            v = max(abs(float(cv.k1)), abs(float(cv.k2))) * (1 if (cv.k1 + cv.k2) >= 0 else -1)
                    except Exception:
                        v = 0.0
                memo[k] = v
            vals[t_i * 3 + c] = memo[k]
    vals = np.nan_to_num(vals, nan=0.0, posinf=0.0, neginf=0.0)
    _cache[key] = vals
    return vals

def curvature_values_for_quality(obj, kind: str, quality: str):
    """Like curvature_values(), but with an explicit quality override."""
    return curvature_values(obj, kind, quality)


def curvature_colors(obj, kind: str, scale: float = 0.0, quality=None):
    # Get tessellation data for vertex interpolation
    pos, nor, tris, owners, verts = geometry_data(obj, quality)
    # Compute per-corner curvature values using the same tess data
    faces = list(core.shape_of(obj).faces())
    memo = {}
    n_tri = len(tris)
    vals = np.zeros(n_tri * 3, dtype=np.float32)
    for t_i, (tri, f) in enumerate(zip(tris, owners)):
        for c, vi in enumerate(tri):
            k = (int(vi), int(f))
            if k not in memo:
                v = 0.0
                if 0 <= f < len(faces):
                    try:
                        cv = faces[f].curvature_at(tuple(verts[vi]))
                        if kind == "GAUSSIAN":
                            v = float(cv.k1) * float(cv.k2)
                        elif kind == "MEAN":
                            v = 0.5 * (float(cv.k1) + float(cv.k2))
                        else:
                            v = max(abs(float(cv.k1)), abs(float(cv.k2))) * (1 if (cv.k1 + cv.k2) >= 0 else -1)
                    except Exception:
                        v = 0.0
                memo[k] = v
            vals[t_i * 3 + c] = memo[k]
    vals = np.nan_to_num(vals, nan=0.0, posinf=0.0, neginf=0.0)

    # Vertex-interpolated smoothing: average curvature per vertex across incident faces
    if len(verts) > 0 and n_tri > 0:
        flat_tris = tris.reshape(-1)
        vertex_vals = np.zeros(len(verts), dtype=np.float32)
        counts = np.zeros(len(verts), dtype=np.int32)
        np.add.at(vertex_vals, flat_tris, vals)
        np.add.at(counts, flat_tris, 1)
        mask = counts > 0
        vertex_vals[mask] /= counts[mask]
        vals_smooth = vertex_vals[flat_tris]
    else:
        vals_smooth = vals

    if scale <= 0:
        nz = np.abs(vals_smooth[np.abs(vals_smooth) > 1e-12])
        scale = float(np.percentile(nz, 95)) if len(nz) else 1.0
    if not np.isfinite(scale) or scale <= 0:
        scale = 1.0
    return _diverging(vals_smooth / max(scale, 1e-300)).astype(np.float32), scale


def curvature_colors_for_quality(obj, kind: str, scale: float = 0.0, quality: str = "NORMAL"):
    return curvature_colors(obj, kind, scale, quality)


def draft_colors(obj, pull_world, min_angle_deg: float, quality=None):
    """Green where a face pulls out of the mold along `pull` with at least the draft, red where it
    faces the other way by that much (the other mold half / an undercut), yellow in between."""
    _pos, nor = geometry(obj, quality)
    R = np.array(obj.matrix_world.to_3x3())
    n_w = nor @ R.T
    n_w /= np.maximum(np.linalg.norm(n_w, axis=1, keepdims=True), 1e-12)
    d = np.asarray(pull_world, dtype=float)
    d = d / max(np.linalg.norm(d), 1e-12)
    s = n_w @ d
    lim = math.sin(math.radians(min_angle_deg))
    col = np.zeros((len(s), 4), dtype=np.float32)
    col[:, 3] = 1.0
    col[s >= lim] = (0.25, 0.8, 0.3, 1.0)
    col[s <= -lim] = (0.9, 0.25, 0.2, 1.0)
    mid = (s > -lim) & (s < lim)
    col[mid] = (1.0, 0.85, 0.15, 1.0)
    return col


def draft_colors_for_quality(obj, pull_world, min_angle_deg: float, quality: str):
    return draft_colors(obj, pull_world, min_angle_deg, quality)


def draft_angles(obj, pull_world):
    """Per-corner draft angle in degrees (90 - the angle between normal and pull)."""
    _pos, nor = geometry(obj)
    R = np.array(obj.matrix_world.to_3x3())
    n_w = nor @ R.T
    n_w /= np.maximum(np.linalg.norm(n_w, axis=1, keepdims=True), 1e-12)
    d = np.asarray(pull_world, dtype=float)
    d = d / max(np.linalg.norm(d), 1e-12)
    return np.degrees(np.arcsin(np.clip(n_w @ d, -1.0, 1.0)))


# ----------------------------------------------------------------------------- the reflection shader

_shader = {"obj": None, "error": ""}

VERT = """
void main()
{
    opos = pos;
    onor = nor;
    gl_Position = mvp * vec4(pos, 1.0);
}
"""

FRAG = """
void main()
{
    vec3 n = normalize(onor);
    vec3 v = (up.w > 0.5) ? normalize(viewDir.xyz) : normalize(opos - eye.xyz);
    if (dot(n, v) > 0.0) { n = -n; }
    vec3 r = reflect(v, n);
    float rz = dot(r, normalize(up.xyz));      /* the reflection's height in the world */
    float stripes = eye.w;
    vec3 col;
    if (viewDir.w < 0.5) {
        float lat = asin(clamp(rz, -1.0, 1.0)) / 3.14159265 + 0.5;
        float band = fract(lat * stripes);
        float edge = fwidth(lat * stripes) * 1.5;
        float s = smoothstep(0.5 - edge, 0.5 + edge, band) - smoothstep(1.0 - edge, 1.0, band);
        col = mix(vec3(0.04), vec3(0.96), s);
    } else if (viewDir.w > 1.5) {
        /* highlight lines: long light tubes along T overhead, spread over 140 degrees round T */
        vec3 N = normalize(up.xyz);
        vec3 T = normalize(params.xyz);
        vec3 B = normalize(cross(N, T));
        float phi = atan(dot(r, B), dot(r, N));
        float spread = 2.443461;                            /* 140 degrees */
        float k = (stripes > 1.5) ? (phi + 0.5 * spread) / spread * (stripes - 1.0) : phi / spread;
        float d = abs(k - floor(k + 0.5));
        float inside = (stripes > 1.5) ? step(-0.5, k) * step(k, stripes - 0.5) : step(d, 0.5);
        float w = 0.5 * params.w;
        float edge = fwidth(k) * 1.2;
        float lit = (1.0 - smoothstep(w - edge, w + edge, d)) * inside;
        float h = rz * 0.5 + 0.5;
        vec3 base = mix(vec3(0.05), vec3(0.22), smoothstep(0.2, 0.8, h));
        col = mix(base, vec3(1.0), lit);
    } else {
        /* dark top / bright center / dark bottom */
        float t = abs(rz);                             /* 0: reflected across the middle; 1: straight up / straight down */
        float bright = max(0.0, 1.0 - t / 0.30);     /* bright through the middle, dark at the top and bottom */
        col = mix(vec3(0.012, 0.012, 0.016), vec3(0.80, 0.77, 0.72), bright);  /* dark .. bright center */
        col += vec3(pow(max(rz, 0.0), 60.0) * bright);
    }
    FragColor = vec4(col, 1.0);
}
"""

FRAG_IMAGE = """
void main()
{
    vec3 n = normalize(onor);
    vec3 v = (up.w > 0.5) ? normalize(viewDir.xyz) : normalize(opos - eye.xyz);
    if (dot(n, v) > 0.0) { n = -n; }
    vec3 r = normalize(reflect(v, n));
    vec3 Z = normalize(up.xyz);
    vec3 X = normalize(params.xyz - Z * dot(params.xyz, Z));
    vec3 Y = cross(Z, X);
    float lon = atan(dot(r, Y), dot(r, X));
    float lat = asin(clamp(dot(r, Z), -1.0, 1.0));
    vec2 uv = vec2(lon / 6.28318531 + 0.5, lat / 3.14159265 + 0.5);
    vec3 c = textureLod(envTex, uv, 0.0).rgb * params.w;
    FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
"""

_shader_img = {"obj": None, "error": ""}


def image_shader():
    """The environment-image shader (an equirectangular texture looked up by the reflection)."""
    if _shader_img["obj"] is not None or _shader_img["error"]:
        return _shader_img["obj"]
    try:
        import gpu
        info = gpu.types.GPUShaderCreateInfo()
        info.push_constant("MAT4", "mvp")
        info.push_constant("VEC4", "eye")
        info.push_constant("VEC4", "viewDir")
        info.push_constant("VEC4", "up")         # world up in the part's space; w: 1 orthographic
        info.push_constant("VEC4", "params")     # the image's X direction in the part's space; w: exposure
        info.sampler(0, "FLOAT_2D", "envTex")
        info.vertex_in(0, "VEC3", "pos")
        info.vertex_in(1, "VEC3", "nor")
        iface = gpu.types.GPUStageInterfaceInfo("nurbs_envimg_iface")
        iface.smooth("VEC3", "opos")
        iface.smooth("VEC3", "onor")
        info.vertex_out(iface)
        info.fragment_out(0, "VEC4", "FragColor")
        info.vertex_source(VERT)
        info.fragment_source(FRAG_IMAGE)
        _shader_img["obj"] = gpu.shader.create_from_info(info)
    except Exception as ex:
        _shader_img["error"] = f"{type(ex).__name__}: {ex}"
    return _shader_img["obj"]


_tex = {"key": None, "tex": None}


def env_texture(image):
    """The GPU texture of the environment image (made again when the image changes)."""
    import gpu
    key = (image.name, image.size[0], image.size[1], getattr(image, "filepath", ""), image.is_dirty)
    if _tex["key"] != key or _tex["tex"] is None:
        _tex["tex"] = gpu.texture.from_image(image)
        _tex["key"] = key
    return _tex["tex"]


def reflection_shader():
    """The zebra / environment shader (None where the GPU module cannot build it)."""
    if _shader["obj"] is not None or _shader["error"]:
        return _shader["obj"]
    try:
        import gpu
        info = gpu.types.GPUShaderCreateInfo()
        # within the 128 bytes of push constants every GPU backend guarantees (Vulkan, Metal): one
        # matrix and three vectors (the eye, view direction and world up in the part's own space,
        # with the settings in their fourth components)
        info.push_constant("MAT4", "mvp")
        info.push_constant("VEC4", "eye")        # w: the number of stripes
        info.push_constant("VEC4", "viewDir")    # w: 0 zebra, 1 environment
        info.push_constant("VEC4", "up")         # w: 1 for an orthographic view
        info.push_constant("VEC4", "params")     # highlight lines: the tubes' direction, their width
        info.vertex_in(0, "VEC3", "pos")
        info.vertex_in(1, "VEC3", "nor")
        iface = gpu.types.GPUStageInterfaceInfo("nurbs_reflect_iface")
        iface.smooth("VEC3", "opos")
        iface.smooth("VEC3", "onor")
        info.vertex_out(iface)
        info.fragment_out(0, "VEC4", "FragColor")
        info.vertex_source(VERT)
        info.fragment_source(FRAG)
        _shader["obj"] = gpu.shader.create_from_info(info)
    except Exception as ex:
        _shader["error"] = f"{type(ex).__name__}: {ex}"
    return _shader["obj"]
