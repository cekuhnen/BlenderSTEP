# SPDX-License-Identifier: GPL-3.0-or-later
"""Viewport overlay: the diagnostic shading on the CAD parts (zebra, environment, highlight lines,
environment image, curvature, draft), drawn with the gpu module on top of the display mesh."""

import bpy
import math

import numpy as np
from mathutils import Vector

from . import core

_handle = None
_batches: dict = {}
_warned = False
status = {"draws": 0, "error": ""}  # shown in the panel for diagnosis

EDGE_COLOR = (0.02, 0.02, 0.025, 0.85)
SEL_COLOR = (1.0, 0.55, 0.1, 1.0)
FACE_COLOR = (1.0, 0.55, 0.1, 0.30)


def _segments(polylines, which=None):
    segs = []
    for i, pl in enumerate(polylines):
        if which is not None and i not in which:
            continue
        if len(pl) < 2:
            continue
        a, b = pl[:-1], pl[1:]
        segs.append(np.stack([a, b], axis=1).reshape(-1, 3))
    return np.concatenate(segs).astype(np.float32) if segs else np.zeros((0, 3), np.float32)


def _batch(key, make):
    b = _batches.get(key)
    if b is None:
        if len(_batches) > 256:
            _batches.clear()
        b = _batches[key] = make()
    return b


def object_diagnostic(obj, scene) -> str:
    """The diagnostic shading on a part: its own choice."""
    return getattr(obj.nurbs, "diagnostic", "NONE")


def any_diagnostic(scene, objs) -> bool:
    return any(getattr(o.nurbs, "diagnostic", "NONE") != "NONE" for o in objs)


def _draw_diagnostic(ctx, scene, objs, proj):
    """Diagnostic shading on the parts (zebra, environment, highlight lines, an environment image,
    curvature, draft), each part as its own choice says."""
    from . import analysis
    import gpu
    from gpu_extras.batch import batch_for_shader
    groups = {}
    for o in objs:
        m = object_diagnostic(o, scene)
        if m != "NONE":
            groups.setdefault(m, []).append(o)
    try:
        for mode, group in groups.items():
            _draw_diagnostic_mode(ctx, scene, group, proj, mode)
    finally:
        gpu.state.face_culling_set("NONE")


def _cull_for(obj):
    """A solid's far side is not drawn: the shading is drawn a hair towards the viewer (to win
    against the part's own faces), and without this the back of the part right behind a sharp rim
    showed through as a bright or dark crescent, as if the rim stood out."""
    import gpu
    flipped = obj.matrix_world.to_3x3().determinant() < 0
    gpu.state.face_culling_set("FRONT" if flipped else "BACK")


def _draw_diagnostic_mode(ctx, scene, objs, proj, mode):
    from . import analysis
    import gpu
    from gpu_extras.batch import batch_for_shader
    rv3d = ctx.region_data
    if rv3d is None:
        return
    if mode in ("ZEBRA", "HIGHLIGHT", "IMAGE"):
        tex = None
        if mode == "IMAGE":
            img = scene.nurbs.env_image
            if img is None:
                return          # no environment image loaded: nothing to reflect
            try:
                tex = analysis.env_texture(img)
            except Exception as ex:
                status["error"] = f"environment image: {type(ex).__name__}: {ex}"[:90]
                return
        sh = analysis.image_shader() if mode == "IMAGE" else analysis.reflection_shader()
        if sh is None:
            err = (analysis._shader_img if mode == "IMAGE" else analysis._shader)["error"]
            status["error"] = "diagnostic shader: " + err[:80]
            return
        vinv = rv3d.view_matrix.inverted()
        vp = proj @ rv3d.view_matrix
        s = scene.nurbs
        kind = {"ZEBRA": 0.0, "HIGHLIGHT": 2.0, "IMAGE": 3.0}[mode]
        for o in objs:
            pos, nor = analysis.geometry(o)
            if not len(pos):
                continue
            b = _batch(("Z" + ("I" if mode == "IMAGE" else ""), o.nurbs.blob_hash, o.nurbs.quality),
                       lambda: batch_for_shader(sh, "TRIS", {"pos": pos, "nor": nor}))
            mw = o.matrix_world
            mi = mw.inverted()
            r3 = mi.to_3x3()
            sh.bind()
            sh.uniform_float("mvp", vp @ mw)
            e = mi @ vinv.translation
            d = (r3 @ -vinv.col[2].xyz).normalized()
            if mode == "ZEBRA" and s.zebra_dir == "VERTICAL":
                u = (r3 @ vinv.col[0].xyz).normalized()     # bands across the view: upright stripes
            else:
                u = (r3 @ Vector((0.0, 0.0, 1.0))).normalized()
            if mode == "HIGHLIGHT":
                a = s.highlight_angle
                tw = Vector((math.cos(a), math.sin(a), 0.0))
                tv = (r3 @ tw).normalized()
                params = (tv.x, tv.y, tv.z, float(s.highlight_width))
                count = float(s.highlight_count)
            elif mode == "IMAGE":
                a = s.env_rotation
                xw = (r3 @ Vector((math.cos(a), math.sin(a), 0.0))).normalized()
                params = (xw.x, xw.y, xw.z, float(s.env_exposure))
                count = 0.0
            else:
                params = (1.0, 0.0, 0.0, 0.0)
                count = float(s.zebra_stripes)
            sh.uniform_float("eye", (e.x, e.y, e.z, count))
            sh.uniform_float("viewDir", (d.x, d.y, d.z, kind))
            sh.uniform_float("up", (u.x, u.y, u.z, 0.0 if rv3d.is_perspective else 1.0))
            sh.uniform_float("params", params)
            if tex is not None:
                sh.uniform_sampler("envTex", tex)
            _cull_for(o)
            b.draw(sh)
        return
    sh = gpu.shader.from_builtin("SMOOTH_COLOR")
    for o in objs:
        pos, _nor = analysis.geometry(o)
        if not len(pos):
            continue
        if mode == "DRAFT":
            v = {"X": (1, 0, 0), "Y": (0, 1, 0), "Z": (0, 0, 1)}[scene.nurbs.draft_pull[-1]]
            v = tuple(-c for c in v) if scene.nurbs.draft_pull.startswith("-") else v
            key = ("D", o.nurbs.blob_hash, o.nurbs.quality, v, round(scene.nurbs.draft_min, 4),
                   tuple(round(x, 6) for row in o.matrix_world.to_3x3() for x in row))
            make = lambda o=o, v=v: batch_for_shader(sh, "TRIS", {"pos": pos, "color": analysis.draft_colors(o, v, scene.nurbs.draft_min)})
        else:
            k = "GAUSSIAN" if mode == "CURVATURE" else mode
            key = ("K", o.nurbs.blob_hash, o.nurbs.quality, k, round(scene.nurbs.curvature_scale, 9))
            make = lambda o=o, k=k: batch_for_shader(sh, "TRIS", {"pos": pos, "color": analysis.curvature_colors(o, k, scene.nurbs.curvature_scale)[0]})
        b = _batch(key, make)
        _cull_for(o)
        with gpu.matrix.push_pop():
            gpu.matrix.multiply_matrix(o.matrix_world)
            b.draw(sh)


def _draw():
    global _warned
    import gpu
    from gpu_extras.batch import batch_for_shader

    from . import core

    ctx = bpy.context
    scene = ctx.scene
    if scene is None or not hasattr(scene, "nurbs"):
        return
    try:
        objs = [o for o in scene.objects if o.visible_get() and core.is_cad(o) and object_diagnostic(o, scene) != "NONE"]
        if not objs:
            return
        rv3d = ctx.region_data
        if rv3d is None:
            return
        gpu.state.blend_set("ALPHA")
        gpu.state.depth_test_set("LESS_EQUAL")
        gpu.state.depth_mask_set(False)
        proj = gpu.matrix.get_projection_matrix().copy()
        eps = 2e-5
        for k in range(4):
            proj[2][k] = proj[2][k] - eps * proj[3][k]
        with gpu.matrix.push_pop_projection():
            gpu.matrix.load_projection_matrix(proj)
            try:
                _draw_diagnostic(ctx, scene, objs, proj)
            except Exception as ex:
                status["error"] = f"diagnostic: {type(ex).__name__}: {ex}"
        status["draws"] += 1
        status["error"] = ""
    except Exception as ex:
        status["error"] = f"{type(ex).__name__}: {ex}"
        if not _warned:
            import traceback
            print("Blender STEP overlay error:")
            traceback.print_exc()
            _warned = True
    finally:
        gpu.state.depth_mask_set(True)
        gpu.state.depth_test_set("NONE")
        gpu.state.blend_set("NONE")


def register():
    global _handle
    if bpy.app.background or _handle is not None:
        return
    _handle = bpy.types.SpaceView3D.draw_handler_add(_draw, (), "WINDOW", "POST_VIEW")


def unregister():
    global _handle
    if _handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_handle, "WINDOW")
        _handle = None
    _batches.clear()
