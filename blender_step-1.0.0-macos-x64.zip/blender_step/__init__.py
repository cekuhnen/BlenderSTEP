# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender STEP: import STEP bodies into Blender, display them, bake to a mesh.

Geometry is computed by SMLib (NVIDIA's open-sourced USD B-rep kernel, Apache-2.0) through smlibpy
(MIT). Each imported CAD object keeps its exact solid as a blob; the mesh you see is a tessellation
of it, made by the add-on's own fast mesher where it can and by the kernel's tessellation otherwise.

This is a pure STEP importer: no modeling, editing or diagnostic-shading tools live here.
"""

import bpy

from . import core, ops_io, overlay, props, ui
from .kernel import mesher

_operator_classes = ops_io.classes
_panel_classes = ui.classes


@bpy.app.handlers.persistent
def _on_load(*_args):
    """A file brings its own mesher setting."""
    try:
        mesher.set_mode(bpy.context.scene.nurbs.mesher_mode)
    except Exception:
        mesher.set_mode("AUTO")


def register():
    props.register()
    for c in (*_operator_classes, *_panel_classes):
        bpy.utils.register_class(c)
    ops_io.register_menus()
    overlay.register()
    if _on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load)


def unregister():
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    ops_io.unregister_menus()
    overlay.unregister()
    for c in reversed((*_operator_classes, *_panel_classes)):
        bpy.utils.unregister_class(c)
    props.unregister()
