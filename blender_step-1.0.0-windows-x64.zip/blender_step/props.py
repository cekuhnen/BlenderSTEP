import bpy


def _quality_update(self, context):
    from . import core
    obj = self.id_data
    if self.is_cad and isinstance(obj, bpy.types.Object):
        try:
            core.sync_mesh(obj)
        except Exception as ex:  # keep the UI alive
            print("NURBS STEP Importer: re-tessellation failed:", ex)


def _fast_mesh_update(self, context):
    """Switch between the add-on's own mesher and the kernel's tessellation; every part is meshed
    again."""
    from . import core
    from .kernel import mesher, session
    mesher.enabled = bool(self.fast_mesh)
    session.clear()
    core._bvh_cache.clear()
    for obj in (context.scene.objects if context and context.scene else ()):
        if core.is_cad(obj):
            try:
                core.sync_mesh(obj)
            except Exception as ex:  # keep the UI alive
                print("NURBS STEP Importer: re-tessellation failed:", ex)


class NURBS_PG_object(bpy.types.PropertyGroup):
    is_cad: bpy.props.BoolProperty(name="CAD Object", default=False)
    # The exact solid or surface: SMLib .smb, zlib-compressed, base64. This is the truth;
    # the mesh is display. Stored on the object so Blender's undo snapshots it.
    blob: bpy.props.StringProperty(name="Exact Geometry", default="", options={"HIDDEN"})
    blob_hash: bpy.props.StringProperty(name="Hash", default="", options={"HIDDEN"})
    info: bpy.props.StringProperty(name="Info", default="")
    quality: bpy.props.EnumProperty(
        name="Display Quality",
        items=[
            ("DRAFT", "Draft", "Coarse tessellation, fastest"),
            ("NORMAL", "Normal", "Balanced tessellation"),
            ("FINE", "Fine", "Dense tessellation for close-ups and renders"),
        ],
        default="NORMAL",
        update=_quality_update,
    )
    # Selected kernel faces / edges of the current shape, as comma-separated ids.
    sel_faces: bpy.props.StringProperty(default="", options={"HIDDEN"})
    sel_edges: bpy.props.StringProperty(default="", options={"HIDDEN"})


class NURBS_PG_scene(bpy.types.PropertyGroup):
    fast_mesh: bpy.props.BoolProperty(
        name="Fast Mesher", default=True, update=_fast_mesh_update,
        description="Mesh parts with the add-on's own mesher (several times faster on parts with many holes "
                    "or faces, and only the faces an edit changed are meshed again); off: the kernel's "
                    "tessellation for every part")


classes = (NURBS_PG_object, NURBS_PG_scene)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Object.nurbs = bpy.props.PointerProperty(type=NURBS_PG_object)
    bpy.types.Scene.nurbs = bpy.props.PointerProperty(type=NURBS_PG_scene)


def unregister():
    del bpy.types.Scene.nurbs
    del bpy.types.Object.nurbs
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
