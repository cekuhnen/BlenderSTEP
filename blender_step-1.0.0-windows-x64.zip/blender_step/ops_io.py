import os

import bpy
from bpy_extras.io_utils import ImportHelper

from . import core
from .kernel import api
from .kernel.api import CadError

# The kernel works in millimeters (STEP files are converted to mm on reading); Blender's lengths
# are in Blender units.
BU_UNITS = [("SCENE", "Scene", "From the scene's units: 1 Blender unit = Unit Scale meters (normally 1 m, also in "
                       "an Imperial scene, which only displays inches)"),
            ("m", "Meters", "1 Blender unit = 1 m"),
            ("mm", "Millimeters", "1 Blender unit = 1 mm"),
            ("cm", "Centimeters", "1 Blender unit = 1 cm"),
            ("inch", "Inches", "1 Blender unit = 1 inch")]
_MM = {"m": 1000.0, "mm": 1.0, "cm": 10.0, "inch": 25.4}


def mm_per_blender_unit(context, choice: str = "SCENE") -> float:
    if choice in _MM:
        return _MM[choice]
    try:
        s = float(f"{float(context.scene.unit_settings.scale_length):.7g}")   # (stored in single precision)
    except Exception:
        s = 1.0
    return 1000.0 * (s if s > 0 else 1.0)


class NURBS_OT_import_step(bpy.types.Operator, ImportHelper):
    """Import STEP bodies as exact CAD objects, at their real size"""
    bl_idname = "nurbs.import_step"
    bl_label = "Import STEP"
    filename_ext = ".step"
    filter_glob: bpy.props.StringProperty(default="*.step;*.stp", options={"HIDDEN"})
    unit: bpy.props.EnumProperty(name="Blender Unit Is", items=BU_UNITS, default="SCENE")
    scale: bpy.props.FloatProperty(name="Extra Scale", default=1.0, min=1e-6,
                                   description="Applied on top of the unit conversion (1: real size)")

    def execute(self, context):
        k = self.scale / mm_per_blender_unit(context, self.unit)    # mm -> Blender units
        try:
            bodies = api.import_step(self.filepath)
            base = os.path.splitext(os.path.basename(self.filepath))[0]
            made = []
            for i, b in enumerate(bodies):
                if abs(k - 1.0) > 1e-12:
                    b = api._call("scale", b.scale, k)
                name = getattr(b, "name", None) or f"{base}_{i + 1}"
                made.append(core.new_cad_object(name, b, context.collection))
        except CadError as ex:
            self.report({"ERROR"}, str(ex))
            return {"CANCELLED"}
        for o in context.selected_objects:
            o.select_set(False)
        for o in made:
            o.select_set(True)
        if made:
            context.view_layer.objects.active = made[-1]
        self.report({"INFO"}, f"Imported {len(made)} bod{'y' if len(made) == 1 else 'ies'}")
        return {"FINISHED"}


class NURBS_OT_bake_mesh(bpy.types.Operator):
    """Keep the current mesh and drop the exact geometry (turns a CAD object into a regular mesh)"""
    bl_idname = "nurbs.bake_mesh"
    bl_label = "Bake to Mesh"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(core.is_cad(o) for o in context.selected_objects)

    def execute(self, context):
        for o in context.selected_objects:
            if core.is_cad(o):
                p = o.nurbs
                p.is_cad = False
                p.blob = ""
                p.blob_hash = ""
                p.info = ""
                core.clear_selection(o)
        return {"FINISHED"}


def menu_import(self, context):
    self.layout.operator(NURBS_OT_import_step.bl_idname, text="STEP (.step / .stp)")


classes = (NURBS_OT_import_step, NURBS_OT_bake_mesh)


def register_menus():
    bpy.types.TOPBAR_MT_file_import.append(menu_import)


def unregister_menus():
    bpy.types.TOPBAR_MT_file_import.remove(menu_import)
