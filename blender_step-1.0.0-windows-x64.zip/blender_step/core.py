# SPDX-License-Identifier: GPL-3.0-or-later
"""Object-level logic of the pure STEP importer: CAD objects and their display mesh.

No operator or UI context in here, so all of it runs headless (tests use bpy as a module).
"""

from __future__ import annotations

import bpy
import numpy as np

from .kernel import api, session
from .kernel.api import CadError

ATTR_FACE = "cad_face"
TESS_TAG = "nurbs_tess"   # on the mesh data: which tessellation it holds (shape, quality, mesher)

# object name -> (blob hash, blob) of a preview shown in place of the object's own shape
preview: dict = {}

_bvh_cache: dict = {}


def is_cad(obj) -> bool:
    return obj is not None and obj.type == "MESH" and obj.nurbs.is_cad and bool(obj.nurbs.blob)


def shape_of(obj):
    p = obj.nurbs
    if not p.blob:
        raise CadError(f"{obj.name} has no exact geometry")
    return session.shape_for(p.blob_hash, p.blob)


def _tess_tag(blob_hash: str, quality: str) -> str:
    from .kernel import mesher
    return f"{blob_hash}|{quality}|{'fast' if mesher.available() else 'kernel'}"


def _tess_from_mesh(obj):
    """The tessellation saved in the object's own mesh (after opening a file), when the mesh
    still holds exactly the shape and quality it was written for; else None."""
    me = obj.data
    p = obj.nurbs
    if me is None or me.get(TESS_TAG) != _tess_tag(p.blob_hash, p.quality) or obj.name in preview:
        return None
    attr = me.attributes.get(ATTR_FACE)
    if attr is None or attr.domain != "FACE" or not len(me.polygons):
        return None
    nt = len(me.polygons)
    if len(me.loops) != nt * 3:
        return None
    co = np.zeros(len(me.vertices) * 3, dtype=np.float32)
    me.vertices.foreach_get("co", co)
    vi = np.zeros(nt * 3, dtype=np.int32)
    me.loops.foreach_get("vertex_index", vi)
    owners = np.zeros(nt, dtype=np.int32)
    attr.data.foreach_get("value", owners)
    normals = None
    try:
        cn = np.zeros(nt * 9, dtype=np.float32)
        me.corner_normals.foreach_get("vector", cn)
        normals = cn.reshape(nt, 3, 3).astype(np.float64)
    except Exception:
        normals = None
    return api.TessResult(co.reshape(-1, 3).astype(np.float64), vi.reshape(-1, 3).astype(np.int64), normals,
                          owners.astype(np.int64))


def tess_of(obj):
    p = obj.nurbs
    if not session.has_tess(p.blob_hash, p.quality):
        t = _tess_from_mesh(obj)
        if t is not None:
            session.put_tess(p.blob_hash, p.quality, t)
            return t
    return session.tess_for(p.blob_hash, p.blob, p.quality)


def set_shape(obj, shape) -> None:
    """Replace the object's exact geometry, clear the kernel selection, refresh the mesh."""
    blob = api.to_blob(shape)
    h = api.blob_hash(blob)
    session.remember(h, shape)
    p = obj.nurbs
    p.is_cad = True
    p.blob = blob
    p.blob_hash = h
    p.sel_faces = ""
    p.sel_edges = ""
    p.info = api.describe(shape)
    sync_mesh(obj)


def set_blob(obj, blob: str, info: str = "") -> None:
    """Like set_shape, for a result that arrives already encoded (from the kernel worker)."""
    h = api.blob_hash(blob)
    p = obj.nurbs
    p.is_cad = True
    p.blob = blob
    p.blob_hash = h
    p.sel_faces = ""
    p.sel_edges = ""
    p.info = info or api.describe(session.shape_for(h, blob))
    sync_mesh(obj)


def new_cad_object(name: str, shape, collection=None, matrix=None):
    me = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, me)
    (collection or bpy.context.scene.collection).objects.link(obj)
    if matrix is not None:
        obj.matrix_world = matrix
    set_shape(obj, shape)
    return obj


# ----------------------------------------------------------------------------- mesh sync

def sync_mesh(obj) -> None:
    """Write the exact shape's tessellation into the object's mesh data."""
    preview.pop(obj.name, None)
    _write_mesh(obj, tess_of(obj))


def _write_mesh(obj, t) -> None:
    me = obj.data
    if me.users > 1:  # never rewrite geometry shared with another object
        me = me.copy()
        obj.data = me

    tris = t.triangles
    keep = (tris[:, 0] != tris[:, 1]) & (tris[:, 1] != tris[:, 2]) & (tris[:, 0] != tris[:, 2])
    tris = tris[keep]
    owners = t.face_ids[keep] if len(t.face_ids) == len(keep) else np.full(len(tris), -1, dtype=np.int64)
    normals = None if t.corner_normals is None else t.corner_normals[keep]

    me.clear_geometry()
    nv, nt = len(t.vertices), len(tris)
    me.vertices.add(nv)
    me.vertices.foreach_set("co", t.vertices.astype(np.float32).ravel())
    me.loops.add(nt * 3)
    me.loops.foreach_set("vertex_index", tris.astype(np.int32).ravel())
    me.polygons.add(nt)
    me.polygons.foreach_set("loop_start", (np.arange(nt, dtype=np.int32) * 3))
    me.update(calc_edges=True)

    attr = me.attributes.get(ATTR_FACE)
    if attr is None or attr.domain != "FACE" or attr.data_type != "INT":
        if attr is not None:
            me.attributes.remove(attr)
        attr = me.attributes.new(ATTR_FACE, "INT", "FACE")
    attr.data.foreach_set("value", owners.astype(np.int32))

    me.shade_smooth()
    if normals is not None and nt:
        n = normals.reshape(-1, 3)
        lens = np.linalg.norm(n, axis=1, keepdims=True)
        n = np.where(lens > 1e-12, n / np.maximum(lens, 1e-12), 0.0)
        me.normals_split_custom_set(n.tolist())
    me.update()
    try:
        ph, _pb = preview.get(obj.name, (obj.nurbs.blob_hash, None))
        me[TESS_TAG] = _tess_tag(ph, obj.nurbs.quality) if obj.name not in preview else ""
    except Exception:
        pass
    _bvh_cache.pop(_bvh_key(obj), None)


def _bvh_key(obj):
    p = obj.nurbs
    return (p.blob_hash, p.quality)


# ----------------------------------------------------------------------------- selection

def clear_selection(obj) -> None:
    obj.nurbs.sel_faces = ""
    obj.nurbs.sel_edges = ""


# ----------------------------------------------------------------------------- previews

def show_preview(obj, blob: str) -> None:
    """Show another exact shape in the object's mesh (live preview); the object's stored
    geometry does not change. clear_preview() puts the real one back."""
    h = api.blob_hash(blob)
    preview[obj.name] = (h, blob)
    _write_mesh(obj, session.tess_for(h, blob, obj.nurbs.quality))


def clear_preview(obj) -> None:
    if preview.pop(obj.name, None) is not None:
        sync_mesh(obj)


def preview_key(obj):
    """(hash, blob) the viewport should draw for obj: its preview, else its own shape."""
    pv = preview.get(obj.name)
    return pv if pv is not None else (obj.nurbs.blob_hash, obj.nurbs.blob)
