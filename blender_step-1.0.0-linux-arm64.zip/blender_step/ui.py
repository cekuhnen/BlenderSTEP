import bpy

from .kernel import api, mesher
from .ops_io import NURBS_OT_bake_mesh, NURBS_OT_import_step


class NURBS_PT_main(bpy.types.Panel):
    """Import STEP bodies, display them, bake to a mesh"""
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "STEP"
    bl_label = "Blender STEP"

    def draw(self, context):
        layout = self.layout
        if not api.available():
            box = layout.box()
            box.alert = True
            box.label(text="SMLib kernel failed to load", icon="ERROR")
            box.label(text=str(api.IMPORT_ERROR)[:80], icon="ERROR")
            return
        box = layout.box()
        box.operator(NURBS_OT_import_step.bl_idname, text="Import STEP", icon="IMPORT")
        s = context.scene.nurbs
        box.prop(s, "fast_mesh", text="Fast Mesher")
        if s.fast_mesh and mesher.stats.get("fallback"):
            box.label(text=f"{mesher.stats['fallback']} by kernel", icon="INFO")
        obj = context.active_object
        if obj is not None and obj.nurbs.is_cad:
            box.prop(obj.nurbs, "quality", text="Display Quality")
            box.prop(obj.nurbs, "diagnostic", text="Diagnostic")
            from . import overlay
            if overlay.status["error"]:
                box.alert = True
                box.label(text="Overlay error (diagnostic hidden):", icon="ERROR")
                box.label(text=str(overlay.status["error"])[:90], icon="ERROR")
            if overlay.status["draws"] == 0 and overlay.status["error"] == "":
                box.label(text="Overlay has not drawn yet", icon="INFO")
            if obj.nurbs.diagnostic == "ZEBRA":
                row = box.row(align=True)
                row.prop(s, "zebra_dir", expand=True)
                box.prop(s, "zebra_stripes")
            if obj.nurbs.diagnostic == "HIGHLIGHT":
                row = box.row(align=True)
                row.prop(s, "highlight_count")
                row.prop(s, "highlight_width")
                box.prop(s, "highlight_angle")
            if obj.nurbs.diagnostic == "IMAGE":
                box.template_ID(s, "env_image", open="image.open")
                row = box.row(align=True)
                row.prop(s, "env_rotation")
                row.prop(s, "env_exposure")
            if obj.nurbs.diagnostic == "HIGH":
                box.prop(s, "curvature_scale")
        box.operator(NURBS_OT_bake_mesh.bl_idname, text="Bake to Mesh", icon="MESH_DATA")


classes = (NURBS_PT_main,)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
